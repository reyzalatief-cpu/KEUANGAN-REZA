/** Deterministic accrual accounting. Amounts are integer IDR; quantities use 1e-6 units. */
export const DEFAULT_COA = `1-1101|TUNAI (KAS)
1-1102|BANK
1-1103|EWALLET
1-1201|PIUTANG
1-1301|BIAYA DIBAYAR DI MUKA
1-2010|PERSEDIAAN
1-4001|PERALATAN
1-4002|AKUMULASI PENYUSUTAN PERALATAN
2-1101|HUTANG
2-1201|BEBAN YANG MASIH HARUS DIBAYAR
3-1001|MODAL AWAL
3-1002|PRIVE
3-2001|LABA DITAHAN
4-1100|PENJUALAN BARANG
4-2100|PENDAPATAN GAJI
4-3100|PENDAPATAN SELISIH KURS
4-3200|PENDAPATAN LAIN LAIN
5-1300|HARGA POKOK PENJUALAN (HPP)
5-2001|BIAYA KONSUMSI
5-2002|BIAYA HIBURAN
5-2003|BIAYA KOMUNIKASI DAN INTERNET
5-2004|BIAYA LISTRIK DAN AIR
5-2005|BIAYA SEWA KOST
5-2006|BIAYA TRANSPORTASI DAN BBM
5-2007|BIAYA PEMELIHARAAN ASET
5-2008|BIAYA PENDIDIKAN
5-2009|BIAYA KEWAJIBAN KE ORANG TUA
5-3001|BUNGA PINJAMAN
5-3002|BIAYA ADMIN BANK
5-4001|BEBAN GAJI DIBAYAR
5-5001|BEBAN PENYUSUTAN PERALATAN
5-9001|BIAYA LAIN LAIN DAN SELISIH KAS
5-9002|BEBAN GIFT`.split('\n').map(x => Object.freeze(x.split('|')));
Object.freeze(DEFAULT_COA);
export const CASH = Object.freeze(['1-1101', '1-1102', '1-1103']);
const SCALE = 1_000_000;
const REQUIRED = ['1-2010','1-1201','2-1101','3-1001','3-1002','3-2001','4-1100','5-1300'];
const TYPES = new Set(['A','U','P','T']);
const CATEGORIES = ['Operasional','Investasi','Pendanaan'];
const fail = message => { throw new Error(message); };
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const text = (value, label, max=500, allowEmpty=false) => {
  if (typeof value !== 'string' || value.length > max || /[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(value)) fail(`${label} tidak valid.`);
  const out = value.trim();
  if (!allowEmpty && !out) fail(`${label} wajib diisi.`);
  return out;
};
const amount = (value, label='Nominal', signed=false) => {
  if (typeof value !== 'number' || !Number.isSafeInteger(value) || (!signed && value < 0)) fail(`${label} harus bilangan bulat Rupiah yang aman${signed ? '' : ' dan tidak negatif'}.`);
  return value === 0 ? 0 : value;
};
const sum = values => values.reduce((a,b) => amount(a+b, 'Total nominal', true), 0);
const micros = value => {
  if (typeof value !== 'number' || !Number.isFinite(value) || value <= 0) fail('Kuantitas harus positif.');
  const n = Math.round(value * SCALE);
  if (!Number.isSafeInteger(n) || n <= 0 || Math.abs(value * SCALE - n) > 0.00001) fail('Kuantitas maksimal 6 angka desimal dan harus dalam batas aman.');
  return n;
};
const roundedRatio = (value, numerator, denominator) => {
  const n = BigInt(value) * BigInt(numerator), d = BigInt(denominator);
  return amount(Number((n * 2n + d) / (2n * d)));
};
const date = (value,label='Tanggal') => {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value) || value < '1900-01-01' || value > '9999-12-31') fail(`${label} tidak valid.`);
  const parsed = new Date(value + 'T00:00:00Z');
  if (Number.isNaN(parsed.valueOf()) || parsed.toISOString().slice(0,10) !== value) fail(`${label} tidak valid.`);
  return value;
};
const identifier = value => {
  if (typeof value === 'number' && Number.isSafeInteger(value) && value >= 0) return value;
  if (typeof value === 'string' && /^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$/.test(value)) return value;
  fail('ID tidak valid.');
};
const masterCode = value => {
  if (typeof value !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/.test(value)) fail('Kode master hanya boleh huruf, angka, titik, garis bawah, dan tanda hubung.');
  return value;
};
const isCash = code => code.startsWith('1-11');
const temporary = code => /^[45]-/.test(code);
// Array order is the transaction sequence when dates and journal kinds tie.
// Preserve that sequence when editing: moving a purchase behind a sale can
// change moving-average cost even though neither date changed.
const replaceJournal = (state, journal) => {
  const index = state.j.findIndex(j=>String(j.id)===String(journal.id));
  return index < 0 ? [...state.j,journal] : state.j.map((j,i)=>i===index?journal:j);
};

export function emptyState() {
  return {version:3,j:[],coa:DEFAULT_COA.map(x=>[...x]),bantu:[],prod:[],settings:{entity:'Keuangan Reza',notes:''},closedThrough:'',reconciliation:[]};
}

function masters(data) {
  const out = {};
  for (const key of ['coa','bantu','prod']) {
    if (!Array.isArray(data[key]) || data[key].length > 10000) fail(`Daftar ${key} tidak valid.`);
    const seen = new Set();
    out[key] = data[key].map(row => {
      if (!Array.isArray(row) || row.length !== (key === 'prod' ? 3 : 2)) fail(`Baris master ${key} tidak valid.`);
      const code = key === 'coa' ? text(row[0],'Kode akun',6) : masterCode(row[0]);
      if (key === 'coa' && !/^[1-5]-\d{4}$/.test(code)) fail('Kode akun harus berbentuk 1-0000 sampai 5-9999.');
      if (seen.has(code)) fail(`Kode ${code} duplikat.`);
      seen.add(code);
      const normalized = [code,text(row[1],'Nama master',200)];
      if (key === 'prod') normalized.push(amount(row[2],'Harga produk'));
      return normalized;
    });
  }
  for (const code of REQUIRED) if (!out.coa.some(x=>x[0]===code)) fail(`Akun wajib ${code} tidak boleh dihapus.`);
  return out;
}

function normalizedJournal(j, state) {
  if (!object(j)) fail('Jurnal tidak valid.');
  const out = {id:identifier(j.id),tgl:date(j.tgl),jn:j.jn,ket:text(j.ket,'Keterangan',2000)};
  if (!TYPES.has(j.jn)) fail('Jenis jurnal tidak valid.');
  if (!Array.isArray(j.l) || j.l.length < 2 || j.l.length > 500) fail('Jurnal harus berisi 2 sampai 500 baris.');
  const coa = new Set(state.coa.map(x=>x[0])), contacts = new Set(state.bantu.map(x=>x[0])), products = new Set(state.prod.map(x=>x[0]));
  out.l = j.l.map(line => {
    if (!Array.isArray(line) || line.length < 3 || line.length > 5 || !coa.has(line[0])) fail('Setiap baris jurnal wajib menggunakan akun yang terdaftar.');
    const [code] = line, debit = amount(line[1],'Debit'), credit = amount(line[2],'Kredit');
    if (debit && credit) fail('Satu baris tidak boleh sekaligus debit dan kredit.');
    const normalized = [code,debit,credit];
    if (code === '1-2010') {
      if (!products.has(line[3])) fail('Produk persediaan harus terdaftar di master produk.');
      const qty = micros(line[4]);
      normalized.push(line[3],qty/SCALE);
    } else {
      if (!debit && !credit) fail('Baris jurnal tanpa nominal harus dihapus.');
      if (code === '1-1201' || code === '2-1101') {
        if (!contacts.has(line[3])) fail('Piutang/hutang wajib menggunakan kontak terdaftar.');
        normalized.push(line[3]);
      } else if ((line[3] !== undefined && line[3] !== '') || (line[4] !== undefined && line[4] !== 0)) fail('Kode bantu/kuantitas hanya untuk akun piutang, hutang, dan persediaan.');
    }
    if (j.jn === 'T' && !temporary(code) && !['3-1002','3-2001'].includes(code)) fail('Jurnal penutup hanya boleh memindahkan akun laba/rugi dan prive ke laba ditahan.');
    return normalized;
  });
  const debit = sum(out.l.map(x=>x[1])), credit = sum(out.l.map(x=>x[2]));
  if (!debit || debit !== credit) fail('Total debit dan kredit harus sama dan lebih besar dari nol.');
  if (j.cashCategory !== undefined && j.cashCategory !== '') {
    if (!CATEGORIES.includes(j.cashCategory)) fail('Kategori arus kas tidak valid.');
    out.cashCategory = j.cashCategory;
  }
  if (j.reference !== undefined) out.reference = text(j.reference,'Referensi',200,true);
  return out;
}

export function sorted(state) {
  const order = {A:0,U:1,P:1,T:2};
  return state.j.map((j,i)=>({j,i})).sort((a,b)=>a.j.tgl.localeCompare(b.j.tgl) || order[a.j.jn]-order[b.j.jn] || a.i-b.i).map(x=>x.j);
}

function stockBook(state, to) {
  const result = new Map(state.prod.map(([code])=>[code,{units:0,value:0}]));
  for (const j of sorted(state)) {
    if (to && j.tgl > to) continue;
    for (const [code,debit,credit,product,quantity] of j.l) {
      if (code !== '1-2010') continue;
      const item = result.get(product);
      if (!item) fail(`Produk ${product} tidak dikenal.`);
      const units = micros(quantity);
      if (debit > 0) {
        item.units = amount(item.units+units,'Jumlah stok');
        item.value = sum([item.value,debit]);
      } else {
        if (units > item.units) fail(`Stok ${product} tidak cukup pada ${j.tgl} (jurnal ${j.id}). Periksa urutan tanggal dan mutasi.`);
        const expected = units === item.units ? item.value : roundedRatio(item.value,units,item.units);
        if (credit !== expected) fail(`HPP ${product} pada ${j.tgl} harus Rp${expected} sesuai rata-rata bergerak, bukan Rp${credit}. Perubahan mundur harus dikoreksi berurutan.`);
        item.units -= units;
        item.value -= credit;
      }
    }
  }
  return result;
}

export function validateJournal(j,state) {
  const normalized = normalizedJournal(j,state);
  validateState({...state,j:replaceJournal(state,normalized)});
  return normalized;
}

export function validateState(data) {
  if (!object(data)) fail('Data buku tidak valid.');
  if (data.version !== undefined && ![1,2,3].includes(data.version)) fail('Versi data tidak didukung.');
  const base = masters(data);
  if (!Array.isArray(data.j) || data.j.length > 100000) fail('Daftar jurnal tidak valid atau terlalu besar.');
  const result = {version:3,...base,j:[],settings:{entity:'Keuangan Reza',notes:''},closedThrough:'',reconciliation:[]};
  const ids = new Set();
  result.j = data.j.map(j => {
    const out = normalizedJournal(j,result), id = String(out.id);
    if (ids.has(id)) fail(`ID jurnal ${id} duplikat.`);
    ids.add(id);
    return out;
  });
  if (data.settings !== undefined) {
    if (!object(data.settings)) fail('Pengaturan tidak valid.');
    result.settings = {entity:text(data.settings.entity ?? 'Keuangan Reza','Nama entitas',200),notes:text(data.settings.notes ?? '','Catatan laporan',20000,true)};
  }
  if (data.closedThrough !== undefined && data.closedThrough !== '') result.closedThrough = date(data.closedThrough,'Tanggal kunci buku');
  if (data.reconciliation !== undefined) {
    if (!Array.isArray(data.reconciliation) || data.reconciliation.length > 100000) fail('Rekonsiliasi tidak valid.');
    const seen = new Set(), accounts = new Set(result.coa.map(x=>x[0]));
    result.reconciliation = data.reconciliation.map(r => {
      if (!object(r)) fail('Baris rekonsiliasi tidak valid.');
      const id = identifier(r.id);
      if (seen.has(String(id))) fail('ID rekonsiliasi duplikat.');
      seen.add(String(id));
      if (typeof r.account !== 'string' || !accounts.has(r.account) || !isCash(r.account)) fail('Rekonsiliasi harus memakai akun kas/bank.');
      const journalId = r.journalId === undefined || r.journalId === null || r.journalId === '' ? null : identifier(r.journalId);
      if (journalId !== null && !ids.has(String(journalId))) fail('Jurnal yang dicocokkan pada rekonsiliasi tidak ditemukan.');
      return {id,date:date(r.date),description:text(r.description ?? '','Keterangan rekonsiliasi',1000,true),amount:amount(r.amount,'Nominal rekening koran',true),account:r.account,journalId};
    });
    const matched = new Set();
    for (const r of result.reconciliation) if (r.journalId !== null) {
      const key = `${r.account}:${r.journalId}`;
      if (matched.has(key)) fail('Satu mutasi jurnal/rekening tidak boleh dicocokkan dua kali.');
      matched.add(key);
      const j = result.j.find(x=>String(x.id)===String(r.journalId));
      const net = sum(j.l.filter(x=>x[0]===r.account).map(x=>x[1]-x[2]));
      if (net !== r.amount || !net) fail('Nominal rekening koran harus sama dengan mutasi akun pada jurnal yang dicocokkan.');
    }
  }
  stockBook(result);
  // Closing lines must exactly remove temporary balances, never manufacture profit.
  let running = Object.create(null);
  for (const j of sorted(result)) {
    if (j.jn === 'T') {
      const expected = closingLines(running);
      const actual = aggregateLines(j.l);
      const wanted = aggregateLines(expected);
      if (JSON.stringify(Object.entries(actual).sort()) !== JSON.stringify(Object.entries(wanted).sort())) fail(`Jurnal penutup ${j.id} tidak sesuai saldo akun pada tanggal penutupan.`);
    }
    for (const [code,d,c] of j.l) running[code] = sum([running[code]||0,d,-c]);
  }
  return result;
}

function period(options={}) {
  const from = options.from ? date(options.from,'Tanggal awal') : '', to = options.to ? date(options.to,'Tanggal akhir') : '';
  if (from && to && from > to) fail('Tanggal awal tidak boleh melewati tanggal akhir.');
  return {from,to};
}

export function balances(state, options={}) {
  const {from,to} = period(options), types = options.types ? new Set(options.types) : null, b = {};
  for (const j of state.j) {
    if ((from && j.tgl < from) || (to && j.tgl > to) || (types && !types.has(j.jn))) continue;
    for (const [code,d,c] of j.l) b[code] = sum([b[code]||0,d,-c]);
  }
  return b;
}

export function inventory(state, options={}) {
  if (options.to) date(options.to);
  const book = stockBook(state,options.to);
  return state.prod.map(([code])=>{const s=book.get(code);return {code,qty:s.units/SCALE,value:s.value,average:s.units?s.value*SCALE/s.units:0};});
}

export function subsidiary(state, account, options={}) {
  if (account === '1-2010') return inventory(state,options).map(x=>({code:x.code,balance:x.value,qty:x.qty}));
  if (!['1-1201','2-1101'].includes(account)) fail('Buku bantu tersedia untuk piutang, hutang, dan persediaan.');
  if (options.to) date(options.to);
  const map = new Map();
  for (const j of state.j) if (!options.to || j.tgl <= options.to) for (const [code,d,c,contact] of j.l) if (code === account) map.set(contact,sum([map.get(contact)||0,(d-c)*(account==='2-1101'?-1:1)]));
  return [...map].map(([code,balance])=>({code,balance,qty:0}));
}

const profit = b => sum(Object.entries(b).filter(([k])=>temporary(k)).map(([,v])=>-v));
const equity = b => -sum(Object.entries(b).filter(([k])=>k.startsWith('3-')).map(([,v])=>v)) + profit(b);
const category = code => code.startsWith('1-4') ? 'Investasi' : code.startsWith('3-') ? 'Pendanaan' : 'Operasional';

export function reports(state, options={}) {
  const {from,to}=period(options), inside=j=>(!from||j.tgl>=from)&&(!to||j.tgl<=to);
  const b=balances(state,{to}), inc=balances(state,{from,to,types:['U','P']}), names=new Map(state.coa);
  const sales = -sum(Object.entries(inc).filter(([k])=>k.startsWith('4-1')).map(([,v])=>v));
  const hpp=inc['5-1300']||0, other=state.coa.filter(([k])=>k.startsWith('4-')&&!k.startsWith('4-1')).map(([k,n])=>[n,-(inc[k]||0)]).filter(x=>x[1]);
  const expenses=state.coa.filter(([k])=>k.startsWith('5-')&&k!=='5-1300').map(([k,n])=>[n,-(inc[k]||0)]).filter(x=>x[1]);
  const laba=profit(inc), LR=[['Penjualan',sales],['HPP',-hpp],['LABA KOTOR',sales-hpp,1],...other,...expenses,['LABA (RUGI) BERSIH',laba,1]];
  const rows=prefix=>state.coa.filter(([k])=>k.startsWith(prefix)).map(([k,n])=>[`${k} ${n}`,prefix==='1-'?(b[k]||0):-(b[k]||0)]).filter(x=>x[1]);
  const A=rows('1-'),L=rows('2-'),Q=rows('3-'),aset=sum(A.map(x=>x[1])),liab=sum(L.map(x=>x[1])),unclosed=profit(b),eq=sum([...Q.map(x=>x[1]),unclosed]);
  const NR=[['ASET',0,1],...A,['TOTAL ASET',aset,1],['LIABILITAS',0,1],...L,['TOTAL LIABILITAS',liab,1],['EKUITAS',0,1],...Q,['Laba belum ditutup (seluruh periode)',unclosed],['TOTAL EKUITAS',eq,1],['TOTAL LIABILITAS + EKUITAS',liab+eq,1]];
  const openingState={...state,j:state.j.filter(j=>(!to||j.tgl<=to)&&((from&&j.tgl<from)||(inside(j)&&j.jn==='A')))};
  const opening=balances(openingState),modal0=equity(opening),drawings=-(inc['3-1002']||0),capital=-sum(Object.entries(inc).filter(([k])=>k.startsWith('3-')&&k!=='3-1002').map(([,v])=>v));
  const PM=[['Modal awal periode',modal0],['Laba (rugi) bersih',laba],['Penambahan modal / mutasi lain',capital],['Prive',drawings],['MODAL AKHIR',sum([modal0,laba,capital,drawings]),1]];
  const flow={Operasional:0,Investasi:0,Pendanaan:0};
  for (const j of state.j.filter(j=>inside(j)&&j.jn!=='A'&&j.jn!=='T')) {
    const cash=j.l.filter(x=>isCash(x[0])),otherLines=j.l.filter(x=>!isCash(x[0]));
    if (!cash.length) continue;
    if (j.cashCategory) flow[j.cashCategory]=sum([flow[j.cashCategory],...cash.map(x=>x[1]-x[2])]);
    else for(const [code,d,c] of otherLines) flow[category(code)]=sum([flow[category(code)],c,-d]);
  }
  const cashsum=book=>sum(Object.entries(book).filter(([k])=>isCash(k)).map(([,v])=>v));
  const k0=cashsum(opening),k1=cashsum(b),net=sum(Object.values(flow));
  const AK=[...Object.entries(flow).map(([k,v])=>[`Kas bersih ${k}`,v]),['KENAIKAN (PENURUNAN) KAS',net,1],['Saldo kas awal',k0],['SALDO KAS AKHIR',sum([k0,net]),1]];
  const chk=[['Neraca seimbang (Aset = Liabilitas + Ekuitas)',aset===liab+eq],['Modal akhir = ekuitas neraca',PM[4][1]===eq],['Arus kas = saldo kas buku besar',k0+net===k1]];
  // Numeric report cells are also exported to XML and JSON. Canonical zero
  // avoids a spurious -0 disagreement between those representations.
  const rowsWithoutNegativeZero=rows=>rows.map(([label,value,...rest])=>[label,value===0?0:value,...rest]);
  return {LR:rowsWithoutNegativeZero(LR),NR:rowsWithoutNegativeZero(NR),PM:rowsWithoutNegativeZero(PM),AK:rowsWithoutNegativeZero(AK),chk,aset,liab,eq,laba};
}

function aggregateLines(lines) {
  const result={};
  for(const [code,d,c] of lines) result[code]=sum([result[code]||0,d,-c]);
  for(const key of Object.keys(result)) if(!result[key]) delete result[key];
  return result;
}
function closingLines(b) {
  const lines=[];
  for(const [code,value] of Object.entries(b).sort()) if((temporary(code)||code==='3-1002')&&value) lines.push([code,Math.max(-value,0),Math.max(value,0)]);
  const difference=sum(lines.map(x=>x[1]-x[2]));
  if(difference) lines.push(['3-2001',Math.max(-difference,0),Math.max(difference,0)]);
  return lines;
}
export function closingEntries(state,from,to) {
  period({from,to});
  if(!to) fail('Tanggal akhir penutupan wajib diisi.');
  if(state.closedThrough && to<=state.closedThrough) fail('Periode sudah dikunci.');
  if(from) {
    const prior=balances({...state,j:state.j.filter(j=>j.tgl<from)});
    if(Object.entries(prior).some(([k,v])=>(temporary(k)||k==='3-1002')&&v)) fail('Masih ada saldo laba/prive sebelum awal periode. Tutup periode sebelumnya atau gunakan tanggal awal yang mencakupnya.');
  }
  const lines=closingLines(balances(state,{to}));
  if(!lines.length) return [];
  const id=`close-${to}`;
  if(state.j.some(j=>String(j.id)===id)) fail('ID penutupan tanggal ini sudah ada.');
  const journal={id,tgl:to,jn:'T',ket:`Penutupan periode ${from||'awal buku'} s.d. ${to}`,l:lines};
  validateState({...state,j:[...state.j,journal]});
  return [journal];
}

export function createTrade(state, options) {
  const {kind,product}=options;
  if(!['purchase','sale'].includes(kind)) fail('Jenis transaksi dagang tidak valid.');
  const tgl=date(options.date),quantity=micros(options.quantity),unitPrice=amount(options.unitPrice,'Harga satuan');
  if(!unitPrice) fail('Harga satuan harus lebih besar dari nol.');
  if(!state.prod.some(x=>x[0]===product)) fail('Produk tidak terdaftar.');
  const total=roundedRatio(unitPrice,quantity,SCALE);
  if(!total) fail('Nilai transaksi setelah pembulatan harus sekurangnya Rp1.');
  const paid=options.paidAmount===undefined?total:amount(options.paidAmount,'Pembayaran');
  if(paid>total) fail('Pembayaran tidak boleh melebihi total transaksi.');
  if(paid && (!state.coa.some(x=>x[0]===options.paymentAccount)||!isCash(options.paymentAccount))) fail('Akun pembayaran harus kas/bank terdaftar.');
  if(paid<total&&!state.bantu.some(x=>x[0]===options.contact)) fail('Pembayaran sebagian/kredit membutuhkan kontak terdaftar.');
  if(state.closedThrough&&tgl<=state.closedThrough) fail('Tanggal transaksi berada dalam periode terkunci.');
  const id=options.id??`trade-${globalThis.crypto.randomUUID()}`;
  const l=[];
  if(kind==='purchase') {
    l.push(['1-2010',total,0,product,quantity/SCALE]);
    if(paid) l.push([options.paymentAccount,0,paid]);
    if(paid<total) l.push(['2-1101',0,total-paid,options.contact]);
  } else {
    const sequence=sorted({...state,j:replaceJournal(state,{id,tgl,jn:'U'})});
    const position=sequence.findIndex(j=>String(j.id)===String(id));
    const stock=stockBook({...state,j:sequence.slice(0,position)}).get(product);
    if(!stock||quantity>stock.units) fail(`Stok ${product} tidak cukup.`);
    const cost=quantity===stock.units?stock.value:roundedRatio(stock.value,quantity,stock.units);
    if(paid) l.push([options.paymentAccount,paid,0]);
    if(paid<total) l.push(['1-1201',total-paid,0,options.contact]);
    l.push(['4-1100',0,total]);
    if(cost) l.push(['5-1300',cost,0]);
    l.push(['1-2010',0,cost,product,quantity/SCALE]);
  }
  const journal={id,tgl,jn:'U',ket:options.description||`${kind==='purchase'?'Pembelian':'Penjualan'} ${product}`,l};
  if(options.reference!==undefined) journal.reference=options.reference;
  const normalized=normalizedJournal(journal,state);
  validateState({...state,j:replaceJournal(state,normalized)});
  return normalized;
}
