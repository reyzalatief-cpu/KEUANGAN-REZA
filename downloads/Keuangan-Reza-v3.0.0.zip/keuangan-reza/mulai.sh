#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
if ! command -v node >/dev/null 2>&1; then
  printf '%s\n' 'Node.js belum ditemukan. Pasang Node.js 24.13 atau versi 24.x yang lebih baru.' >&2
  exit 1
fi
exec node scripts/start-local.mjs
