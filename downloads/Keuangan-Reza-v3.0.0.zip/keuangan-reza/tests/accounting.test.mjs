import test from 'node:test';
import assert from 'node:assert/strict';
import { DEFAULT_COA, emptyState, validateState, validateJournal, sorted, balances, inventory, subsidiary, reports, closingEntries, createTrade } from '../accounting.js';

const copy = value => structuredClone(value);
const journal = (id, tgl, l, extra={}) => ({id,tgl,jn:'U',ket:`Transaksi ${id}`,l,...extra});
const cashIncome = (id='income', tgl='2026-01-01', value=100) => journal(id,tgl,[['1-1101',value,0],['4-1100',0,value]]);
const fixture = () => {
  const state = emptyState();
  state.prod = [['P1','Barang pertama',250],['P2','Barang kedua',50]];
  state.bantu = [['C1','Pelanggan'],['V1','Pemasok']];
  return state;
};
const save = (state,j) => {
  const index=state.j.findIndex(old=>String(old.id)===String(j.id));
  state.j=index<0?[...state.j,j]:state.j.map((old,i)=>i===index?j:old);
  return state;
};
const trade = (state,kind,id,quantity,unitPrice,extra={}) => save(state,createTrade(state,{kind,id,quantity,unitPrice,product:'P1',date:'2026-01-10',paymentAccount:'1-1101',...extra}));
const cell = (rows,label) => rows.find(row=>row[0]===label)?.[1];
const assertChecks = report => assert.deepEqual(report.chk.map(row=>row[1]),[true,true,true]);

test('new books are independent and empty; legacy imports normalize without mutating their source', () => {
  const a=emptyState(),b=emptyState();
  a.coa[0][1]='Different';
  assert.notEqual(a.coa[0][1],b.coa[0][1]);
  assert.equal(DEFAULT_COA[0][1],'TUNAI (KAS)');
  assert.deepEqual(b.j,[]);
  assert.deepEqual(b.prod,[]);
  const legacy={coa:b.coa,bantu:[],prod:[],j:[cashIncome(1)]};
  const snapshot=copy(legacy),actual=validateState(legacy);
  assert.deepEqual(legacy,snapshot);
  assert.equal(actual.version,3);
  assert.equal(actual.j[0].id,1);
  assert.deepEqual(actual.settings,{entity:'Keuangan Reza',notes:''});
  assert.equal(actual.closedThrough,'');
  assert.deepEqual(actual.reconciliation,[]);
  assert.throws(()=>validateState({...legacy,version:999}),/Versi/);
});

test('all zero report values are canonical numbers, and an empty book balances', () => {
  const r=reports(emptyState());
  for(const key of ['LR','NR','PM','AK']) for(const [,value] of r[key]) assert.equal(Object.is(value,-0),false,`${key} contains -0`);
  assert.equal(Object.is(r.laba,-0),false);
  assertChecks(r);
});

test('master validation rejects duplicates, missing mandatory accounts, and unsupported account classes', () => {
  for(const key of ['coa','bantu','prod']) {
    const state=fixture(); state[key].push([...state[key][0]]);
    assert.throws(()=>validateState(state),/duplikat/);
  }
  const state=fixture(); state.coa=state.coa.filter(row=>row[0]!=='1-2010');
  assert.throws(()=>validateState(state),/Akun wajib/);
  const invalid=fixture(); invalid.coa.push(['6-1000','Tidak didukung']);
  assert.throws(()=>validateState(invalid),/Kode akun/);
  const negative=fixture(); negative.prod[0][2]=-1;
  assert.throws(()=>validateState(negative),/Harga produk/);
});

test('strict journals reject invalid, unbalanced, empty and unknown account entries', () => {
  const badLines=[
    [['',100,0],['4-1100',0,100]],
    [['1-9999',100,0],['4-1100',0,100]],
    [['1-1101',100,0],['4-1100',0,99]],
    [['1-1101',0,0],['4-1100',0,0]],
    [['1-1101',110,10],['4-1100',0,100]],
    [['1-1101',-100,0],['4-1100',0,-100]],
    [['1-1101',1.5,0],['4-1100',0,1.5]],
    [['1-1101','100',0],['4-1100',0,100]],
    [['1-1101',Infinity,0],['4-1100',0,Infinity]],
    [['1-1101',NaN,0],['4-1100',0,NaN]],
    [['1-1101',100,0,'C1'],['4-1100',0,100]],
    [['1-1101',100,0,'',2],['4-1100',0,100]],
  ];
  for(const lines of badLines) assert.throws(()=>validateJournal(journal('x','2026-01-01',lines),fixture()));
  assert.throws(()=>validateJournal({...cashIncome(),l:[['1-1101',100,0]]},fixture()),/2 sampai/);
  assert.throws(()=>validateJournal({...cashIncome(),ket:'  '},fixture()),/Keterangan/);
  assert.throws(()=>validateJournal({...cashIncome(),jn:'unknown'},fixture()),/Jenis/);
  assert.throws(()=>validateJournal({...cashIncome(),cashCategory:'Unknown'},fixture()),/Kategori/);
});

test('dates, numeric limits, and duplicate numeric/string journal IDs are rejected', () => {
  for(const tgl of ['2026-02-29','2026-04-31','01-01-2026','1899-12-31']) assert.throws(()=>validateJournal({...cashIncome(),tgl},fixture()),/Tanggal/);
  assert.equal(validateJournal({...cashIncome(),tgl:'2024-02-29'},fixture()).tgl,'2024-02-29');
  assert.throws(()=>validateState({...fixture(),j:[cashIncome(1),cashIncome('1')]}),/duplikat/);
  assert.throws(()=>validateJournal(journal('huge','2026-01-01',[
    ['1-1101',Number.MAX_SAFE_INTEGER,0],['1-1102',1,0],['4-1100',0,Number.MAX_SAFE_INTEGER],['4-2100',0,1]
  ]),fixture()),/Total nominal/);
  for(const closedThrough of [false,null,0,'invalid']) assert.throws(()=>validateState({...fixture(),closedThrough}),/Tanggal kunci/);
});

test('inventory, receivable and payable rows require a valid subledger master', () => {
  for(const code of ['1-1201','2-1101']) for(const contact of ['',undefined,'missing']) {
    assert.throws(()=>validateJournal(journal('bad','2026-01-01',[[code,100,0,contact],['3-1001',0,100]]),fixture()),/kontak/);
  }
  assert.throws(()=>validateJournal(journal('bad','2026-01-01',[['1-2010',100,0,'missing',1],['3-1001',0,100]]),fixture()),/Produk/);
  for(const quantity of [0,-1,0.0000001,1.0000001,NaN,Infinity,'1']) {
    assert.throws(()=>validateJournal(journal('bad','2026-01-01',[['1-2010',100,0,'P1',quantity],['3-1001',0,100]]),fixture()),/Kuantitas/);
  }
});

test('chronological stock ordering is stable, independent of randomized journal IDs', () => {
  const state=fixture();
  trade(state,'purchase','zz-purchase',10,100);
  trade(state,'sale','aa-sale',4,200);
  assert.deepEqual(sorted(state).map(j=>j.id),['zz-purchase','aa-sale']);
  assert.deepEqual(inventory(state)[0],{code:'P1',qty:6,value:600,average:100});
  assert.doesNotThrow(()=>validateJournal({...state.j[0],ket:'Updated purchase description'},state));
  assert.throws(()=>validateState({...state,j:[state.j[1],state.j[0]]}),/Stok/);
  const opening=journal('opening','2026-01-10',[['1-2010',100,0,'P1',1],['3-1001',0,100]],{jn:'A'});
  assert.equal(sorted({...state,j:[...state.j,opening]})[0].id,'opening');
});

test('purchase and sale use moving-average cost and maintain product-specific stock', () => {
  const state=fixture();
  trade(state,'purchase','b1',10,100);
  trade(state,'purchase','b2',10,200);
  trade(state,'sale','s1',8,250);
  const sale=state.j[2];
  assert.deepEqual(sale.l,[['1-1101',2000,0],['4-1100',0,2000],['5-1300',1200,0],['1-2010',0,1200,'P1',8]]);
  assert.deepEqual(inventory(state),[{code:'P1',qty:12,value:1800,average:150},{code:'P2',qty:0,value:0,average:0}]);
  assert.deepEqual(subsidiary(state,'1-2010')[0],{code:'P1',balance:1800,qty:12});
  assert.throws(()=>createTrade(state,{kind:'sale',id:'oversell',date:'2026-01-10',product:'P1',quantity:13,unitPrice:1,paymentAccount:'1-1101'}),/Stok/);
  assert.throws(()=>createTrade(state,{kind:'sale',id:'p2',date:'2026-01-10',product:'P2',quantity:1,unitPrice:1,paymentAccount:'1-1101'}),/Stok/);
});

test('fractional stock uses six decimal units and clears the final remaining Rupiah exactly', () => {
  const state=fixture();
  trade(state,'purchase','micro-buy',0.000003,1_000_000);
  trade(state,'sale','micro-sale',0.000001,2_000_000);
  assert.deepEqual(inventory(state)[0],{code:'P1',qty:0.000002,value:2,average:1_000_000});
  trade(state,'sale','micro-rest',0.000002,2_000_000);
  assert.deepEqual(inventory(state)[0],{code:'P1',qty:0,value:0,average:0});
  const rounding=fixture();
  save(rounding,journal('opening','2026-01-01',[['1-2010',1,0,'P1',3],['3-1001',0,1]],{jn:'A'}));
  trade(rounding,'sale','zero-cost',1,1);
  assert.deepEqual(inventory(rounding)[0],{code:'P1',qty:2,value:1,average:0.5});
  trade(rounding,'sale','rest',2,1);
  assert.deepEqual(inventory(rounding)[0],{code:'P1',qty:0,value:0,average:0});
  assert.equal(balances(rounding)['5-1300'],1);
});

test('historical insertion cannot silently invalidate already-recorded moving-average cost', () => {
  const state=fixture();
  trade(state,'purchase','buy',10,100,{date:'2026-01-01'});
  trade(state,'sale','sell',5,200,{date:'2026-01-10'});
  const snapshot=copy(state);
  assert.throws(()=>createTrade(state,{kind:'purchase',id:'backdated',date:'2026-01-05',product:'P1',quantity:10,unitPrice:200,paymentAccount:'1-1101'}),/HPP.*750/);
  assert.deepEqual(state,snapshot);
  assert.throws(()=>validateState({...state,j:state.j.filter(j=>j.id!=='buy')}),/Stok/);
  const manipulated=copy(state);
  manipulated.j[1].l.find(l=>l[0]==='1-2010')[2]=450;
  manipulated.j[1].l.find(l=>l[0]==='5-1300')[1]=450;
  assert.throws(()=>validateState(manipulated),/HPP.*500/);
  const safe=createTrade(state,{kind:'purchase',id:'same-cost',date:'2026-01-05',product:'P1',quantity:10,unitPrice:100,paymentAccount:'1-1101'});
  assert.doesNotThrow(()=>validateState({...state,j:[...state.j,safe]}));
});

test('editing an earlier sale calculates its original stock position, not later same-day sales', () => {
  const state=fixture();
  trade(state,'purchase','buy',10,100);
  trade(state,'sale','first-sale',6,200);
  trade(state,'sale','second-sale',4,200);
  const edited=createTrade(state,{kind:'sale',id:'first-sale',date:'2026-01-10',product:'P1',quantity:6,unitPrice:250,paymentAccount:'1-1101'});
  assert.equal(edited.l.find(l=>l[0]==='5-1300')[1],600);
  save(state,edited);
  assert.equal(balances(validateState(state))['4-1100'],-2300);
  assert.equal(inventory(state)[0].qty,0);
});

test('credit and partial purchase/sale payments reconcile to contact balances', () => {
  const state=fixture();
  trade(state,'purchase','buy',10,100,{paidAmount:400,contact:'V1'});
  trade(state,'sale','sale',5,200,{paidAmount:250,contact:'C1'});
  assert.deepEqual(subsidiary(state,'2-1101'),[{code:'V1',balance:600,qty:0}]);
  assert.deepEqual(subsidiary(state,'1-1201'),[{code:'C1',balance:750,qty:0}]);
  save(state,journal('receive','2026-01-11',[['1-1101',300,0],['1-1201',0,300,'C1']]));
  save(state,journal('pay','2026-01-11',[['2-1101',200,0,'V1'],['1-1101',0,200]]));
  assert.deepEqual(subsidiary(state,'2-1101'),[{code:'V1',balance:400,qty:0}]);
  assert.deepEqual(subsidiary(state,'1-1201'),[{code:'C1',balance:450,qty:0}]);
  assert.equal(subsidiary(state,'1-1201',{to:'2026-01-10'})[0].balance,750);
  trade(state,'sale','credit',1,200,{paidAmount:0,paymentAccount:'',contact:'C1'});
  assert.equal(state.j.at(-1).l.some(l=>l[0].startsWith('1-11')),false);
  assert.doesNotThrow(()=>validateState(state));
  for(const extra of [{paidAmount:-1},{paidAmount:1001},{paidAmount:1.2},{paidAmount:0,contact:'missing'},{paymentAccount:'3-1001'}]) {
    assert.throws(()=>createTrade(state,{kind:'purchase',id:'bad',date:'2026-01-12',product:'P1',quantity:10,unitPrice:100,paymentAccount:'1-1101',...extra}));
  }
});

function completedJanuary() {
  const state=fixture();
  save(state,journal('opening','2025-12-31',[['1-1101',10000,0],['3-1001',0,10000]],{jn:'A'}));
  trade(state,'purchase','buy1',10,100,{date:'2026-01-01',paidAmount:400,contact:'V1'});
  trade(state,'purchase','buy2',10,200,{date:'2026-01-02'});
  trade(state,'sale','sale',8,250,{date:'2026-01-03',paidAmount:500,contact:'C1'});
  save(state,journal('ar','2026-01-04',[['1-1101',500,0],['1-1201',0,500,'C1']]));
  save(state,journal('ap','2026-01-05',[['2-1101',200,0,'V1'],['1-1101',0,200]]));
  save(state,journal('salary','2026-01-06',[['1-1101',700,0],['4-2100',0,700]]));
  save(state,journal('cost','2026-01-07',[['5-2001',300,0],['1-1101',0,300]]));
  save(state,journal('drawing','2026-01-08',[['3-1002',100,0],['1-1101',0,100]]));
  return validateState(state);
}

test('complete accrual workflow produces independently calculated income, equity and cash flow', () => {
  const state=completedJanuary(),r=reports(state,{from:'2026-01-01',to:'2026-01-31'});
  assert.equal(cell(r.LR,'Penjualan'),2000);
  assert.equal(cell(r.LR,'HPP'),-1200);
  assert.equal(cell(r.LR,'LABA KOTOR'),800);
  assert.equal(r.laba,1200);
  assert.equal(r.aset,11500); // cash 8700 + receivables 1000 + inventory 1800
  assert.equal(r.liab,400);
  assert.equal(r.eq,11100); // capital 10000 + income 1200 - drawings 100
  assert.equal(cell(r.PM,'Modal awal periode'),10000);
  assert.equal(cell(r.PM,'MODAL AKHIR'),11100);
  assert.equal(cell(r.AK,'Kas bersih Operasional'),-1200);
  assert.equal(cell(r.AK,'Kas bersih Pendanaan'),-100);
  assert.equal(cell(r.AK,'Saldo kas awal'),10000);
  assert.equal(cell(r.AK,'SALDO KAS AKHIR'),8700);
  assertChecks(r);
});

test('closing moves profit and drawings once and never doubles current or later income', () => {
  const state=completedJanuary(),before=reports(state,{from:'2026-01-01',to:'2026-01-31'});
  const entries=closingEntries(state,'2026-01-01','2026-01-31');
  assert.equal(entries.length,1);
  assert.deepEqual(entries[0].l.find(l=>l[0]==='3-2001'),['3-2001',0,1100]);
  state.j.push(...entries);
  const closed=validateState(state),after=reports(closed,{from:'2026-01-01',to:'2026-01-31'});
  for(const key of ['LR','PM','AK']) assert.deepEqual(after[key],before[key]);
  assert.equal(after.eq,11100);
  assert.equal(cell(after.NR,'Laba belum ditutup (seluruh periode)'),0);
  assert.equal(balances(closed)['4-1100'],0);
  assert.equal(balances(closed)['3-1002'],0);
  assert.deepEqual(closingEntries(closed,'2026-01-01','2026-01-31'),[]);
  assertChecks(after);
  trade(closed,'sale','feb-sale',4,300,{date:'2026-02-02'});
  const feb=reports(closed,{from:'2026-02-01',to:'2026-02-28'});
  assert.equal(feb.laba,600);
  assert.equal(feb.eq,11700);
  assert.equal(feb.aset,12100);
  assert.equal(cell(feb.PM,'Modal awal periode'),11100);
  assert.equal(cell(feb.AK,'Saldo kas awal'),8700);
  assert.equal(cell(feb.AK,'SALDO KAS AKHIR'),9900);
  assertChecks(feb);
});

test('prior unclosed profit carries into a later balance sheet and opening equity', () => {
  const state=completedJanuary();
  trade(state,'sale','feb-sale',4,300,{date:'2026-02-02'});
  const r=reports(state,{from:'2026-02-01',to:'2026-02-28'});
  assert.equal(r.laba,600);
  assert.equal(cell(r.NR,'Laba belum ditutup (seluruh periode)'),1800);
  assert.equal(cell(r.PM,'Modal awal periode'),11100);
  assert.equal(r.eq,11700);
  assertChecks(r);
  assert.throws(()=>closingEntries(state,'2026-02-01','2026-02-28'),/sebelum awal periode/);
  assert.doesNotThrow(()=>closingEntries(state,'2026-01-01','2026-02-28'));
});

test('all revenue and expense account classes affect net income, including custom accounts', () => {
  const state=fixture();
  state.coa.push(['4-9999','Pendapatan khusus'],['5-9999','Beban khusus']);
  save(state,journal('all-revenue','2026-01-01',[
    ['1-1101',1500,0],['4-1100',0,100],['4-2100',0,200],['4-3100',0,300],['4-3200',0,400],['4-9999',0,500]
  ]));
  save(state,journal('cost','2026-01-02',[['5-9999',100,0],['1-1101',0,100]],{jn:'P'}));
  const r=reports(validateState(state));
  assert.equal(r.laba,1400);
  assert.equal(cell(r.LR,'Penjualan'),100);
  assert.equal(cell(r.LR,'Pendapatan khusus'),500);
  assert.equal(cell(r.LR,'Beban khusus'),-100);
  assert.equal(r.eq,1400);
  assertChecks(r);
  const closing=closingEntries(state,'2026-01-01','2026-01-31')[0];
  assert.deepEqual(closing.l.find(l=>l[0]==='3-2001'),['3-2001',0,1400]);
});

test('cash flow splits compound counterparts, ignores internal transfers, and honors explicit categories', () => {
  const state=fixture();
  save(state,journal('opening','2026-01-01',[['1-1101',10000,0],['3-1001',0,10000]],{jn:'A'}));
  save(state,journal('mixed','2026-01-02',[
    ['1-1101',5000,0],['1-4001',2000,0],['5-2001',300,0],['3-1001',0,4000],['4-1100',0,3300]
  ]));
  save(state,journal('transfer','2026-01-03',[['1-1102',2000,0],['5-3002',10,0],['1-1101',0,2010]]));
  save(state,journal('funding','2026-01-04',[['1-1101',1000,0],['2-1101',0,1000,'V1']],{cashCategory:'Pendanaan'}));
  const r=reports(validateState(state),{from:'2026-01-01',to:'2026-01-31'});
  assert.equal(cell(r.AK,'Kas bersih Operasional'),2990);
  assert.equal(cell(r.AK,'Kas bersih Investasi'),-2000);
  assert.equal(cell(r.AK,'Kas bersih Pendanaan'),5000);
  assert.equal(cell(r.AK,'KENAIKAN (PENURUNAN) KAS'),5990);
  assert.equal(cell(r.AK,'SALDO KAS AKHIR'),15990);
  assertChecks(r);
  assert.throws(()=>reports(state,{from:'2026-02-01',to:'2026-01-01'}),/Tanggal awal/);
});

test('closing rejects forged transfers, stale adjustments, and locked date requests', () => {
  const state=fixture(); state.j=[cashIncome()];
  const forged=journal('fake','2026-01-31',[['4-1100',200,0],['3-2001',0,200]],{jn:'T'});
  assert.throws(()=>validateState({...state,j:[...state.j,forged]}),/penutup/);
  assert.throws(()=>validateJournal(forged,state),/penutup/);
  assert.throws(()=>validateJournal(journal('fake-cash','2026-01-31',[['1-1101',100,0],['3-2001',0,100]],{jn:'T'}),state),/penutup/);
  state.j.push(...closingEntries(state,'2026-01-01','2026-01-31'));
  assert.throws(()=>validateJournal(cashIncome('late','2026-01-20'),state),/penutup/);
  state.closedThrough='2026-01-31';
  assert.throws(()=>closingEntries(state,'2026-01-01','2026-01-31'),/dikunci/);
  assert.throws(()=>createTrade(state,{kind:'purchase',date:'2026-01-01',product:'P1',quantity:1,unitPrice:100,paymentAccount:'1-1101'}),/terkunci/);
});

test('reconciliation preserves valid matches and rejects missing, duplicate, mismatched or noncash matches', () => {
  const state=fixture(); state.j=[cashIncome(1)];
  const line={id:'bank1',date:'2026-01-01',account:'1-1101',description:'Setoran',amount:100,journalId:1};
  state.reconciliation=[line];
  assert.deepEqual(validateState(state).reconciliation,[line]);
  for(const extra of [{amount:99},{account:'4-1100'},{journalId:'missing'}]) {
    assert.throws(()=>validateState({...state,reconciliation:[{...line,...extra}]}));
  }
  assert.throws(()=>validateState({...state,reconciliation:[line,{...line,id:'bank2'}]}),/dua kali/);
  const unmatched={...line,journalId:null,amount:-200};
  assert.deepEqual(validateState({...state,reconciliation:[unmatched]}).reconciliation,[unmatched]);
});

test('date filters and as-of inventory do not leak future balances', () => {
  const state=fixture();
  trade(state,'purchase','buy',10,100,{date:'2026-01-01'});
  trade(state,'sale','sale',4,250,{date:'2026-02-01'});
  assert.deepEqual(inventory(state,{to:'2026-01-31'})[0],{code:'P1',qty:10,value:1000,average:100});
  assert.equal(balances(state,{from:'2026-02-01',to:'2026-02-28'})['4-1100'],-1000);
  assert.equal(reports(state,{to:'2026-01-31'}).laba,0);
  assert.equal(reports(state,{from:'2026-02-01',to:'2026-02-28'}).laba,600);
});
