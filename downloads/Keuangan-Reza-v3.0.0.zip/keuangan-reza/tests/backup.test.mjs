import { test } from 'node:test';
import assert from 'node:assert/strict';
import { encryptBackup, decryptBackup, parseBackup } from '../backup.js';
const state = { j: [], coa: [['1-1101', 'Kas']], prod: [], bantu: [] };
const backup = { format:'keuangan-reza-data', version:1, state, attachments:[{id:'proof',data:'YWJj'}], exportedAt:'2026-10-19T00:00:00Z' };
test('encrypted backup round-trip preserves state and attachments with random nonces', async () => {
  const a = await encryptBackup(backup, 'test-password-backup');
  const b = await encryptBackup(backup, 'test-password-backup');
  assert.notEqual(a.data,b.data); assert.notEqual(a.salt,b.salt);
  assert.deepEqual(await parseBackup(JSON.stringify(a), 'test-password-backup'), backup);
  assert.equal(JSON.stringify(a).includes('proof'),false);
});
test('wrong password and tampering cannot produce restore payload', async () => {
  const a = await encryptBackup(backup,'test-password-backup');
  await assert.rejects(decryptBackup(a,'wrong-password'), /salah|rusak/);
  a.data = (a.data.startsWith('A') ? 'B' : 'A') + a.data.slice(1);
  await assert.rejects(decryptBackup(a,'test-password-backup'), /salah|rusak/);
});
test('legacy raw JSON supported without guessing unknown encrypted format', async () => {
  assert.deepEqual((await parseBackup(JSON.stringify(state))).state,state);
  assert.deepEqual(await parseBackup(JSON.stringify(backup)),backup);
  await assert.rejects(parseBackup('{"format":"old-krb","version":1}'), /tidak didukung/);
  await assert.rejects(parseBackup('{oops'), /bukan JSON/);
});
test('hostile KDF settings and malformed lengths rejected before computation', async () => {
  const a=await encryptBackup(backup,'test-password-backup');
  await assert.rejects(decryptBackup({...a,iterations:999999999},'test-password-backup'),/Parameter/);
  await assert.rejects(decryptBackup({...a,iv:'AA=='},'test-password-backup'),/Struktur/);
  await assert.rejects(encryptBackup(backup,'short'),/minimal/);
});
