import test from 'node:test';
import assert from 'node:assert/strict';
import { emptyState, validateState, reports } from '../accounting.js';
import { makeWorkbook } from '../export.js';

function crc32(bytes) {
  let crc = 0xffffffff;
  for (const byte of bytes) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit++) crc = crc & 1 ? (crc >>> 1) ^ 0xedb88320 : crc >>> 1;
  }
  return (crc ^ 0xffffffff) >>> 0;
}

async function unpack(blob) {
  assert.equal(blob.type, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  const bytes = Buffer.from(await blob.arrayBuffer()), files = new Map();
  let offset = 0;
  while (bytes.readUInt32LE(offset) === 0x04034b50) {
    assert.equal(bytes.readUInt16LE(offset + 8), 0, 'ZIP entries are uncompressed');
    const length = bytes.readUInt32LE(offset + 18), nameLength = bytes.readUInt16LE(offset + 26), extraLength = bytes.readUInt16LE(offset + 28);
    const path = bytes.subarray(offset + 30, offset + 30 + nameLength).toString('utf8');
    const start = offset + 30 + nameLength + extraLength, body = bytes.subarray(start, start + length);
    assert.equal(body.length, length, `ZIP length for ${path}`);
    assert.equal(crc32(body), bytes.readUInt32LE(offset + 14), `ZIP CRC for ${path}`);
    files.set(path, body.toString('utf8'));
    offset = start + length;
  }
  const centralOffset = offset;
  for (const [name] of files) {
    assert.equal(bytes.readUInt32LE(offset), 0x02014b50, 'Central directory entry exists');
    const nameLength = bytes.readUInt16LE(offset + 28), extraLength = bytes.readUInt16LE(offset + 30), commentLength = bytes.readUInt16LE(offset + 32);
    assert.equal(bytes.subarray(offset + 46, offset + 46 + nameLength).toString('utf8'), name);
    assert.equal(bytes.readUInt32LE(bytes.readUInt32LE(offset + 42)), 0x04034b50, 'Central offset points to local header');
    offset += 46 + nameLength + extraLength + commentLength;
  }
  assert.equal(bytes.readUInt32LE(offset), 0x06054b50, 'ZIP end record exists');
  assert.equal(bytes.readUInt16LE(offset + 10), files.size);
  assert.equal(bytes.readUInt32LE(offset + 16), centralOffset);
  assert.equal(bytes.length, offset + 22);
  return files;
}

function xmlText(text) {
  return text.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&');
}

function rows(xml) {
  return [...xml.matchAll(/<row r="(\d+)"[^>]*>(.*?)<\/row>/gs)].map(([, number, inner]) => {
    const cells = {};
    for (const [, column, value] of inner.matchAll(/<c r="([A-Z]+)\d+"[^>]*>(.*?)<\/c>/gs)) {
      const numeric = value.match(/<v>(.*?)<\/v>/s), string = value.match(/<t[^>]*>(.*?)<\/t>/s);
      cells[column] = numeric ? Number(numeric[1]) : xmlText(string?.[1] || '');
    }
    return { number: Number(number), cells };
  });
}

function namedSheets(files) {
  return new Map([...files.get('xl/workbook.xml').matchAll(/<sheet name="([^"]+)" sheetId="(\d+)"/g)].map(([, name, id]) => [xmlText(name), files.get(`xl/worksheets/sheet${id}.xml`)]));
}

function fixture() {
  const state = emptyState(), cash = state.coa.find(([code]) => code.startsWith('1-11'))[0], expense = state.coa.find(([code]) => code.startsWith('5-'))[0];
  state.settings = { ...state.settings, entity: '=SUM(1,2)', notes: 'Catatan <aman> & tetap literal.\nBaris kedua.' };
  state.j = [
    { id: 'opening', tgl: '2026-01-01', jn: 'A', ket: 'Modal awal', l: [[cash, 1000000, 0], ['3-1001', 0, 1000000]], cashCategory: 'Pendanaan' },
    { id: 'revenue', tgl: '2026-02-01', jn: 'U', ket: '=WEBSERVICE("https://invalid.example/")', l: [[cash, 200000, 0], ['4-1100', 0, 200000]], cashCategory: 'Operasional' },
    { id: 'expense', tgl: '2026-02-02', jn: 'U', ket: 'Biaya operasional <utama> & lain', l: [[expense, 50000, 0], [cash, 0, 50000]], cashCategory: 'Operasional' },
    { id: 'future', tgl: '2026-03-01', jn: 'U', ket: 'Di luar periode', l: [[cash, 10000, 0], ['4-1100', 0, 10000]], cashCategory: 'Operasional' },
  ];
  return { state: validateState(state), cash };
}

test('XLSX container has valid checksums, central directory and all report/master sheets', async () => {
  const files = await unpack(makeWorkbook(emptyState()));
  for (const name of ['[Content_Types].xml', '_rels/.rels', 'xl/workbook.xml', 'xl/_rels/workbook.xml.rels', 'xl/styles.xml', 'docProps/core.xml', 'docProps/app.xml']) assert.ok(files.has(name), name);
  const sheets = namedSheets(files);
  assert.deepEqual([...sheets.keys()], ['Jurnal', 'Daftar Akun', 'Neraca Saldo', 'Buku Besar', 'Laba Rugi', 'Neraca', 'Perubahan Modal', 'Arus Kas', 'Validasi Laporan', 'Buku Bantu', 'Persediaan', 'Mutasi Persediaan', 'Kontak', 'Produk', 'Jurnal Penutup', 'Rekonsiliasi', 'Catatan']);
  for (const xml of files.values()) {
    assert.ok(xml.startsWith('<?xml version="1.0"'), 'Every package entry is XML');
    assert.doesNotMatch(xml, /<f(?:\s|>)/, 'Export contains no executable spreadsheet formulas');
  }
  assert.match(sheets.get('Jurnal'), /paperSize="9"/);
});

test('period exports retain prior balances and exclude transactions after the ending date', async () => {
  const { state, cash } = fixture(), period = { from: '2026-02-01', to: '2026-02-28' };
  const sheets = namedSheets(await unpack(makeWorkbook(state, period)));
  const journals = rows(sheets.get('Jurnal')).filter(row => row.number > 5);
  assert.equal(journals.length, 4);
  assert.deepEqual(new Set(journals.map(row => row.cells.A)), new Set(['revenue', 'expense']));
  assert.equal(journals.reduce((sum, row) => sum + row.cells.G, 0), 250000);
  assert.equal(journals.reduce((sum, row) => sum + row.cells.H, 0), 250000);
  const trial = rows(sheets.get('Neraca Saldo')).find(row => row.cells.A === cash).cells;
  assert.deepEqual([trial.C, trial.D, trial.E, trial.F, trial.G, trial.H], [1000000, 0, 200000, 50000, 1150000, 0]);
  const ledger = rows(sheets.get('Buku Besar')).filter(row => row.number > 5 && row.cells.A === cash);
  assert.equal(ledger[0].cells.H, 1000000);
  assert.equal(ledger.at(-1).cells.H, 1150000);
  const report = reports(state, period);
  for (const [sheet, key] of [['Laba Rugi', 'LR'], ['Neraca', 'NR'], ['Perubahan Modal', 'PM'], ['Arus Kas', 'AK']]) {
    const exported = rows(sheets.get(sheet)).filter(row => row.number > 5).map(row => [row.cells.A, row.cells.B]);
    assert.deepEqual(exported, report[key].map(([label, value]) => [label || undefined, value ?? undefined]));
  }
});

test('user text is escaped and stored as literal strings, preserving line breaks', async () => {
  const { state } = fixture(), sheets = namedSheets(await unpack(makeWorkbook(state)));
  const journal = sheets.get('Jurnal');
  assert.match(journal, /t="inlineStr"><is><t xml:space="preserve">=WEBSERVICE\(/);
  assert.match(journal, /Biaya operasional &lt;utama&gt; &amp; lain/);
  assert.equal(rows(journal).find(row => row.number === 2).cells.A, '=SUM(1,2)');
  assert.equal(rows(sheets.get('Catatan')).find(row => row.cells.A === 'Catatan laporan').cells.B, state.settings.notes);
});

test('invalid periods and oversize text fail explicitly instead of corrupting or truncating exports', () => {
  const state = emptyState();
  assert.throws(() => makeWorkbook(state, { from: '2026-02-31' }), /tidak valid/);
  assert.throws(() => makeWorkbook(state, { to: 'not-a-date' }), /tidak valid/);
  assert.throws(() => makeWorkbook(state, { from: '2026-03-01', to: '2026-02-01' }), /Tanggal awal/);
  state.settings.notes = 'x'.repeat(32768);
  assert.throws(() => makeWorkbook(state), /Teks terlalu panjang/);
});
