import { test, expect } from '@playwright/test';
import { mkdir, readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

// Browser writes go only to the disposable database created by playwright.config.mjs.
const password = 'Browser-Only-Owner-4821!';
const readerPassword = 'Browser-Only-Reader-4821!';
const artifactDir = resolve('artifacts/browser');
let ownerCookies = [];
let backupPath;

async function navigate(page, tab) {
  if (await page.getByRole('button', { name: 'Buka navigasi' }).isVisible()) {
    const open = await page.getByRole('button', { name: 'Buka navigasi' }).getAttribute('aria-expanded');
    if (open !== 'true') await page.getByRole('button', { name: 'Buka navigasi' }).click();
  }
  await page.locator(`button[data-tab="${tab}"]`).click();
}

async function book(page) {
  const response = await page.request.get('/api/state');
  expect(response.ok()).toBeTruthy();
  return (await response.json()).state;
}

async function save(page, button, expected = /tersimpan|berhasil|dicatat/i) {
  await page.getByRole('button', { name: button, exact: true }).click();
  await expect(page.locator('#notice')).toContainText(expected);
  await expect(page.locator('body')).not.toHaveAttribute('aria-busy', 'true');
}

async function manualJournal(page, { description, amount, date = '2026-01-01', kind = 'U', debit = '1-1101', credit = '3-1001' }) {
  await navigate(page, 'input');
  await page.getByRole('button', { name: 'Jurnal manual', exact: true }).click();
  await page.getByLabel('Tanggal transaksi', { exact: true }).fill(date);
  await page.getByLabel('Jenis jurnal', { exact: true }).selectOption(kind);
  await page.getByLabel('Keterangan', { exact: true }).fill(description);
  await page.getByLabel('Akun · baris 1', { exact: true }).selectOption(debit);
  await page.locator('#line-debit-0').fill(String(amount));
  await page.getByLabel('Akun · baris 2', { exact: true }).selectOption(credit);
  await page.locator('#line-credit-1').fill(String(amount));
  await save(page, 'Simpan jurnal');
}

test.describe.serial('Pembukuan mandiri melalui browser', () => {
  test.beforeAll(async () => { await mkdir(artifactDir, { recursive: true }); });

  test.beforeEach(async ({ page, context }, testInfo) => {
    const errors = [], externalRequests = [];
    page.on('pageerror', error => errors.push(error.message));
    page.on('request', request => {
      const url = new URL(request.url());
      if (['http:', 'https:'].includes(url.protocol) && url.origin !== 'http://127.0.0.1:3127') externalRequests.push(request.url());
    });
    testInfo.browserErrors = errors;
    testInfo.externalRequests = externalRequests;
    if (ownerCookies.length) await context.addCookies(ownerCookies);
    await page.goto('/');
  });

  test.afterEach(async ({ page }, testInfo) => {
    await expect(page.locator('main')).not.toContainText('NaN');
    expect(testInfo.browserErrors, 'Tidak ada exception JavaScript yang tidak ditangani').toEqual([]);
    expect(testInfo.externalRequests, 'Semua fungsi berjalan tanpa AI, CDN, font, atau layanan eksternal').toEqual([]);
  });

  test('pemilik pertama, validasi formulir, dan sesi bertahan setelah muat ulang', async ({ page, context }) => {
    await expect(page.getByRole('heading', { name: 'Siapkan pembukuan Anda' })).toBeVisible();
    await page.getByRole('button', { name: 'Buat akun & mulai', exact: true }).click();
    await expect(page.locator('#displayName')).toBeFocused();
    expect(await page.locator('#displayName').evaluate(input => input.validity.valueMissing)).toBe(true);
    await page.getByLabel('Nama lengkap', { exact: true }).fill('Pemilik Uji Browser');
    await page.getByLabel('Nama pengguna', { exact: true }).fill('browser_owner');
    await page.getByLabel('Kata sandi', { exact: true }).fill(password);
    await page.getByRole('button', { name: 'Buat akun & mulai', exact: true }).click();
    await expect(page.getByRole('heading', { name: 'Beranda', exact: true })).toBeVisible();
    await expect(page.getByText('Buku Anda siap diisi', { exact: true })).toBeVisible();
    await page.reload();
    await expect(page.getByRole('heading', { name: 'Beranda', exact: true })).toBeVisible();
    expect((await book(page)).j).toHaveLength(0);
    ownerCookies = await context.cookies();
  });

  test('saldo awal disimpan, jurnal tidak seimbang ditolak, dan perubahan/penghapusan tercermin di server', async ({ page }) => {
    await manualJournal(page, { description: 'Modal awal pengujian browser', amount: 1_000_000, kind: 'A' });
    let state = await book(page);
    expect(state.j).toHaveLength(1);
    expect(state.j[0].l).toEqual([['1-1101', 1_000_000, 0], ['3-1001', 0, 1_000_000]]);

    await navigate(page, 'input');
    await page.getByLabel('Keterangan', { exact: true }).fill('Validasi jurnal tidak seimbang');
    await page.getByLabel('Akun · baris 1', { exact: true }).selectOption('5-2001');
    await page.locator('#line-debit-0').fill('1000');
    await page.getByLabel('Akun · baris 2', { exact: true }).selectOption('1-1101');
    await page.locator('#line-credit-1').fill('999');
    await page.getByRole('button', { name: 'Simpan jurnal', exact: true }).click();
    await expect(page.locator('#notice .error')).toContainText(/seimbang|debit.*kredit/i);
    expect((await book(page)).j).toHaveLength(1);
    await page.locator('#line-credit-1').fill('1000');
    await save(page, 'Simpan jurnal');
    await navigate(page, 'journals');
    let article = page.locator('article').filter({ hasText: 'Validasi jurnal tidak seimbang' });
    await article.getByRole('button', { name: 'Ubah', exact: true }).click();
    await expect(page.getByRole('heading', { name: 'Ubah jurnal', exact: true })).toBeVisible();
    await page.getByLabel('Keterangan', { exact: true }).fill('Biaya sementara diubah');
    await save(page, 'Simpan perubahan');
    await navigate(page, 'journals');
    article = page.locator('article').filter({ hasText: 'Biaya sementara diubah' });
    await expect(article).toBeVisible();
    page.once('dialog', dialog => dialog.accept());
    await article.getByRole('button', { name: 'Hapus', exact: true }).click();
    await expect(article).toHaveCount(0);
    state = await book(page);
    expect(state.j.map(journal => journal.ket)).toEqual(['Modal awal pengujian browser']);
  });

  test('kontak, produk, pembelian parsial, penjualan parsial, HPP, dan stok divalidasi', async ({ page }) => {
    await navigate(page, 'settings');
    await page.getByRole('button', { name: 'Data master', exact: true }).click();
    await page.locator('[data-master-kind="bantu"]').click();
    for (const [code, name] of [['SUP-01', 'Pemasok Browser'], ['CUS-01', 'Pelanggan Browser']]) {
      await page.locator('#master-code').fill(code);
      await page.locator('#master-name').fill(name);
      await save(page, 'Tambah data');
    }
    await page.locator('[data-master-kind="prod"]').click();
    await page.locator('#master-code').fill('SKU-01');
    await page.locator('#master-name').fill('Produk Browser');
    await page.locator('#master-price').fill('20000');
    await save(page, 'Tambah data');

    await navigate(page, 'input');
    await page.getByRole('button', { name: 'Pembelian & penjualan', exact: true }).click();
    const trade = page.locator('#trade-form');
    async function tradeEntry(kind, date, quantity, price, paid, contact, description) {
      await navigate(page, 'input');
      await page.getByRole('button', { name: 'Pembelian & penjualan', exact: true }).click();
      await trade.getByLabel('Jenis transaksi', { exact: true }).selectOption(kind);
      await trade.getByLabel('Tanggal', { exact: true }).fill(date);
      await trade.getByLabel('Produk', { exact: true }).selectOption('SKU-01');
      await trade.getByLabel('Kuantitas', { exact: true }).fill(String(quantity));
      await trade.getByLabel('Harga per unit (Rp)', { exact: true }).fill(String(price));
      await trade.getByLabel('Dibayar sekarang (Rp)', { exact: true }).fill(String(paid));
      await trade.getByLabel('Kontak (wajib jika belum lunas)', { exact: true }).selectOption(contact);
      await trade.getByLabel('Keterangan', { exact: true }).fill(description);
    }
    await tradeEntry('purchase', '2026-01-02', 10, 10000, 40000, 'SUP-01', 'Pembelian parsial browser');
    await save(page, 'Catat transaksi dagang');
    let state = await book(page);
    expect(state.j.find(j => j.ket === 'Pembelian parsial browser').l).toEqual([
      ['1-2010', 100000, 0, 'SKU-01', 10], ['1-1101', 0, 40000], ['2-1101', 0, 60000, 'SUP-01'],
    ]);
    await tradeEntry('sale', '2026-01-03', 4, 20000, 30000, 'CUS-01', 'Penjualan parsial browser');
    await save(page, 'Catat transaksi dagang');
    state = await book(page);
    expect(state.j.find(j => j.ket === 'Penjualan parsial browser').l).toEqual([
      ['1-1101', 30000, 0], ['1-1201', 50000, 0, 'CUS-01'], ['4-1100', 0, 80000],
      ['5-1300', 40000, 0], ['1-2010', 0, 40000, 'SKU-01', 4],
    ]);
    await tradeEntry('sale', '2026-01-04', 7, 20000, 0, 'CUS-01', 'Penjualan melebihi stok');
    await page.getByRole('button', { name: 'Catat transaksi dagang', exact: true }).click();
    await expect(page.locator('#notice .error')).toContainText(/stok.*tidak cukup/i);
    expect((await book(page)).j).toHaveLength(3);
    await navigate(page, 'subsidiary');
    const inventory = page.locator('section').filter({ has: page.getByRole('heading', { name: 'Persediaan barang', exact: true }) });
    await expect(inventory.getByRole('row').filter({ hasText: 'SKU-01' }).getByRole('cell')).toHaveText(['SKU-01 · Produk Browser', '6', '60.000', '10.000']);
    await expect(page.getByRole('row').filter({ hasText: 'CUS-01' })).toContainText('50.000');
    await expect(page.getByRole('row').filter({ hasText: 'SUP-01' })).toContainText('60.000');
    await expect(page.getByText('Cocok dengan buku besar', { exact: true })).toHaveCount(2);
  });

  test('laporan nyata, filter periode, perbandingan, ekspor XLSX, dan cetak A4', async ({ page }) => {
    await navigate(page, 'reports');
    await page.getByLabel('Dari tanggal', { exact: true }).fill('2026-01-01');
    await page.getByLabel('Sampai tanggal', { exact: true }).fill('2026-01-31');
    await page.getByRole('button', { name: 'Terapkan periode', exact: true }).click();
    await expect(page.getByRole('row').filter({ has: page.getByRole('cell', { name: 'Penjualan', exact: true }) })).toContainText('80.000');
    await expect(page.getByRole('row').filter({ has: page.getByRole('cell', { name: 'HPP', exact: true }) })).toContainText('(40.000)');
    await expect(page.getByRole('row').filter({ has: page.getByRole('cell', { name: 'LABA (RUGI) BERSIH', exact: true }) })).toContainText('40.000');
    await expect(page.getByRole('row').filter({ has: page.getByRole('cell', { name: 'TOTAL ASET', exact: true }) })).toContainText('1.100.000');
    await expect(page.getByRole('row').filter({ has: page.getByRole('cell', { name: 'TOTAL LIABILITAS + EKUITAS', exact: true }) })).toContainText('1.100.000');
    await expect(page.getByRole('row').filter({ has: page.getByRole('cell', { name: 'SALDO KAS AKHIR', exact: true }) })).toContainText('990.000');
    await expect(page.locator('main')).not.toContainText('NaN');

    await page.getByLabel('Bandingkan dengan periode lain').check();
    await page.getByLabel('Awal pembanding', { exact: true }).fill('2026-01-01');
    await page.getByLabel('Akhir pembanding', { exact: true }).fill('2026-01-02');
    await page.getByRole('button', { name: 'Terapkan pembanding', exact: true }).click();
    const saleRow = page.getByRole('row').filter({ has: page.getByRole('cell', { name: 'Penjualan', exact: true }) });
    await expect(saleRow.getByRole('cell')).toHaveText(['Penjualan', '80.000', '0', '80.000']);
    await page.getByLabel('Bandingkan dengan periode lain').uncheck();

    const downloadPromise = page.waitForEvent('download');
    await page.getByRole('button', { name: '↓ Ekspor Excel', exact: true }).click();
    const download = await downloadPromise;
    expect(download.suggestedFilename()).toMatch(/\.xlsx$/);
    const workbookPath = resolve(artifactDir, 'laporan-browser.xlsx');
    await download.saveAs(workbookPath);
    const bytes = await readFile(workbookPath);
    expect(bytes.subarray(0, 4).toString('hex')).toBe('504b0304');
    expect(bytes.toString('utf8')).toContain('LABA (RUGI) BERSIH');
    expect(bytes.toString('utf8')).toContain('80000');

    await page.getByRole('button', { name: 'Tutup pemberitahuan', exact: true }).click();
    await page.screenshot({ path: resolve(artifactDir, 'laporan-desktop.png'), fullPage: true });
    await page.emulateMedia({ media: 'print' });
    await expect(page.locator('.sidebar')).toBeHidden();
    await expect(page.locator('.topbar')).toBeHidden();
    const pdf = await page.pdf({ path: resolve(artifactDir, 'laporan-a4.pdf'), preferCSSPageSize: true, printBackground: true });
    expect(pdf.subarray(0, 5).toString()).toBe('%PDF-');
    const mediaBox = pdf.toString('latin1').match(/\/MediaBox\s*\[\s*0\s+0\s+([\d.]+)\s+([\d.]+)/);
    expect(mediaBox).not.toBeNull();
    expect(Number(mediaBox[1])).toBeCloseTo(595, -1);
    expect(Number(mediaBox[2])).toBeCloseTo(842, -1);
  });

  test('bukti PDF, cadangan terenkripsi, kata sandi salah, dan pemulihan buku nyata', async ({ page }) => {
    await navigate(page, 'journals');
    const purchase = page.locator('article').filter({ hasText: 'Pembelian parsial browser' });
    await purchase.getByRole('button', { name: 'Bukti', exact: true }).click();
    await page.getByLabel('Tambah PDF, JPEG, atau PNG (maksimal 5 MB)', { exact: true }).setInputFiles(resolve(artifactDir, 'laporan-a4.pdf'));
    await save(page, 'Unggah bukti');
    const proof = page.getByRole('link', { name: 'laporan-a4.pdf', exact: true });
    await expect(proof).toBeVisible();
    const proofDownload = page.waitForEvent('download');
    await proof.click();
    await (await proofDownload).saveAs(resolve(artifactDir, 'bukti-diunduh.pdf'));
    expect(await readFile(resolve(artifactDir, 'bukti-diunduh.pdf'))).toEqual(await readFile(resolve(artifactDir, 'laporan-a4.pdf')));

    const before = await book(page);
    await navigate(page, 'settings');
    await page.getByRole('button', { name: 'Cadangan & pemulihan', exact: true }).click();
    await page.getByLabel('Kata sandi cadangan', { exact: true }).fill(password);
    await page.getByLabel('Ulangi kata sandi cadangan', { exact: true }).fill(password);
    const backupDownload = page.waitForEvent('download');
    await page.getByRole('button', { name: 'Unduh cadangan terenkripsi', exact: true }).click();
    backupPath = resolve(artifactDir, 'buku-uji.encrypted.json');
    await (await backupDownload).saveAs(backupPath);
    const encrypted = await readFile(backupPath, 'utf8');
    expect(JSON.parse(encrypted).cipher).toBe('AES-256-GCM');
    expect(encrypted).not.toContain('Pembelian parsial browser');
    await expect(page.locator('body')).not.toHaveAttribute('aria-busy', 'true');

    await manualJournal(page, { description: 'Perubahan setelah cadangan', amount: 25000, date: '2026-02-01', debit: '5-2001', credit: '1-1101' });
    expect((await book(page)).j).toHaveLength(4);
    await navigate(page, 'settings');
    await page.getByRole('button', { name: 'Cadangan & pemulihan', exact: true }).click();
    await page.getByLabel('File cadangan JSON', { exact: true }).setInputFiles(backupPath);
    await page.getByLabel('Kata sandi jika terenkripsi', { exact: true }).fill('Incorrect-Backup-Password!');
    await page.getByRole('button', { name: 'Periksa & pratinjau', exact: true }).click();
    await expect(page.locator('#notice .error')).toContainText('Kata sandi salah atau cadangan rusak');
    expect((await book(page)).j).toHaveLength(4);
    await page.getByLabel('Kata sandi jika terenkripsi', { exact: true }).fill(password);
    await save(page, 'Periksa & pratinjau');
    await expect(page.getByRole('heading', { name: 'Pratinjau pemulihan', exact: true })).toBeVisible();
    await page.getByLabel('Saya telah memeriksa cadangan dan ingin mengganti buku aktif.').check();
    page.once('dialog', dialog => dialog.accept());
    await save(page, 'Pulihkan buku ini');
    expect(await book(page)).toEqual(before);
    await navigate(page, 'journals');
    await page.locator('article').filter({ hasText: 'Pembelian parsial browser' }).getByRole('button', { name: 'Bukti', exact: true }).click();
    await expect(page.getByRole('link', { name: 'laporan-a4.pdf', exact: true })).toBeVisible();
  });

  test('pelunasan menolak kelebihan bayar dan memperbarui buku bantu', async ({ page }) => {
    await navigate(page, 'input');
    await page.getByRole('button', { name: 'Pelunasan piutang / hutang', exact: true }).click();
    const form = page.locator('#settlement-form');
    await form.getByLabel('Tanggal', { exact: true }).fill('2026-01-05');
    await form.getByLabel('Kontak', { exact: true }).selectOption('CUS-01');
    await form.getByLabel('Nominal (Rp)', { exact: true }).fill('50001');
    await page.getByRole('button', { name: 'Simpan pelunasan', exact: true }).click();
    await expect(page.locator('#notice .error')).toContainText('melebihi saldo piutang');
    expect((await book(page)).j).toHaveLength(3);
    await form.getByLabel('Nominal (Rp)', { exact: true }).fill('50000');
    await form.getByLabel('Keterangan', { exact: true }).fill('Pelunasan pelanggan browser');
    await save(page, 'Simpan pelunasan');
    expect((await book(page)).j).toHaveLength(4);
    await navigate(page, 'subsidiary');
    await expect(page.getByRole('row').filter({ hasText: 'CUS-01' }).getByRole('cell')).toHaveText(['CUS-01', 'Pelanggan Browser', '0']);
  });

  test('impor CSV rekonsiliasi, pencocokan, penutupan dan penguncian periode', async ({ page }) => {
    await navigate(page, 'reconciliation');
    await page.getByLabel('Rekening kas / bank', { exact: true }).selectOption('1-1101');
    await page.getByRole('button', { name: 'Tampilkan rekening', exact: true }).click();
    await page.getByLabel('File CSV (maksimal 2 MB)', { exact: true }).setInputFiles({
      name: 'rekening-browser.csv', mimeType: 'text/csv',
      buffer: Buffer.from('date,description,amount\n2026-01-05,Pelunasan rekening koran,50000\n'),
    });
    await page.getByRole('button', { name: 'Pratinjau CSV', exact: true }).click();
    await expect(page.getByRole('heading', { name: '1 mutasi siap ditambahkan ke 1-1101', exact: true })).toBeVisible();
    await save(page, 'Impor mutasi', /ditambahkan/);
    const before = await book(page);
    const payment = before.j.find(j => j.ket === 'Pelunasan pelanggan browser');
    await page.getByLabel('Jurnal untuk Pelunasan rekening koran', { exact: true }).selectOption(String(payment.id));
    await expect(page.locator('#notice')).toContainText('Pencocokan disimpan');
    await expect(page.getByText('1 / 1 cocok', { exact: true })).toBeVisible();
    expect((await book(page)).j).toHaveLength(4);
    expect((await book(page)).reconciliation[0].journalId).toBe(payment.id);

    await navigate(page, 'closing');
    await page.getByLabel('Dari tanggal (opsional)', { exact: true }).fill('2026-01-01');
    await page.getByLabel('Sampai tanggal', { exact: true }).fill('2026-01-31');
    await page.getByRole('button', { name: 'Pratinjau penutupan', exact: true }).click();
    await expect(page.locator('#closing-preview')).toContainText('Jurnal penutup sebesar');
    page.once('dialog', dialog => dialog.accept());
    await save(page, 'Tutup & kunci periode ini', /ditutup dan dikunci/);
    const after = await book(page);
    expect(after.closedThrough).toBe('2026-01-31');
    expect(after.j).toHaveLength(5);
    expect(after.j.filter(j => j.jn === 'T')).toHaveLength(1);
    await navigate(page, 'journals');
    const article = page.locator('article').filter({ hasText: 'Penjualan parsial browser' });
    await expect(article.getByText('Terkunci', { exact: true })).toBeVisible();
    await expect(article.getByRole('button', { name: 'Ubah', exact: true })).toHaveCount(0);
    await expect(article.getByRole('button', { name: 'Hapus', exact: true })).toHaveCount(0);
    await navigate(page, 'reports');
    await expect(page.getByRole('row').filter({ has: page.getByRole('cell', { name: 'LABA (RUGI) BERSIH', exact: true }) })).toContainText('40.000');
    await expect(page.getByRole('row').filter({ has: page.getByRole('cell', { name: 'TOTAL ASET', exact: true }) })).toContainText('1.100.000');
    await expect(page.getByRole('row').filter({ has: page.getByRole('cell', { name: 'TOTAL LIABILITAS + EKUITAS', exact: true }) })).toContainText('1.100.000');
  });

  test('navigasi layar ponsel dan otorisasi pembaca melalui UI serta API', async ({ page }) => {
    await navigate(page, 'settings');
    await page.getByRole('button', { name: 'Pengguna', exact: true }).click();
    await page.getByLabel('Nama pengguna', { exact: true }).fill('browser_reader');
    await page.getByLabel('Nama tampilan', { exact: true }).fill('Pembaca Uji Browser');
    await page.getByLabel('Kata sandi awal', { exact: true }).fill(readerPassword);
    await page.getByLabel('Peran', { exact: true }).selectOption('reader');
    await save(page, 'Buat pengguna', /ditambahkan/);
    await expect(page.getByRole('row').filter({ hasText: 'browser_reader' })).toContainText('Pembaca');
    await page.getByRole('button', { name: 'Keluar', exact: true }).click();
    await expect(page.getByRole('heading', { name: 'Selamat datang kembali', exact: true })).toBeVisible();
    await expect(page.locator('body')).not.toHaveAttribute('aria-busy', 'true');
    await page.getByLabel('Nama pengguna', { exact: true }).fill('browser_reader');
    await page.getByLabel('Kata sandi', { exact: true }).fill(readerPassword);
    await page.getByRole('button', { name: 'Masuk ke pembukuan', exact: true }).click();
    await expect(page.getByRole('heading', { name: 'Beranda', exact: true })).toBeVisible();
    await page.setViewportSize({ width: 390, height: 844 });
    await expect(page.getByRole('button', { name: 'Buka navigasi', exact: true })).toBeVisible();
    if (await page.getByRole('button', { name: 'Tutup pemberitahuan', exact: true }).isVisible()) await page.getByRole('button', { name: 'Tutup pemberitahuan', exact: true }).click();
    await page.screenshot({ path: resolve(artifactDir, 'beranda-mobile.png'), fullPage: true });
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
    await navigate(page, 'reports');
    await expect(page.getByRole('heading', { name: 'Laporan Keuangan', exact: true })).toBeVisible();
    await page.screenshot({ path: resolve(artifactDir, 'laporan-mobile.png'), fullPage: true });
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
    await navigate(page, 'input');
    await expect(page.getByText('Anda memerlukan peran operator atau pemilik untuk mencatat transaksi.', { exact: true })).toBeVisible();
    await expect(page.locator('#manual-form')).toHaveCount(0);
    await navigate(page, 'settings');
    await expect(page.getByRole('button', { name: 'Pengguna', exact: true })).toHaveCount(0);
    await expect(page.getByRole('button', { name: 'Cadangan & pemulihan', exact: true })).toHaveCount(0);
    const session = await (await page.request.get('/api/session')).json();
    const state = await (await page.request.get('/api/state')).json();
    const forbidden = await page.request.put('/api/state', { headers: { 'x-csrf-token': session.csrfToken }, data: { state: state.state, revision: state.revision } });
    expect(forbidden.status()).toBe(403);
    await page.getByRole('button', { name: 'Keluar', exact: true }).click();
    await expect(page.getByRole('heading', { name: 'Selamat datang kembali', exact: true })).toBeVisible();
    expect((await page.request.get('/api/state')).status()).toBe(401);
  });
});
