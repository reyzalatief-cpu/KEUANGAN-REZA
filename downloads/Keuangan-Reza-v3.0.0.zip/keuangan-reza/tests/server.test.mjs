import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm, readdir, readFile, cp } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { request as httpRequest } from 'node:http';
import { execFile, spawn } from 'node:child_process';
import { promisify } from 'node:util';
import { createApplication } from '../server.mjs';
import { hashPassword, totpCode } from '../server/security.mjs';
import { closingEntries } from '../accounting.js';

const exec = promisify(execFile);
const PASSWORD = 'test-password-only-12345';
const NEW_PASSWORD = 'another-test-password-54321';
const ROOT = resolve(import.meta.dirname, '..');
const journal = (id = 'opening', amount = 100000) => ({ id, tgl: '2026-01-01', jn: 'A', ket: 'Setoran modal', l: [['1-1101', amount, 0], ['3-1001', 0, amount]] });
const pdf = { name: 'bukti.pdf', type: 'application/pdf', data: Buffer.from('%PDF-1.4\nexample evidence\n%%EOF').toString('base64') };

async function fixture(t, options = {}) {
  const dir = await mkdtemp(join(tmpdir(), 'keuangan-server-test-'));
  const app = createApplication({ dataDir: join(dir, 'data'), port: 0, host: '127.0.0.1', appOrigin: '', secureCookies: false, ...options });
  let closed = false;
  const address = await app.listen(), base = `http://127.0.0.1:${address.port}`;
  t.after(async () => { if (!closed) await app.close(); await rm(dir, { recursive: true, force: true }); });
  const client = () => {
    let cookie = '', csrf = '';
    const api = async (path, { method = 'GET', body, headers = {}, raw = false } = {}) => {
      const response = await fetch(base + path, { method, headers: { ...(cookie ? { Cookie: cookie } : {}), ...(csrf ? { 'X-CSRF-Token': csrf } : {}), ...(body === undefined ? {} : { 'Content-Type': 'application/json' }), ...headers }, ...(body === undefined ? {} : { body: typeof body === 'string' ? body : JSON.stringify(body) }) });
      if (response.headers.has('set-cookie')) cookie = response.headers.get('set-cookie').split(';')[0];
      const data = raw ? Buffer.from(await response.arrayBuffer()) : await response.json();
      if (data.csrfToken) csrf = data.csrfToken;
      return { status: response.status, headers: response.headers, data };
    };
    api.credentials = () => ({ Cookie: cookie, 'X-CSRF-Token': csrf });
    return api;
  };
  const owner = client();
  return { dir, app, base, owner, client, close: async () => { await app.close(); closed = true; }, setup: async () => { const r = await owner('/api/setup', { method: 'POST', body: { username: 'owner', password: PASSWORD, displayName: 'Pemilik' } }); assert.equal(r.status, 201, JSON.stringify(r.data)); return r.data; } };
}
async function createUser(f, username, role) {
  const response = await f.owner('/api/users', { method: 'POST', body: { username, role, password: PASSWORD } });
  assert.equal(response.status, 201, JSON.stringify(response.data));
  const api = f.client();
  assert.equal((await api('/api/login', { method: 'POST', body: { username, password: PASSWORD } })).status, 200);
  return { user: response.data.user, api };
}
async function put(api, state, revision) { return api('/api/state', { method: 'PUT', body: { state, revision } }); }

test('initialization, authentication, CSRF, static allowlist and independent local operation', async t => {
  const f = await fixture(t);
  assert.deepEqual((await f.owner('/api/health')).data, { ok: true });
  assert.equal((await f.owner('/api/status')).data.initialized, false);
  assert.equal((await f.owner('/api/state')).status, 401);
  assert.equal((await f.owner('/api/setup', { method: 'POST', body: { username: 'owner', password: 'short' } })).status, 400);
  const setup = await f.setup();
  assert.equal(setup.user.role, 'owner');
  assert.equal('password_hash' in setup.user, false);
  const session = await f.owner('/api/session');
  assert.equal(session.status, 200); assert.match(session.headers.get('content-security-policy'), /script-src 'self'/);
  assert.equal((await f.owner('/api/setup', { method: 'POST', body: { username: 'second', password: PASSWORD } })).status, 409);
  assert.equal((await f.owner('/api/logout', { method: 'POST', headers: { 'X-CSRF-Token': '' } })).status, 403);
  assert.equal((await f.owner('/api/logout', { method: 'POST', headers: { Origin: 'https://evil.example' } })).status, 403);
  for (const path of ['/data/database.sqlite', '/server/security.mjs', '/.env', '/package.json']) assert.equal((await f.owner(path)).status, 404);
  const page = await f.owner('/', { raw: true }); assert.equal(page.status, 200); assert.match(page.data.toString(), /<!DOCTYPE html>/i);
  assert.equal((await f.owner('/api/logout', { method: 'POST' })).status, 200);
  assert.equal((await f.owner('/api/session')).status, 401);
  assert.equal((await f.owner('/api/login', { method: 'POST', body: { username: 'OWNER', password: 'wrong' } })).status, 401);
  const login = await f.owner('/api/login', { method: 'POST', body: { username: 'OWNER', password: PASSWORD } });
  assert.equal(login.status, 200); assert.match(login.headers.get('set-cookie'), /HttpOnly; SameSite=Strict/);
});

test('state validation, owner/operator/reader permissions, conflict detection and journal audit', async t => {
  const f = await fixture(t); await f.setup();
  const operator = await createUser(f, 'operator', 'operator'), reader = await createUser(f, 'reader', 'reader');
  let { state, revision } = (await f.owner('/api/state')).data;
  state.j.push(journal());
  assert.equal((await put(reader.api, state, revision)).status, 403);
  const changed = await put(operator.api, state, revision); assert.equal(changed.status, 200); revision = changed.data.revision;
  assert.equal((await put(f.owner, state, revision - 1)).data.code, 'REVISION_CONFLICT');
  assert.equal((await reader.api('/api/state')).data.state.j.length, 1);
  state.settings.entity = 'Tidak berizin';
  assert.equal((await put(operator.api, state, revision)).status, 403);
  assert.equal((await put(f.owner, state, revision)).status, 200); revision++;
  state.j[0].l[0][1] = 1;
  assert.equal((await put(f.owner, state, revision)).status, 400);
  assert.equal((await f.owner('/api/state')).data.revision, revision);
  assert.equal((await operator.api('/api/users')).status, 403);
  assert.equal((await reader.api('/api/backup')).status, 403);
  assert.equal((await operator.api('/api/audit')).status, 403);
  const events = (await f.owner('/api/audit')).data.events;
  assert.ok(events.some(e => e.action === 'state.updated' && e.detail.journals.some(j => j.id === 'opening' && j.before === null && j.after.l[0][1] === 100000)));
  assert.equal(JSON.stringify(events).includes(PASSWORD), false);
});

test('period locks protect modification, deletion, backdating and attached evidence', async t => {
  const f = await fixture(t); await f.setup();
  let { state, revision } = (await f.owner('/api/state')).data; state.j.push(journal());
  ({ state, revision } = (await put(f.owner, state, revision)).data);
  const uploaded = await f.owner('/api/attachments', { method: 'POST', body: { ...pdf, journalId: 'opening' } }); assert.equal(uploaded.status, 201);
  state.closedThrough = '2026-01-31'; ({ state, revision } = (await put(f.owner, state, revision)).data);
  for (const mutate of [s => { s.j[0].ket = 'Diubah'; }, s => { s.j = []; }, s => { s.j.push(journal('late')); }]) {
    const next = structuredClone(state); mutate(next); assert.equal((await put(f.owner, next, revision)).status, 423);
  }
  assert.equal((await f.owner('/api/attachments', { method: 'POST', body: { ...pdf, journalId: 'opening' } })).status, 423);
  assert.equal((await f.owner(`/api/attachments/${uploaded.data.id}`, { method: 'DELETE' })).status, 423);
  const unlockAndModify = structuredClone(state); unlockAndModify.closedThrough = ''; unlockAndModify.j[0].ket = 'Modified';
  assert.equal((await put(f.owner, unlockAndModify, revision)).status, 400);
  state.closedThrough = ''; ({ state, revision } = (await put(f.owner, state, revision)).data);
  state.j = []; assert.equal((await put(f.owner, state, revision)).status, 200);
  assert.equal((await f.owner('/api/attachments?journalId=opening')).data.attachments.length, 0);
});

test('only owner can create, change or remove closing journals even in an unlocked period', async t => {
  const f = await fixture(t); await f.setup();
  const operator = await createUser(f, 'closing_operator', 'operator');
  let { state, revision } = (await f.owner('/api/state')).data;
  state.j.push({ id: 'income', tgl: '2026-01-01', jn: 'U', ket: 'Pendapatan', l: [['1-1101', 100000, 0], ['4-1100', 0, 100000]] });
  ({ state, revision } = (await put(operator.api, state, revision)).data);
  state.j.push(...closingEntries(state, '2026-01-01', '2026-01-31'));
  assert.equal((await put(operator.api, state, revision)).status, 403);
  const closed = await put(f.owner, state, revision);
  assert.equal(closed.status, 200);
  ({ state, revision } = closed.data);
  assert.equal(state.closedThrough, '');
  const changed = structuredClone(state); changed.j.find(j => j.jn === 'T').ket = 'Penutup ditinjau';
  assert.equal((await put(operator.api, changed, revision)).status, 403);
  const deleted = structuredClone(state); deleted.j = deleted.j.filter(j => j.jn !== 'T');
  assert.equal((await put(operator.api, deleted, revision)).status, 403);
  const reclassified = structuredClone(state); reclassified.j.find(j => j.jn === 'T').jn = 'U';
  assert.equal((await put(operator.api, reclassified, revision)).status, 403);
  assert.equal((await f.owner('/api/state')).data.revision, revision);
  const allowedEdit = await put(f.owner, changed, revision); assert.equal(allowedEdit.status, 200);
  assert.equal((await put(f.owner, deleted, allowedEdit.data.revision)).status, 200);
});

test('attachment validation, authenticated download, backup and atomic restore with snapshot', async t => {
  const f = await fixture(t); await f.setup();
  const reader = await createUser(f, 'reader', 'reader');
  let { state, revision } = (await f.owner('/api/state')).data; state.j.push(journal());
  ({ state, revision } = (await put(f.owner, state, revision)).data);
  for (const bad of [{ ...pdf, data: Buffer.from('HTML').toString('base64') }, { ...pdf, type: 'text/html' }, { ...pdf, name: '../escape.pdf' }, { ...pdf, data: '%%%=' }]) {
    assert.equal((await f.owner('/api/attachments', { method: 'POST', body: { ...bad, journalId: 'opening' } })).status, 400);
  }
  assert.equal((await reader.api('/api/attachments', { method: 'POST', body: { ...pdf, journalId: 'opening' } })).status, 403);
  const uploaded = await f.owner('/api/attachments', { method: 'POST', body: { ...pdf, journalId: 'opening' } }); assert.equal(uploaded.status, 201);
  const download = await reader.api(`/api/attachments/${uploaded.data.id}`, { raw: true });
  assert.equal(download.status, 200); assert.equal(download.data.toString('base64'), pdf.data); assert.match(download.headers.get('content-disposition'), /^attachment;/);
  assert.equal((await f.client()(`/api/attachments/${uploaded.data.id}`)).status, 401);
  const backup = (await f.owner('/api/backup')).data; assert.equal(backup.attachments.length, 1); assert.equal('users' in backup, false);
  const invalid = structuredClone(backup); invalid.state.j[0].l[0][1] = 2;
  assert.equal((await f.owner('/api/restore', { method: 'POST', body: { backup: invalid, revision } })).status, 400);
  assert.equal((await f.owner('/api/restore', { method: 'POST', body: { backup: { ...backup, format: 'unknown' }, revision } })).status, 400);
  assert.equal((await f.owner('/api/state')).data.revision, revision);
  state.j = []; ({ state, revision } = (await put(f.owner, state, revision)).data);
  assert.equal((await f.owner('/api/restore', { method: 'POST', body: { backup, revision: revision - 1 } })).status, 409);
  const restored = await f.owner('/api/restore', { method: 'POST', body: { backup, revision } }); assert.equal(restored.status, 200); assert.equal(restored.data.state.j.length, 1);
  const list = (await f.owner('/api/attachments?journalId=opening')).data.attachments; assert.equal(list.length, 1);
  assert.equal((await f.owner(`/api/attachments/${list[0].id}`, { raw: true })).data.toString('base64'), pdf.data);
  const snapshots = await readdir(join(f.app.dataDir, 'snapshots')); assert.equal(snapshots.length, 1);
  const beforeRestore = JSON.parse(await readFile(join(f.app.dataDir, 'snapshots', snapshots[0]), 'utf8')); assert.equal(beforeRestore.state.j.length, 0);
});

test('user lifecycle protects the last owner, revokes changed roles and validates profile', async t => {
  const f = await fixture(t), me = await f.setup();
  assert.equal((await f.owner(`/api/users/${me.user.id}`, { method: 'PATCH', body: { role: 'reader' } })).status, 400);
  assert.equal((await f.owner(`/api/users/${me.user.id}`, { method: 'PATCH', body: { disabled: true } })).status, 400);
  const operator = await createUser(f, 'operator', 'operator');
  assert.equal((await f.owner(`/api/users/${operator.user.id}`, { method: 'PATCH', body: { role: 'reader' } })).status, 200);
  assert.equal((await operator.api('/api/session')).status, 401);
  assert.equal((await f.owner(`/api/users/${operator.user.id}`, { method: 'PATCH', body: { disabled: true } })).status, 200);
  assert.equal((await operator.api('/api/login', { method: 'POST', body: { username: 'operator', password: PASSWORD } })).status, 401);
  const changed = await f.owner('/api/profile', { method: 'PATCH', body: { displayName: 'Reza', email: 'reza@example.com', phone: '+62 811-222' } }); assert.equal(changed.status, 200); assert.equal(changed.data.user.displayName, 'Reza');
  assert.equal((await f.owner('/api/profile', { method: 'PATCH', body: { email: null } })).status, 400);
  assert.equal((await f.owner('/api/profile', { method: 'PATCH', body: { role: 'owner' } })).status, 400);
  assert.equal((await f.owner('/api/profile', { method: 'PATCH', body: { avatar: 'data:image/svg+xml;base64,PHN2Zz4=' } })).status, 400);
  assert.equal((await f.owner('/api/profile', { method: 'PATCH', body: { email: '' } })).status, 200);
  assert.equal((await f.owner('/api/session')).data.user.phone, '+62 811-222');
});

test('password changes, session revocation and login rate limiting', async t => {
  const f = await fixture(t); await f.setup();
  const other = f.client(); assert.equal((await other('/api/login', { method: 'POST', body: { username: 'owner', password: PASSWORD } })).status, 200);
  assert.equal((await f.owner('/api/password', { method: 'POST', body: { currentPassword: 'bad', newPassword: NEW_PASSWORD } })).status, 403);
  assert.equal((await f.owner('/api/password', { method: 'POST', body: { currentPassword: PASSWORD, newPassword: NEW_PASSWORD } })).status, 200);
  assert.equal((await other('/api/session')).status, 401); assert.equal((await f.owner('/api/session')).status, 200);
  assert.equal((await other('/api/login', { method: 'POST', body: { username: 'owner', password: NEW_PASSWORD } })).status, 200);
  assert.equal((await f.owner('/api/sessions/revoke', { method: 'POST' })).status, 200); assert.equal((await other('/api/session')).status, 401);
  for (let i = 0; i < 12; i++) assert.equal((await other('/api/login', { method: 'POST', body: { username: 'missing', password: 'bad' } })).status, 401);
  assert.equal((await other('/api/login', { method: 'POST', body: { username: 'missing', password: 'bad' } })).status, 429);
});

test('MFA enrollment, TOTP replay prevention, one-use recovery and safe disable', async t => {
  const f = await fixture(t); await f.setup();
  const other = f.client(); assert.equal((await other('/api/login', { method: 'POST', body: { username: 'owner', password: PASSWORD } })).status, 200);
  const setup = await f.owner('/api/mfa/setup', { method: 'POST' }); assert.equal(setup.status, 200); assert.match(setup.data.uri, /^otpauth:\/\/totp\//);
  assert.equal((await f.owner('/api/session')).data.user.mfaEnabled, false);
  assert.equal((await f.owner('/api/mfa/enable', { method: 'POST', body: { code: 'invalid' } })).status, 400);
  const code = totpCode(setup.data.secret), enabled = await f.owner('/api/mfa/enable', { method: 'POST', body: { code } });
  assert.equal(enabled.status, 200); assert.equal(enabled.data.recoveryCodes.length, 10); assert.equal((await other('/api/session')).status, 401);
  assert.equal((await other('/api/login', { method: 'POST', body: { username: 'owner', password: PASSWORD } })).data.code, 'MFA_REQUIRED');
  assert.equal((await other('/api/login', { method: 'POST', body: { username: 'owner', password: PASSWORD, code } })).status, 401);
  const recovery = enabled.data.recoveryCodes;
  assert.equal((await other('/api/login', { method: 'POST', body: { username: 'owner', password: PASSWORD, code: recovery[0] } })).status, 200);
  assert.equal((await f.client()('/api/login', { method: 'POST', body: { username: 'owner', password: PASSWORD, code: recovery[0] } })).status, 401);
  assert.equal((await f.owner('/api/mfa/disable', { method: 'POST', body: { password: 'incorrect', code: recovery[1] } })).status, 403);
  assert.equal((await f.owner('/api/mfa/disable', { method: 'POST', body: { password: PASSWORD, code: recovery[1] } })).status, 200);
  assert.equal((await f.owner('/api/session')).data.user.mfaEnabled, false); assert.equal((await other('/api/session')).status, 401);
  assert.equal(JSON.stringify((await f.owner('/api/audit')).data).includes(setup.data.secret), false);
});

test('explicit reverse proxy origin works while initialization remains local', async t => {
  const f = await fixture(t, { appOrigin: 'https://money.example.test', secureCookies: true });
  // Node fetch normalizes Host to the request URL; raw HTTP is necessary to simulate a proxy.
  const proxyRequest = (path, {method='GET',body,headers={}}={}) => new Promise((resolveResponse,reject) => {
    const payload=body===undefined?undefined:JSON.stringify(body);
    const request=httpRequest(new URL(path,f.base),{method,headers:{...(payload?{'Content-Type':'application/json','Content-Length':Buffer.byteLength(payload)}:{}),...headers}},response=>{
      let text='';response.on('data',chunk=>text+=chunk);response.on('end',()=>resolveResponse({status:response.statusCode,data:JSON.parse(text),headers:new Headers(response.headers)}));
    });request.on('error',reject);request.end(payload);
  });
  const publicHeaders = { Host: 'money.example.test', Origin: 'https://money.example.test' };
  assert.equal((await proxyRequest('/api/status', { headers: publicHeaders })).status, 200);
  assert.equal((await proxyRequest('/api/setup', { method: 'POST', headers: publicHeaders, body: { username: 'owner', password: PASSWORD } })).status, 403);
  await f.setup();
  const login = await proxyRequest('/api/login', { method: 'POST', headers: publicHeaders, body: { username: 'owner', password: PASSWORD } }); assert.equal(login.status, 200); assert.match(login.headers.get('set-cookie'), /; Secure$/);
  assert.equal((await proxyRequest('/api/status', { headers: { Host: 'evil.example' } })).status, 403);
  assert.equal((await proxyRequest('/api/logout', { method: 'POST', headers: { ...publicHeaders, Origin: 'https://evil.example' } })).status, 403);
  assert.throws(() => createApplication({ appOrigin: 'https://money.example.test/', dataDir: join(f.dir, 'bad') }), /APP_ORIGIN/);
  assert.throws(() => createApplication({ appOrigin: 'https://money.example.test', secureCookies: false, dataDir: join(f.dir, 'bad') }), /SECURE_COOKIES/);
  assert.throws(() => createApplication({ host: '0.0.0.0', appOrigin: '', dataDir: join(f.dir, 'external') }), /Inisialisasi/);
});

test('a delayed request cannot mutate after its operator session is revoked', async t => {
  const f = await fixture(t); await f.setup(); const operator = await createUser(f, 'operator', 'operator');
  const { state, revision } = (await f.owner('/api/state')).data; state.j.push(journal());
  const payload = JSON.stringify({ state, revision });
  let finishBody;
  const started = new Promise(resolveStarted => f.app.server.once('request', resolveStarted));
  const response = new Promise((resolveResponse, reject) => {
    const req = httpRequest(f.base + '/api/state', { method: 'PUT', headers: { ...operator.api.credentials(), 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) } }, res => {
      let body = ''; res.setEncoding('utf8'); res.on('data', chunk => { body += chunk; }); res.on('end', () => resolveResponse({ status: res.statusCode, body }));
    }); req.on('error', reject); req.write(payload.slice(0, 10)); finishBody = () => req.end(payload.slice(10));
  });
  await started;
  assert.equal((await f.owner(`/api/users/${operator.user.id}`, { method: 'PATCH', body: { disabled: true } })).status, 200);
  finishBody(); assert.equal((await response).status, 401);
  assert.equal((await f.owner('/api/state')).data.state.j.length, 0);
});

test('login rejects an old password when a password reset happens during verification', async t => {
  const f = await fixture(t); const me = await f.setup(); const nextHash = await hashPassword(NEW_PASSWORD);
  // Change the row after the request enters asynchronous password verification.
  f.app.server.once('request', req => {
    req.once('end', () => setImmediate(() => f.app.db.prepare('UPDATE users SET password_hash=? WHERE id=?').run(nextHash, me.user.id)));
  });
  const response = await f.client()('/api/login', { method: 'POST', body: { username: 'owner', password: PASSWORD } }); assert.equal(response.status, 401);
  assert.equal((await f.client()('/api/login', { method: 'POST', body: { username: 'owner', password: NEW_PASSWORD } })).status, 200);
});

test('persistent book, complete server backup, recovery CLI and restored authentication', async t => {
  const f = await fixture(t); await f.setup(); let { state, revision } = (await f.owner('/api/state')).data; state.j.push(journal());
  assert.equal((await put(f.owner, state, revision)).status, 200);
  const backupDir = join(f.dir, 'server-copy');
  const backupRun = await exec(process.execPath, ['scripts/server-backup.mjs', backupDir], { cwd: ROOT, env: { ...process.env, DATA_DIR: f.app.dataDir } }); assert.match(backupRun.stdout, /tersimpan/);
  assert.deepEqual((await readdir(backupDir)).sort(), ['auth.key', 'backup-info.json', 'database.sqlite']);
  const restoreDir = join(f.dir, 'restored'); await cp(backupDir, restoreDir, { recursive: true });
  const restored = createApplication({ dataDir: restoreDir, port: 0, host: '127.0.0.1', appOrigin: '', secureCookies: false }); const address = await restored.listen();
  try {
    const login = await fetch(`http://127.0.0.1:${address.port}/api/login`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: 'owner', password: PASSWORD }) }); assert.equal(login.status, 200);
    const response = await fetch(`http://127.0.0.1:${address.port}/api/state`, { headers: { Cookie: login.headers.get('set-cookie').split(';')[0] } }); assert.equal((await response.json()).state.j.length, 1);
  } finally { await restored.close(); }
  await f.close();
  const recovery = await new Promise((resolveRecovery, reject) => {
    const child = spawn(process.execPath, ['scripts/reset-owner.mjs', 'owner', '--disable-mfa'], { cwd: ROOT, env: { ...process.env, DATA_DIR: f.app.dataDir }, stdio: ['pipe', 'pipe', 'pipe'] }); let output = '';
    child.stdout.on('data', chunk => { output += chunk; }); child.stderr.on('data', chunk => { output += chunk; }); child.on('error', reject); child.on('close', code => resolveRecovery({ code, output })); child.stdin.end(NEW_PASSWORD + '\n');
  }); assert.equal(recovery.code, 0, recovery.output);
  const restarted = createApplication({ dataDir: f.app.dataDir, port: 0, host: '127.0.0.1', appOrigin: '', secureCookies: false }); const restartedAddress = await restarted.listen();
  try {
    const base = `http://127.0.0.1:${restartedAddress.port}`;
    assert.equal((await fetch(base + '/api/session', { headers: f.owner.credentials() })).status, 401);
    const response = await fetch(base + '/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: 'owner', password: NEW_PASSWORD }) }); assert.equal(response.status, 200);
    const saved = await fetch(base + '/api/state', { headers: { Cookie: response.headers.get('set-cookie').split(';')[0] } }); assert.equal((await saved.json()).state.j[0].id, 'opening');
  } finally { await restarted.close(); }
});
