/** Portable encrypted backup format. Runs in modern browsers and Node 24. */
const FORMAT = 'keuangan-reza-encrypted';
const DATA_FORMAT = 'keuangan-reza-data';
const ITERATIONS = 310_000;
const MAX_BYTES = 48 * 1024 * 1024;
const encoder = new TextEncoder();
const decoder = new TextDecoder('utf-8', { fatal: true });
const aad = encoder.encode(`${FORMAT}:1`);
function bytesToBase64(bytes) {
  let binary = '';
  for (let i = 0; i < bytes.length; i += 32768) binary += String.fromCharCode(...bytes.subarray(i, i + 32768));
  return btoa(binary);
}
function base64ToBytes(value, max) {
  if (typeof value !== 'string' || value.length > Math.ceil(max / 3) * 4 || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(value)) throw new Error('Struktur cadangan terenkripsi tidak valid.');
  const bytes = Uint8Array.from(atob(value), c => c.charCodeAt(0));
  if (bytes.length > max) throw new Error('Cadangan terlalu besar.');
  return bytes;
}
function checkPassword(password, creating = false) {
  if (typeof password !== 'string' || !password || password.length > 1024 || (creating && password.length < 12)) throw new Error(creating ? 'Kata sandi cadangan minimal 12 karakter.' : 'Masukkan kata sandi cadangan.');
}
async function keyFor(password, salt, iterations) {
  const key = await crypto.subtle.importKey('raw', encoder.encode(password), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations }, key, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
}
function normalizeData(data) {
  if (!data || typeof data !== 'object' || Array.isArray(data)) throw new Error('Format data cadangan tidak didukung.');
  if (data.format === DATA_FORMAT && data.version === 1 && data.state && Array.isArray(data.state.j) && Array.isArray(data.attachments)) return data;
  // The exact legacy JSON schema in the checked-out repository; no guessed KRB codecs.
  if (!data.format && Array.isArray(data.j) && Array.isArray(data.coa)) return { format: DATA_FORMAT, version: 1, state: data, attachments: [], exportedAt: null };
  throw new Error('Format cadangan tidak didukung. JSON dari repository lama didukung; .krb aplikasi lain memerlukan format sumber yang sesuai. Buku aktif belum diubah.');
}
export async function encryptBackup(backup, password) {
  checkPassword(password, true);
  normalizeData(backup);
  const raw = encoder.encode(JSON.stringify(backup));
  if (raw.length > MAX_BYTES) throw new Error('Cadangan melebihi batas 48 MiB. Gunakan cadangan database server.');
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const key = await keyFor(password, salt, ITERATIONS);
  const encrypted = await crypto.subtle.encrypt({ name: 'AES-GCM', iv, additionalData: aad, tagLength: 128 }, key, raw);
  return { format: FORMAT, version: 1, cipher: 'AES-256-GCM', kdf: 'PBKDF2-SHA256', iterations: ITERATIONS, salt: bytesToBase64(salt), iv: bytesToBase64(iv), data: bytesToBase64(new Uint8Array(encrypted)) };
}
export async function decryptBackup(envelope, password) {
  checkPassword(password);
  if (!envelope || envelope.format !== FORMAT || envelope.version !== 1 || envelope.cipher !== 'AES-256-GCM' || envelope.kdf !== 'PBKDF2-SHA256') throw new Error('Format cadangan terenkripsi tidak didukung.');
  if (!Number.isInteger(envelope.iterations) || envelope.iterations < ITERATIONS || envelope.iterations > 1_000_000) throw new Error('Parameter enkripsi cadangan tidak didukung.');
  const salt = base64ToBytes(envelope.salt, 16), iv = base64ToBytes(envelope.iv, 12), data = base64ToBytes(envelope.data, MAX_BYTES + 16);
  if (salt.length !== 16 || iv.length !== 12 || data.length < 16) throw new Error('Struktur cadangan terenkripsi tidak valid.');
  const key = await keyFor(password, salt, envelope.iterations);
  let decoded;
  try {
    const raw = await crypto.subtle.decrypt({ name: 'AES-GCM', iv, additionalData: aad, tagLength: 128 }, key, data);
    decoded = JSON.parse(decoder.decode(raw));
  } catch { throw new Error('Kata sandi salah atau cadangan rusak. Buku aktif belum diubah.'); }
  return normalizeData(decoded);
}
export async function parseBackup(text, password) {
  if (typeof text !== 'string' || text.length > Math.ceil(MAX_BYTES * 1.5)) throw new Error('File cadangan terlalu besar.');
  let data;
  try { data = JSON.parse(text); } catch { throw new Error('File bukan JSON cadangan yang valid. Format .krb lama belum dapat diverifikasi tanpa spesifikasi sumber.'); }
  return data?.format === FORMAT ? decryptBackup(data, password) : normalizeData(data);
}
