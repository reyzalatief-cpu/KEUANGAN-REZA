@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 (
  echo Node.js belum ditemukan. Pasang Node.js 24.13 atau versi 24.x yang lebih baru.
  pause
  exit /b 1
)
node scripts\start-local.mjs
set "REZA_EXIT=%ERRORLEVEL%"
if not "%REZA_EXIT%"=="0" pause
exit /b %REZA_EXIT%
