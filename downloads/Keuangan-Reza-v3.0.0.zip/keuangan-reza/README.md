# Keuangan Reza

Aplikasi pembukuan berbahasa Indonesia yang berjalan pada server Anda sendiri. Antarmuka menggunakan JavaScript standar; server menggunakan Node.js dan SQLite. Fungsi normal tidak memerlukan ChatGPT, Claude, API AI, akun platform pembuat aplikasi, atau CDN.

## Mulai di komputer sendiri

Cara praktis: ikuti [MULAI-DI-SINI.md](MULAI-DI-SINI.md). Di Windows, klik `MULAI-WINDOWS.cmd`; di Linux/macOS, jalankan `bash mulai.sh`. Launcher memeriksa Node dan membuat `.env` hanya jika belum ada.

Persyaratan: **Node.js 24.13 atau versi 24.x yang lebih baru**, npm, dan browser modern. Gunakan Node.js versi LTS yang masih didukung. Tidak perlu memasang database terpisah atau membeli layanan eksternal.

```sh
cp .env.example .env
npm start
```

Jalankan dari folder proyek. Tidak ada paket npm runtime yang perlu diunduh. Pada Windows PowerShell, ganti perintah salin dengan `Copy-Item .env.example .env`. Jika `.env` sudah ada, periksa dan sesuaikan file tersebut; jangan menimpanya dengan contoh.

1. Buka `http://127.0.0.1:3000` pada komputer yang menjalankan server.
2. Buat akun pemilik dengan nama pengguna dan kata sandi Anda sendiri. Tidak ada akun atau kata sandi bawaan.
3. Lengkapi nama pembukuan, daftar akun, kontak, produk, dan saldo awal. Buku baru tidak berisi transaksi contoh atau saldo rekaan.
4. Tambahkan akun pengguna lain dari pengaturan akses jika diperlukan. Gunakan peran Pembaca untuk akses laporan saja.
5. Buat cadangan sebelum mengimpor data atau melakukan penutupan periode.

Hentikan server dengan **Ctrl+C**. Jalankan kembali menggunakan `npm start`; data tetap berada di folder `data/`. Jangan menghapus folder tersebut saat memperbarui kode.

Aplikasi hanya mendengarkan `127.0.0.1` secara bawaan. Pembuatan pemilik pertama harus dilakukan dalam mode lokal; petunjuk akses dari HP atau internet ada pada [panduan operasi](docs/operations.md).

## Alur pembukuan

- Kelola COA, kontak, produk, dan rekening bank/e-wallet. Kode akun lama dipertahankan; akun yang sudah dipakai tidak boleh dihapus sembarangan.
- Catat saldo awal, jurnal umum dan penyesuaian, atau gunakan transaksi pembelian/penjualan. Debit dan kredit harus seimbang.
- Periksa jurnal, buku besar, buku bantu, neraca saldo, laporan, serta kontrol keseimbangan sebelum menutup periode.
- Gunakan filter periode, catatan laporan dan pembanding untuk meninjau hasil. Ekspor Excel atau cetak/simpan PDF memakai kertas A4.
- Kelola bukti transaksi, rekonsiliasi, akses pengguna, MFA, riwayat perubahan, cadangan dan pemulihan melalui aplikasi.

Asumsi dasar: pencatatan akrual, Rupiah bulat, persediaan perpetual rata-rata bergerak, dan kuantitas maksimal enam desimal. PPN, retur otomatis dan akuntansi valuta asing tidak diaktifkan. Koreksi/retur dapat dicatat melalui jurnal manual dengan referensi transaksi asal dan nilai persediaan yang memenuhi validasi. Penambahan laporan tidak dengan sendirinya membuktikan kepatuhan penuh SAK EMKM/PSAK. [Ruang lingkup dan sumber kebutuhan](docs/requirements.md) menjelaskan keputusan dan keterbatasannya.

## Data lama dan cadangan

Cadangan JSON dari aplikasi HTML dalam repository dapat diperiksa sebelum dipulihkan. Jika data browser versi lama tersedia pada origin yang sama, gunakan tawaran migrasi di aplikasi; penyimpanan lama tidak dihapus otomatis. Untuk origin atau komputer berbeda, ekspor JSON dari versi lama dahulu.

**Berkas `.krb` dari situs lama dalam PDF belum tersedia**, dan format enkripsi/payload aslinya belum diketahui. Dukungan cadangan aplikasi ini tidak membuktikan kompatibilitas dengan `.krb` tersebut. Jangan mengganti nama ekstensi untuk memaksa impor atau menghapus data sumber. Pemulihan harus ditinjau sebelum mengganti buku.

Cadangan pembukuan dari aplikasi dan cadangan server memiliki fungsi berbeda: cadangan pembukuan memindahkan buku beserta bukti; cadangan server juga mempertahankan akun dan konfigurasi autentikasi. Lihat [backup dan pemulihan](docs/operations.md#backup-dan-pemulihan).

## Pengembangan, pengujian dan distribusi

```sh
npm ci
npm run check
npm run test:unit
npm run test:integration
npm run test:e2e
npm test
npm run build
```

Tes browser memakai Playwright sebagai dependensi pengembangan. Bila browser uji belum terpasang, jalankan `npx playwright install chromium`. Dependensi runtime aplikasi tidak memakai paket npm tambahan; dependensi pengembangan diperlukan untuk menjalankan tes.

`npm run build` menghasilkan folder `dist/keuangan-reza/` dan arsip `dist/keuangan-reza-v3.0.0.zip`, tanpa data pengguna atau kredensial. Gunakan hasil build bersama Node.js, bukan dengan membuka HTML melalui `file://`. Aplikasi memerlukan server untuk login dan penyimpanan. Hasil eksekusi yang benar-benar dilakukan, termasuk batas pengujian, dicatat pada [laporan validasi](docs/validation.md).

[README ini](README.md) menjelaskan penggunaan lokal; [panduan operasi](docs/operations.md) mencakup HTTPS, Docker, pemulihan pemilik, pemeliharaan dan pemasangan di HP. Konfigurasi cloud development yang disimpan untuk ditinjau berbeda dari deployment aplikasi; meninjau konfigurasi itu tidak otomatis membuat situs publik.
