import { reports, inventory, subsidiary, sorted } from './accounting.js';

const XLSX_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
const XML_DECL = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
const encoder = new TextEncoder();
const JOURNAL_NAMES = { A: 'Saldo awal', U: 'Umum', P: 'Penyesuaian', T: 'Penutup' };

function xml(value) {
  return String(value ?? '').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\ufffe\uffff]/g, '')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&apos;');
}

function columnName(index) {
  let result = '';
  for (let n = index + 1; n > 0; n = Math.floor((n - 1) / 26)) result = String.fromCharCode(65 + (n - 1) % 26) + result;
  return result;
}

function dateOption(value, label) {
  if (!value) return '';
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value) || !Number.isFinite(Date.parse(value)) || new Date(value).toISOString().slice(0, 10) !== value) {
    throw new Error(`${label} ekspor tidak valid.`);
  }
  return value;
}

function worksheet({ rows, filter = true, widths }) {
  if (rows.length > 1048576) throw new Error('Jumlah baris melebihi batas Excel. Pilih periode yang lebih pendek.');
  const columns = Math.max(1, ...rows.slice(0, 100).map(row => row.length));
  const lastCell = `${columnName(columns - 1)}${rows.length}`;
  const dimensions = Array.from({ length: columns }, (_, i) => {
    const inferred = Math.max(14, ...rows.slice(4, 104).map(row => Math.min(55, String(row[i]?.value ?? row[i] ?? '').length + 2)));
    return `<col min="${i + 1}" max="${i + 1}" width="${widths?.[i] ?? inferred}" customWidth="1"/>`;
  }).join('');
  const sheetRows = rows.map((row, rowIndex) => {
    const cells = row.map((entry, columnIndex) => {
      const object = entry !== null && typeof entry === 'object';
      const value = object ? entry.value : entry;
      if (value === undefined || value === null || value === '') return '';
      const style = object && entry.style !== undefined ? entry.style : typeof value === 'number' ? 3 : 0;
      const address = `${columnName(columnIndex)}${rowIndex + 1}`;
      if (typeof value === 'number') {
        if (!Number.isFinite(value)) throw new Error('Ekspor dibatalkan karena terdapat nilai angka yang tidak valid.');
        return `<c r="${address}" s="${style}"><v>${value}</v></c>`;
      }
      // All text is an inline string, never a formula, even when it starts with =, +, - or @.
      if (String(value).length > 32767) throw new Error('Teks terlalu panjang untuk satu sel Excel (maksimal 32.767 karakter). Persingkat catatan sebelum ekspor.');
      return `<c r="${address}" s="${style}" t="inlineStr"><is><t xml:space="preserve">${xml(value)}</t></is></c>`;
    }).join('');
    return `<row r="${rowIndex + 1}"${rowIndex === 0 ? ' ht="26" customHeight="1"' : ''}>${cells}</row>`;
  }).join('');
  return XML_DECL + `<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetPr><pageSetUpPr fitToPage="1"/></sheetPr><dimension ref="A1:${lastCell}"/><sheetViews><sheetView workbookViewId="0"><pane ySplit="5" topLeftCell="A6" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><sheetFormatPr defaultRowHeight="15"/><cols>${dimensions}</cols><sheetData>${sheetRows}</sheetData>${filter && rows.length > 5 ? `<autoFilter ref="A5:${lastCell}"/>` : ''}<printOptions horizontalCentered="1"/><pageMargins left="0.25" right="0.25" top="0.5" bottom="0.5" header="0.2" footer="0.2"/><pageSetup paperSize="9" orientation="landscape" fitToWidth="1" fitToHeight="0"/></worksheet>`;
}

const STYLES = XML_DECL + `<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><numFmts count="1"><numFmt numFmtId="164" formatCode="#,##0.######;[Red](#,##0.######);&quot;-&quot;"/></numFmts><fonts count="3"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="16"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFE5EDF5"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="7"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/><xf numFmtId="0" fontId="2" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"><alignment wrapText="1"/></xf><xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="164" fontId="2" fillId="0" borderId="0" xfId="0" applyNumberFormat="1" applyFont="1"/><xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1"/><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`;

const CRC_TABLE = Uint32Array.from({ length: 256 }, (_, byte) => {
  let value = byte;
  for (let bit = 0; bit < 8; bit++) value = value & 1 ? 0xedb88320 ^ (value >>> 1) : value >>> 1;
  return value >>> 0;
});

function crc32(data) {
  let value = 0xffffffff;
  for (const byte of data) value = CRC_TABLE[(value ^ byte) & 0xff] ^ (value >>> 8);
  return (value ^ 0xffffffff) >>> 0;
}

function zip(files) {
  const pieces = [], directory = [];
  let offset = 0;
  for (const [path, contents] of files) {
    const name = encoder.encode(path), body = encoder.encode(contents), crc = crc32(body);
    if (offset + body.length > 0xffffffff) throw new Error('Ukuran ekspor melebihi batas ZIP. Pilih periode yang lebih pendek.');
    const header = new Uint8Array(30 + name.length), h = new DataView(header.buffer);
    h.setUint32(0, 0x04034b50, true); h.setUint16(4, 20, true); h.setUint16(6, 0x0800, true);
    h.setUint16(12, 33, true); // 1980-01-01, a valid DOS date.
    h.setUint32(14, crc, true); h.setUint32(18, body.length, true); h.setUint32(22, body.length, true);
    h.setUint16(26, name.length, true); header.set(name, 30);
    const central = new Uint8Array(46 + name.length), c = new DataView(central.buffer);
    c.setUint32(0, 0x02014b50, true); c.setUint16(4, 20, true); c.setUint16(6, 20, true); c.setUint16(8, 0x0800, true);
    c.setUint16(14, 33, true); c.setUint32(16, crc, true); c.setUint32(20, body.length, true); c.setUint32(24, body.length, true);
    c.setUint16(28, name.length, true); c.setUint32(42, offset, true); central.set(name, 46);
    pieces.push(header, body); directory.push(central); offset += header.length + body.length;
  }
  const centralSize = directory.reduce((sum, chunk) => sum + chunk.length, 0);
  const end = new Uint8Array(22), e = new DataView(end.buffer);
  e.setUint32(0, 0x06054b50, true); e.setUint16(8, files.length, true); e.setUint16(10, files.length, true);
  e.setUint32(12, centralSize, true); e.setUint32(16, offset, true);
  return new Blob([...pieces, ...directory, end], { type: XLSX_TYPE });
}

/** Export a self-contained Excel workbook. No network, third-party scripts, or AI service is used. */
export function makeWorkbook(state, options = {}) {
  const from = dateOption(options.from, 'Tanggal awal'), to = dateOption(options.to, 'Tanggal akhir');
  if (from && to && from > to) throw new Error('Tanggal awal ekspor harus sebelum atau sama dengan tanggal akhir.');
  const period = { ...(from ? { from } : {}), ...(to ? { to } : {}) };
  const asOf = to ? { to } : {};
  const periodLabel = `Periode: ${from || 'Awal pembukuan'} s.d. ${to || 'Seluruh tanggal'} | Mata uang: Rupiah (Rp)`;
  const entity = state.settings?.entity || 'Keuangan Reza';
  const accountNames = new Map(state.coa), contactNames = new Map(state.bantu), productNames = new Map(state.prod.map(([code, name]) => [code, name]));
  const allJournals = sorted(state).filter(journal => !to || journal.tgl <= to);
  const journals = allJournals.filter(journal => !from || journal.tgl >= from);
  const sheets = [];
  function add(name, headers, body, config = {}) {
    sheets.push({ name, rows: [[{ value: name, style: 1 }], [entity], [periodLabel], [], headers.map(value => ({ value, style: 2 })), ...body], ...config });
  }
  const lines = journals.flatMap(journal => journal.l.map(line => ({ journal, line })));
  add('Jurnal', ['ID', 'Tanggal', 'Jenis', 'Keterangan', 'Kode akun', 'Nama akun', 'Debit', 'Kredit', 'Kode bantu', 'Nama bantu', 'Kuantitas', 'Kategori kas', 'Referensi'], lines.map(({ journal: j, line: l }) => [
    String(j.id), j.tgl, JOURNAL_NAMES[j.jn] || j.jn, j.ket, l[0], accountNames.get(l[0]) || '', l[1], l[2], l[3] || '', contactNames.get(l[3]) || productNames.get(l[3]) || '', l[4] ?? '', j.cashCategory || '', j.reference || '',
  ]));
  add('Daftar Akun', ['Kode', 'Nama akun', 'Golongan'], state.coa.map(([code, name]) => [code, name, ({ 1: 'Aset', 2: 'Liabilitas', 3: 'Ekuitas', 4: 'Pendapatan', 5: 'Beban' })[code[0]] || '']));

  const opening = new Map(), movement = new Map(), ledger = new Map();
  for (const j of allJournals) for (const l of j.l) {
    if (from && j.tgl < from) opening.set(l[0], (opening.get(l[0]) || 0) + l[1] - l[2]);
    else {
      const totals = movement.get(l[0]) || [0, 0];
      totals[0] += l[1]; totals[1] += l[2]; movement.set(l[0], totals);
      const entries = ledger.get(l[0]) || []; entries.push({ j, l }); ledger.set(l[0], entries);
    }
  }
  const trial = [], book = [], totals = Array(6).fill(0);
  for (const [code, name] of state.coa) {
    const start = opening.get(code) || 0, moves = movement.get(code) || [0, 0], end = start + moves[0] - moves[1];
    const values = [Math.max(start, 0), Math.max(-start, 0), ...moves, Math.max(end, 0), Math.max(-end, 0)];
    values.forEach((value, i) => { totals[i] += value; }); trial.push([code, name, ...values]);
    let running = start;
    book.push([code, name, '', '', 'Saldo sebelum periode', 0, 0, running]);
    for (const { j, l } of ledger.get(code) || []) {
      running += l[1] - l[2]; book.push([code, name, j.tgl, String(j.id), j.ket, l[1], l[2], running]);
    }
  }
  trial.push([{ value: 'TOTAL', style: 5 }, '', ...totals.map(value => ({ value, style: 4 }))]);
  add('Neraca Saldo', ['Kode', 'Nama akun', 'Awal debit', 'Awal kredit', 'Mutasi debit', 'Mutasi kredit', 'Akhir debit', 'Akhir kredit'], trial);
  add('Buku Besar', ['Kode akun', 'Nama akun', 'Tanggal', 'ID jurnal', 'Keterangan', 'Debit', 'Kredit', 'Saldo (debit positif)'], book);

  const result = reports(state, period);
  for (const [name, key] of [['Laba Rugi', 'LR'], ['Neraca', 'NR'], ['Perubahan Modal', 'PM'], ['Arus Kas', 'AK']]) {
    add(name, ['Uraian', 'Jumlah (Rp)'], result[key].map(([label, value, bold]) => [{ value: label, style: bold ? 5 : 0 }, { value, style: bold ? 4 : 3 }]), { filter: false, widths: [65, 24] });
  }
  add('Validasi Laporan', ['Pemeriksaan', 'Hasil'], (result.chk || []).map(([label, valid]) => [label, valid ? 'Sesuai' : 'Perlu diperiksa']), { widths: [65, 24] });
  const subsidiaryRows = [];
  for (const code of ['1-1201', '2-1101']) for (const entry of subsidiary(state, code, asOf)) {
    subsidiaryRows.push([code, accountNames.get(code) || '', entry.code, contactNames.get(entry.code) || '', entry.balance, entry.qty ?? '']);
  }
  add('Buku Bantu', ['Kode akun', 'Nama akun', 'Kode kontak', 'Nama kontak', 'Saldo', 'Kuantitas'], subsidiaryRows);
  const stock = inventory(state, asOf);
  add('Persediaan', ['Kode produk', 'Nama produk', 'Kuantitas', 'Nilai (Rp)', 'Rata-rata per unit (Rp)'], stock.map(item => [item.code, productNames.get(item.code) || '', item.qty, item.value, item.average]));
  add('Mutasi Persediaan', ['Tanggal', 'ID jurnal', 'Keterangan', 'Kode produk', 'Nama produk', 'Kuantitas', 'Debit', 'Kredit'], lines.filter(({ line }) => line[0] === '1-2010').map(({ journal: j, line: l }) => [j.tgl, String(j.id), j.ket, l[3] || '', productNames.get(l[3]) || '', l[4] ?? '', l[1], l[2]]));
  add('Kontak', ['Kode', 'Nama'], state.bantu);
  add('Produk', ['Kode', 'Nama', 'Harga referensi (Rp)'], state.prod);
  add('Jurnal Penutup', ['ID', 'Tanggal', 'Keterangan', 'Kode akun', 'Nama akun', 'Debit', 'Kredit'], lines.filter(({ journal }) => journal.jn === 'T').map(({ journal: j, line: l }) => [String(j.id), j.tgl, j.ket, l[0], accountNames.get(l[0]) || '', l[1], l[2]]));
  add('Rekonsiliasi', ['No.', 'Data rekonsiliasi'], (state.reconciliation || []).map((entry, i) => [i + 1, { value: typeof entry === 'string' ? entry : JSON.stringify(entry), style: 6 }]), { widths: [10, 110] });
  add('Catatan', ['Bagian', 'Isi'], [
    ['Nama entitas', entity], ['Periode mulai', from || 'Awal pembukuan'], ['Periode akhir', to || 'Seluruh tanggal'], ['Buku dikunci sampai', state.closedThrough || 'Belum dikunci'],
    ['Catatan laporan', { value: state.settings?.notes || 'Belum ada catatan.', style: 6 }],
    ['Dasar laporan', { value: 'Angka menggunakan Rupiah. Neraca, buku bantu, dan persediaan menunjukkan posisi sampai tanggal akhir. Laba rugi dan arus kas menggunakan periode terpilih. Neraca saldo serta buku besar mencakup jurnal saldo awal, umum, penyesuaian, dan penutup; saldo debit bertanda positif. Jurnal penutup tidak dihitung sebagai pendapatan, beban, atau arus kas periode.', style: 6 }],
    ['Penggunaan ekspor', { value: 'Berkas ini adalah laporan, bukan cadangan untuk pemulihan. Gunakan menu cadangan untuk menyimpan data beserta lampiran dan memulihkannya. Teks diekspor sebagai teks literal untuk mencegah rumus yang tidak diinginkan.', style: 6 }],
  ], { filter: false, widths: [26, 110] });

  const types = XML_DECL + `<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>${sheets.map((_, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('')}</Types>`;
  const workbook = XML_DECL + `<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView activeTab="0"/></bookViews><sheets>${sheets.map((sheet, i) => `<sheet name="${xml(sheet.name)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join('')}</sheets><calcPr calcId="191029"/></workbook>`;
  const rels = XML_DECL + `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${sheets.map((_, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join('')}<Relationship Id="rId${sheets.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`;
  const rootRels = XML_DECL + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>';
  const core = XML_DECL + `<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>${xml(entity)} — Laporan keuangan</dc:title><dc:creator>Keuangan Reza</dc:creator><dcterms:created xsi:type="dcterms:W3CDTF">${new Date().toISOString()}</dcterms:created></cp:coreProperties>`;
  const app = XML_DECL + '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>Keuangan Reza</Application></Properties>';
  return zip([['[Content_Types].xml', types], ['_rels/.rels', rootRels], ['xl/workbook.xml', workbook], ['xl/_rels/workbook.xml.rels', rels], ['xl/styles.xml', STYLES], ['docProps/core.xml', core], ['docProps/app.xml', app], ...sheets.map((sheet, i) => [`xl/worksheets/sheet${i + 1}.xml`, worksheet(sheet)])]);
}

export function downloadWorkbook(state, options = {}) {
  const blob = makeWorkbook(state, options), url = URL.createObjectURL(blob), link = document.createElement('a');
  link.href = url;
  link.download = `keuangan-reza-${options.from || 'awal'}-${options.to || 'semua'}.xlsx`;
  document.body.append(link); link.click(); link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
  return blob;
}
