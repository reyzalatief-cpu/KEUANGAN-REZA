import { randomBytes, scrypt, timingSafeEqual, createHash, createHmac, createCipheriv, createDecipheriv } from 'node:crypto';
import { promisify } from 'node:util';

const derive = promisify(scrypt);
export const token = () => randomBytes(32).toString('base64url');
export const digest = value => createHash('sha256').update(String(value)).digest('hex');
export function equal(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string') return false;
  const x = Buffer.from(a), y = Buffer.from(b);
  return x.length === y.length && timingSafeEqual(x, y);
}
export function checkPassword(password) {
  if (typeof password !== 'string' || password.length < 12 || password.length > 256) throw new Error('Kata sandi harus terdiri dari 12–256 karakter.');
}
export async function hashPassword(password) {
  checkPassword(password);
  const salt = randomBytes(16).toString('hex');
  const key = await derive(password, salt, 64, { N: 32768, r: 8, p: 1, maxmem: 128 * 1024 * 1024 });
  return `scrypt$32768$${salt}$${key.toString('hex')}`;
}
export async function verifyPassword(password, stored) {
  if (typeof password !== 'string' || password.length > 256) return false;
  const parts = typeof stored === 'string' ? stored.split('$') : [];
  const valid = parts.length === 4 && parts[0] === 'scrypt' && parts[1] === '32768';
  const key = await derive(password, valid ? parts[2] : 'authentication-dummy-salt', 64, { N: 32768, r: 8, p: 1, maxmem: 128 * 1024 * 1024 });
  return valid && equal(key.toString('hex'), parts[3]);
}
const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
export function newTotpSecret() {
  let bits = 0, value = 0, result = '';
  for (const byte of randomBytes(20)) { value = (value << 8) | byte; bits += 8; while (bits >= 5) { result += alphabet[(value >>> (bits -= 5)) & 31]; } }
  return result;
}
function base32Decode(secret) {
  let bits = 0, value = 0; const bytes = [];
  for (const char of secret) { const i = alphabet.indexOf(char); if (i < 0) throw new Error('Invalid MFA secret'); value = (value << 5) | i; bits += 5; if (bits >= 8) bytes.push((value >>> (bits -= 8)) & 255); }
  return Buffer.from(bytes);
}
export function totpCode(secret, counter = Math.floor(Date.now() / 30000)) {
  const input = Buffer.alloc(8); input.writeBigUInt64BE(BigInt(counter));
  const hmac = createHmac('sha1', base32Decode(secret)).update(input).digest();
  const offset = hmac[hmac.length - 1] & 15;
  return String((hmac.readUInt32BE(offset) & 0x7fffffff) % 1000000).padStart(6, '0');
}
export function verifyTotp(secret, code, lastCounter = -1) {
  if (typeof code !== 'string' || !/^\d{6}$/.test(code)) return null;
  const now = Math.floor(Date.now() / 30000);
  for (const counter of [now, now - 1, now + 1]) if (counter > lastCounter && equal(code, totpCode(secret, counter))) return counter;
  return null;
}
export function seal(value, key) {
  const iv = randomBytes(12), cipher = createCipheriv('aes-256-gcm', key, iv);
  const ciphertext = Buffer.concat([cipher.update(value, 'utf8'), cipher.final()]);
  return Buffer.concat([iv, cipher.getAuthTag(), ciphertext]).toString('base64');
}
export function unseal(value, key) {
  const data = Buffer.from(value, 'base64');
  const decipher = createDecipheriv('aes-256-gcm', key, data.subarray(0, 12)); decipher.setAuthTag(data.subarray(12, 28));
  return Buffer.concat([decipher.update(data.subarray(28)), decipher.final()]).toString('utf8');
}
