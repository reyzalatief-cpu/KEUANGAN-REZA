import { DatabaseSync } from 'node:sqlite';
import { mkdirSync, readFileSync, writeFileSync, chmodSync, existsSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { randomBytes } from 'node:crypto';

export function openStore(dataDir) {
  dataDir = resolve(dataDir); mkdirSync(dataDir, { recursive: true, mode: 0o700 }); chmodSync(dataDir, 0o700);
  const databasePath = join(dataDir, 'database.sqlite');
  const db = new DatabaseSync(databasePath); chmodSync(databasePath, 0o600);
  db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY, username TEXT NOT NULL UNIQUE COLLATE NOCASE, display_name TEXT NOT NULL,
      password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('owner','operator','reader')),
      email TEXT NOT NULL DEFAULT '', phone TEXT NOT NULL DEFAULT '', avatar TEXT NOT NULL DEFAULT '',
      disabled INTEGER NOT NULL DEFAULT 0, mfa_secret TEXT, mfa_pending TEXT, mfa_pending_at INTEGER,
      mfa_counter INTEGER NOT NULL DEFAULT -1, recovery_codes TEXT NOT NULL DEFAULT '[]', created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS sessions (
      id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      csrf TEXT NOT NULL, expires INTEGER NOT NULL, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS book (id INTEGER PRIMARY KEY CHECK(id=1), state TEXT NOT NULL, revision INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS attachments (
      id TEXT PRIMARY KEY, journal_id TEXT NOT NULL, name TEXT NOT NULL, type TEXT NOT NULL,
      size INTEGER NOT NULL, data BLOB NOT NULL, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS audit (
      id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL, user TEXT NOT NULL, action TEXT NOT NULL, detail TEXT NOT NULL);
  `);
  // Additive migrations preserve existing installations and users.
  const columns = new Set(db.prepare('PRAGMA table_info(users)').all().map(row => row.name));
  for (const column of ['email', 'phone', 'avatar']) if (!columns.has(column)) db.exec(`ALTER TABLE users ADD COLUMN ${column} TEXT NOT NULL DEFAULT ''`);
  const keyPath = join(dataDir, 'auth.key');
  if (!existsSync(keyPath)) {
    if (db.prepare('SELECT COUNT(*) AS n FROM users WHERE mfa_secret IS NOT NULL OR mfa_pending IS NOT NULL').get().n) {
      db.close(); throw new Error('auth.key tidak ditemukan; pulihkan kunci dari backup server sebelum menjalankan.');
    }
    writeFileSync(keyPath, randomBytes(32), { mode: 0o600, flag: 'wx' });
  }
  chmodSync(keyPath, 0o600);
  const key = readFileSync(keyPath);
  if (key.length !== 32) { db.close(); throw new Error('auth.key tidak valid.'); }
  return { db, key, dataDir };
}
export function transaction(db, callback) {
  db.exec('BEGIN IMMEDIATE');
  try { const result = callback(); db.exec('COMMIT'); return result; }
  catch (error) { db.exec('ROLLBACK'); throw error; }
}
