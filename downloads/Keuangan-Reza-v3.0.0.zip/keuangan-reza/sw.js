/* Financial data and authenticated responses must never be cached offline. */
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', event => event.waitUntil((async () => {
  for (const name of await caches.keys()) if (name.startsWith('keuangan-reza')) await caches.delete(name);
  await self.clients.claim();
  await self.registration.unregister();
})()));
