import { readdir } from 'node:fs/promises';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';
const excluded = new Set(['node_modules', '.git', 'data', 'dist', 'artifacts', 'test-results', 'playwright-report']);
let count = 0;
async function scan(directory) {
  for (const item of await readdir(directory, { withFileTypes: true })) {
    if (excluded.has(item.name)) continue;
    const path=join(directory,item.name);
    if(item.isDirectory()) await scan(path);
    else if(/\.(?:m?js)$/.test(item.name)) {
      const result=spawnSync(process.execPath,['--check',path],{encoding:'utf8'});
      if(result.status!==0) { process.stderr.write(result.stderr); process.exitCode=1; }
      count++;
    }
  }
}
await scan('.');
console.log(`Pemeriksaan sintaks: ${count} file JavaScript, ${process.exitCode ? 'GAGAL' : 'LULUS'}.`);
