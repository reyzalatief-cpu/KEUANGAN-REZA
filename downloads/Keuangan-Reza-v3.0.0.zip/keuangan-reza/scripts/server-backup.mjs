import { DatabaseSync, backup } from 'node:sqlite';
import { mkdirSync, copyFileSync, writeFileSync, chmodSync, statSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = dirname(dirname(fileURLToPath(import.meta.url)));
const source = resolve(process.env.DATA_DIR || join(root, 'data'));
const destination = process.argv[2] && resolve(process.argv[2]);
if (!destination || process.argv.length !== 3) { console.error('Penggunaan: node --env-file-if-exists=.env scripts/server-backup.mjs /direktori/backup-baru'); process.exit(1); }
let db;
try {
  statSync(join(source, 'database.sqlite')); statSync(join(source, 'auth.key'));
  mkdirSync(destination, { recursive: false, mode: 0o700 });
  db = new DatabaseSync(join(source, 'database.sqlite'), { readOnly: true });
  db.exec('PRAGMA busy_timeout=10000');
  await backup(db, join(destination, 'database.sqlite'));
  chmodSync(join(destination, 'database.sqlite'), 0o600);
  copyFileSync(join(source, 'auth.key'), join(destination, 'auth.key')); chmodSync(join(destination, 'auth.key'), 0o600);
  writeFileSync(join(destination, 'backup-info.json'), JSON.stringify({ format: 'keuangan-reza-server', version: 1, createdAt: new Date().toISOString(), containsCredentials: true }, null, 2), { mode: 0o600, flag: 'wx' });
  console.log(`Backup server lengkap tersimpan: ${destination}`);
} catch (error) { console.error(`Backup gagal: ${error.message}`); process.exitCode = 1; }
finally { db?.close(); }
