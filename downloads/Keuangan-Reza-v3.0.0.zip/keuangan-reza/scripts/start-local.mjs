import { constants, copyFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const [major, minor] = process.versions.node.split('.').map(Number);
if (major !== 24 || minor < 13) {
  console.error(`Node.js ${process.versions.node} belum sesuai. Pasang Node.js 24.13 atau versi 24.x yang lebih baru, lalu jalankan kembali.`);
  process.exit(1);
}
if (process.argv.length > 2) {
  console.error('Penggunaan: node scripts/start-local.mjs (tanpa argumen).');
  process.exit(1);
}
process.chdir(root);
try {
  copyFileSync('.env.example', '.env', constants.COPYFILE_EXCL);
  console.log('Konfigurasi awal dibuat dari .env.example.');
} catch (error) {
  if (error.code !== 'EEXIST') {
    console.error(`Konfigurasi tidak dapat disiapkan: ${error.message}`);
    process.exit(1);
  }
}
console.log('Memulai Keuangan Reza. Buka alamat yang ditampilkan server di browser.');
console.log('Pada penggunaan pertama, buat akun pemilik Anda sendiri. Hentikan dengan Ctrl+C.');
const child = spawn(process.execPath, ['--env-file-if-exists=.env', 'server.mjs'], { cwd: root, stdio: 'inherit' });
child.on('error', error => {
  console.error(`Server tidak dapat dijalankan: ${error.message}`);
  process.exitCode = 1;
});
for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => { if (!child.killed) child.kill(signal); });
child.on('exit', (code, signal) => { process.exitCode = code ?? (signal === 'SIGINT' || signal === 'SIGTERM' ? 0 : 1); });
