import { mkdir, readFile, writeFile, readdir, cp, rm, stat } from 'node:fs/promises';
import { resolve, relative, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { deflateRawSync } from 'node:zlib';
const root=resolve(fileURLToPath(new URL('..',import.meta.url)));
const output=join(root,'dist','keuangan-reza');
const pkg=JSON.parse(await readFile(join(root,'package.json'),'utf8'));
const sources=['index.html','app.js','styles.css','accounting.js','backup.js','export.js','manifest.json','icon.svg','sw.js','server.mjs','package.json','package-lock.json','.nvmrc','.env.example','.gitignore','README.md','MULAI-DI-SINI.md','MULAI-WINDOWS.cmd','mulai.sh','Dockerfile','.dockerignore','docs','scripts','tests','playwright.config.mjs'];
for(const name of await readdir(root)) if(/^ui-.*\.js$/.test(name)||name==='server') sources.push(name);
for(const file of sources) await stat(join(root,file));
await mkdir(join(root,'dist'),{recursive:true});
await rm(output,{recursive:true,force:true});
await mkdir(output);
for(const file of sources) await cp(join(root,file),join(output,file),{recursive:true});
const files=[];
async function list(dir) { for(const entry of await readdir(dir,{withFileTypes:true})) {const path=join(dir,entry.name); if(entry.isDirectory()) await list(path); else files.push(path);} }
await list(output);
const table=Uint32Array.from({length:256},(_,i)=>{for(let j=0;j<8;j++)i=(i&1)?0xedb88320^(i>>>1):i>>>1;return i>>>0});
function crc32(data){let c=0xffffffff;for(const b of data)c=table[(c^b)&255]^(c>>>8);return (c^0xffffffff)>>>0;}
const parts=[],central=[];let offset=0;
for(const path of files.sort()) {
 const raw=await readFile(path),data=deflateRawSync(raw),name=Buffer.from('keuangan-reza/'+relative(output,path).replaceAll('\\','/')),crc=crc32(raw);
 const local=Buffer.alloc(30);local.writeUInt32LE(0x04034b50);local.writeUInt16LE(20,4);local.writeUInt16LE(0x800,6);local.writeUInt16LE(8,8);local.writeUInt16LE(33,12);local.writeUInt32LE(crc,14);local.writeUInt32LE(data.length,18);local.writeUInt32LE(raw.length,22);local.writeUInt16LE(name.length,26);
 const dir=Buffer.alloc(46);dir.writeUInt32LE(0x02014b50);dir.writeUInt16LE(20,4);dir.writeUInt16LE(20,6);dir.writeUInt16LE(0x800,8);dir.writeUInt16LE(8,10);dir.writeUInt16LE(33,14);dir.writeUInt32LE(crc,16);dir.writeUInt32LE(data.length,20);dir.writeUInt32LE(raw.length,24);dir.writeUInt16LE(name.length,28);dir.writeUInt32LE(offset,42);
 parts.push(local,name,data);central.push(dir,name);offset+=local.length+name.length+data.length;
}
const end=Buffer.alloc(22),centralSize=central.reduce((sum,x)=>sum+x.length,0);end.writeUInt32LE(0x06054b50);end.writeUInt16LE(files.length,8);end.writeUInt16LE(files.length,10);end.writeUInt32LE(centralSize,12);end.writeUInt32LE(offset,16);
const archive=join(root,'dist',`keuangan-reza-v${pkg.version}.zip`);await writeFile(archive,Buffer.concat([...parts,...central,end]));
console.log(`Paket ${files.length} file: ${archive}. Data pengguna dan rahasia tidak disertakan.`);
