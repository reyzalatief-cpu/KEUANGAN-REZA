import { DatabaseSync } from 'node:sqlite';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { hashPassword } from '../server/security.mjs';
import { transaction } from '../server/storage.mjs';

const root = dirname(dirname(fileURLToPath(import.meta.url)));
const username = process.argv[2], disableMfa = process.argv[3] === '--disable-mfa';
if (!username || process.argv.length > (disableMfa ? 4 : 3)) { console.error('Penggunaan: node --env-file-if-exists=.env scripts/reset-owner.mjs USERNAME [--disable-mfa]\nKata sandi baru dibaca dari stdin; hentikan aplikasi terlebih dahulu.'); process.exit(1); }
async function readSecret() {
  if (!process.stdin.isTTY) { let input = ''; for await (const part of process.stdin) { input += part; if (input.length > 1024) throw new Error('Input terlalu panjang.'); } return input.replace(/\r?\n$/, ''); }
  return new Promise((resolveSecret, reject) => {
    process.stderr.write('Kata sandi baru (12–256 karakter): ');
    process.stdin.setRawMode(true); process.stdin.setEncoding('utf8'); process.stdin.resume(); let value = '';
    const finish = () => { process.stdin.setRawMode(false); process.stdin.pause(); process.stdin.off('data', read); process.stderr.write('\n'); };
    const read = chunk => { for (const char of chunk) { if (char === '\u0003') { finish(); reject(new Error('Dibatalkan.')); return; } if (char === '\r' || char === '\n') { finish(); resolveSecret(value); return; } if (char === '\u007f' || char === '\b') value = value.slice(0, -1); else if (value.length < 257) value += char; } };
    process.stdin.on('data', read);
  });
}
let db;
try {
  db = new DatabaseSync(resolve(process.env.DATA_DIR || join(root, 'data'), 'database.sqlite'), { open: true });
  db.exec('PRAGMA busy_timeout=5000');
  const owner = db.prepare("SELECT id,username FROM users WHERE username=? COLLATE NOCASE AND role='owner'").get(username);
  if (!owner) throw new Error('Akun pemilik tidak ditemukan.');
  const hash = await hashPassword(await readSecret());
  transaction(db, () => {
    db.prepare('UPDATE users SET password_hash=?,disabled=0 WHERE id=?').run(hash, owner.id);
    if (disableMfa) db.prepare("UPDATE users SET mfa_secret=NULL,mfa_pending=NULL,mfa_pending_at=NULL,mfa_counter=-1,recovery_codes='[]' WHERE id=?").run(owner.id);
    db.prepare('DELETE FROM sessions WHERE user_id=?').run(owner.id);
    db.prepare('INSERT INTO audit (at,user,action,detail) VALUES (?,?,?,?)').run(new Date().toISOString(), 'server-console', 'owner.recovered', JSON.stringify({ id: owner.id, mfaDisabled: disableMfa }));
  });
  console.log('Kata sandi pemilik diperbarui dan semua sesinya dicabut.');
} catch (error) { console.error(`Pemulihan gagal: ${error.message}`); process.exitCode = 1; }
finally { db?.close(); }
