# Menjalankan dan merawat Keuangan Reza

## Instalasi lokal

Gunakan Node.js **24.13 sampai sebelum 25**; versi pengembangan yang dipin ada di `.nvmrc`. SQLite sudah disediakan oleh Node.js. Jalankan perintah dari folder proyek.

```sh
cp .env.example .env
npm start
```

Pada PowerShell gunakan `Copy-Item .env.example .env`. Jika konfigurasi `.env` sudah ada, sesuaikan isinya tanpa menimpanya dengan contoh.

Buka `http://127.0.0.1:3000`, lalu buat pemilik pertama. Kata sandi minimal 12 karakter; gunakan kata sandi unik yang panjang. Tidak ada pendaftaran umum setelah pemilik tersedia. Folder `data/` berisi data nyata dan harus tetap privat. Hentikan dengan **Ctrl+C**.

Runtime tidak membutuhkan paket npm tambahan. `npm ci` memasang alat pengembangan/pengujian dari lockfile; distribusi yang sudah disiapkan dapat dijalankan langsung dengan `node --env-file-if-exists=.env server.mjs` menggunakan Node yang sesuai.

| Variabel | Bawaan | Fungsi |
|---|---|---|
| `HOST` | `127.0.0.1` | Alamat listener. Gunakan loopback untuk pembuatan pemilik pertama. |
| `PORT` | `3000` | Port HTTP internal. |
| `DATA_DIR` | `data/` di folder proyek | Folder data persisten. Contoh `.env` memakai `./data`, relatif terhadap direktori kerja; path absolut disarankan pada service. |
| `SECURE_COOKIES` | `0` | Set `1` untuk akses HTTPS agar cookie tidak dikirim lewat HTTP. |
| `APP_ORIGIN` | kosong | Origin publik yang tepat, misalnya `https://keuangan.domain-anda.example`, tanpa slash akhir/path. Isi ketika memakai domain atau reverse proxy; origin HTTPS mewajibkan `SECURE_COOKIES=1`. |

`.env` dimuat oleh `npm start`; variabel lingkungan proses memiliki prioritas. Jangan simpan kata sandi pengguna dalam `.env`. Untuk menjalankan beberapa buku terpisah, gunakan instance, port dan `DATA_DIR` berbeda; setiap instance memiliki pemilik dan pengguna sendiri.

## Akses pengguna dan keamanan akun

Pemilik mengelola buku, master, periode, pengguna, pemulihan dan konfigurasi. Operator memasukkan transaksi dalam ruang izin yang diberikan server. Pembaca melihat laporan dan mengunduh hasil. Penambahan pengguna hanya tersedia bagi pemilik; aplikasi bukan layanan pendaftaran publik.

Ubah kata sandi melalui aplikasi. Aktifkan MFA jika digunakan, verifikasi kode autentikator, kemudian simpan kode pemulihan sekali pakai di tempat aman di luar perangkat. Gunakan pencabutan sesi lain setelah kehilangan perangkat atau menduga sesi bocor. Jangan masukkan password, secret MFA atau kode pemulihan dalam issue, log publik atau percakapan.

Kehilangan akses pemilik dapat dipulihkan oleh administrator yang mempunyai akses filesystem server. **Hentikan aplikasi terlebih dahulu**, lalu jalankan dari folder proyek dengan `DATA_DIR` yang sama:

```sh
node --env-file-if-exists=.env scripts/reset-owner.mjs NAMA_PENGGUNA
```

Perintah meminta kata sandi baru melalui terminal dengan input tersembunyi dan mencabut sesi pemilik itu. Bila MFA benar-benar hilang dan kode pemulihan tidak ada, gunakan opsi eksplisit berikut:

```sh
node --env-file-if-exists=.env scripts/reset-owner.mjs NAMA_PENGGUNA --disable-mfa
```

Jalankan kembali server dengan `npm start`, lalu login dengan kata sandi baru. Aktifkan kembali MFA setelah login bila sebelumnya dinonaktifkan. Akses filesystem administrator memberikan kendali penuh terhadap database; batasi akun sistem dan izin folder data.

## Data dan periode

Selesaikan master akun, kontak dan produk sebelum memasukkan transaksi. Saldo awal harus seimbang dan memiliki rincian piutang/hutang/stok bila relevan. Periksa hasil jurnal otomatis sebelum menyimpan transaksi. Rekening bank/e-wallet baru memakai akun kas tersendiri; jangan mengubah kode akun yang telah dipakai untuk memberi makna baru pada histori.

Buat cadangan, periksa neraca saldo, laporan dan buku bantu sebelum penutupan. Jurnal penutup dipisahkan dari laba rugi periode berjalan. Perubahan periode tertutup perlu dilakukan pemilik secara sadar dengan membuka kunci terlebih dahulu, kemudian meninjau dan menutup ulang sesuai hasil koreksi.

Saat ada konflik revisi dari tab atau pengguna lain, aplikasi menolak penimpaan. Muat data terbaru dan ulangi perubahan setelah meninjau hasil yang sudah disimpan pihak lain. Jangan memaksa restore untuk menyelesaikan konflik biasa.

## Backup dan pemulihan

Ada dua jenis cadangan:

| Jenis | Isi dan kegunaan |
|---|---|
| Cadangan pembukuan melalui aplikasi | Buku dan bukti transaksi; dipakai untuk pemindahan/pemulihan buku, bukan menyalin akun login. Gunakan cadangan terenkripsi saat mengunduh. |
| Cadangan server | Database dan `auth.key`; mempertahankan pembukuan, bukti, akun, sesi/konfigurasi autentikasi yang tersimpan. Dipakai untuk pemulihan penuh server. |

### Cadangan server konsisten

Perintah berikut membuat **folder tujuan baru**. Tentukan nama unik yang belum ada dan lokasi di luar folder data aktif:

```sh
mkdir -p backups
node --env-file-if-exists=.env scripts/server-backup.mjs ./backups/backup-2026-10-19
```

Pada PowerShell, gunakan `New-Item -ItemType Directory -Force backups` sebagai pengganti `mkdir -p backups`. Folder induk harus sudah ada; folder tujuan `backup-2026-10-19` dibuat oleh utilitas dan harus belum ada.

Gunakan tanggal/nama yang sesuai saat Anda menjalankannya. Utilitas membuat salinan SQLite konsisten dan menyertakan `auth.key`; jangan menyalin hanya file SQLite secara manual ketika server masih aktif karena transaksi bisa berada pada journal/WAL.

Lampiran PDF/PNG/JPEG dibatasi 5 MiB per file dan total 100 MiB per buku. Cadangan terenkripsi dari browser dibatasi 48 MiB sebelum enkripsi; gunakan cadangan server bila buku beserta lampiran melampaui batas tersebut. Kata sandi cadangan browser terpisah dari kata sandi login dan tidak dapat dipulihkan oleh server.

Cadangan server bukan otomatis terenkripsi. Simpan di volume terenkripsi atau arsipkan melalui perangkat backup tepercaya. Berikan izin baca hanya kepada administrator. Kunci `auth.key` diperlukan untuk mempertahankan autentikasi terkait MFA; simpan bersama database dalam cadangan privat. Jangan unggah database, kunci, `.env` atau cadangan ke repository publik.

Untuk otomatisasi Linux, contoh cron harian berikut memakai direktori absolut; sesuaikan lokasi Node, proyek dan tujuan terlebih dahulu:

```cron
0 2 * * * cd /srv/keuangan-reza && /usr/bin/node --env-file-if-exists=.env scripts/server-backup.mjs /srv/backup-reza/backup-$(date +\%Y-\%m-\%d-\%H\%M) >> /srv/backup-reza/backup.log 2>&1
```

Periksa `command -v node` untuk lokasi Node. Siapkan folder tujuan dengan izin privat, periksa log, pindahkan salinan ke media lain, dan tentukan retensi. Jadwal tidak terpasang otomatis oleh aplikasi. Uji restore pada folder terpisah sebelum mengandalkan cadangan.

### Memulihkan seluruh server

1. Hentikan aplikasi atau container. Cadangkan keadaan sekarang walaupun bermasalah.
2. Pindahkan folder data aktif ke nama lain agar dapat dikembalikan.
3. Buat folder data baru, lalu salin `database.sqlite` dan `auth.key` dari satu cadangan yang sama. Jangan membawa file WAL/SHM dari database lain.
4. Atur pemilik filesystem sesuai pengguna proses server; pada Linux gunakan izin folder `700` dan file `600`.
5. Jalankan server, login, lalu cocokkan jumlah transaksi, saldo, lampiran, pengguna dan laporan.

Contoh untuk `DATA_DIR=./data`, dijalankan ketika server sudah berhenti:

```sh
mv data data-sebelum-pemulihan
mkdir -m 700 data
cp backups/backup-2026-10-19/database.sqlite data/
cp backups/backup-2026-10-19/auth.key data/
chmod 600 data/database.sqlite data/auth.key
npm start
```

Pilih nama arsip yang belum ada; sesuaikan lokasi jika `DATA_DIR` berbeda. Windows menggunakan pengaturan akses folder sistem sebagai pengganti `chmod`.

### Memulihkan buku melalui aplikasi

Unduh cadangan buku saat ini, pilih file yang akan diperiksa, masukkan kata sandinya hanya di aplikasi, dan tinjau isi sebelum menyetujui penggantian buku. Bandingkan jumlah transaksi, debit/kredit, neraca, rincian hutang/piutang/stok serta lampiran setelah pemulihan. File yang ditolak tidak boleh dipaksa dengan mengubah ekstensi.

Sebelum mengganti buku, server menyimpan snapshot buku sebelumnya di `DATA_DIR/snapshots/`. Snapshot ini berisi data pembukuan tanpa enkripsi file; batasi akses dan buat kebijakan retensi sendiri. Cadangan server dari utilitas berisi keadaan database saat dicadangkan serta `auth.key`, bukan salinan folder snapshot historis.

Cadangan `.krb` situs lama yang disebut di PDF belum disertakan. Implementasi enkripsi baru tidak berarti format lama kompatibel. Untuk migrasi tersebut masih diperlukan file asli dan spesifikasi/kode format yang dapat diverifikasi; data dan akun situs lama tetap dikelola pada situs asal sampai migrasi berhasil dibuktikan.

## HTTPS dan akses dari perangkat lain

Server harus sudah memiliki pemilik sebelum dibuka pada alamat selain loopback. Untuk server jauh, inisialisasi dengan SSH tunnel:

```sh
ssh -L 3000:127.0.0.1:3000 pengguna@alamat-server
```

Jalankan aplikasi di server dengan `HOST=127.0.0.1`, buka `http://127.0.0.1:3000` dari komputer Anda melalui tunnel, lalu buat pemilik. Jangan meneruskan port aplikasi tanpa autentikasi ke internet saat bootstrap.

Sesudah inisialisasi, tempatkan aplikasi di belakang reverse proxy HTTPS. Contoh Caddy pada mesin yang sama:

```caddyfile
keuangan.domain-anda.example {
    reverse_proxy 127.0.0.1:3000
}
```

Ganti hostname dengan domain yang benar, arahkan DNS ke server, dan buka port proxy `80/443`. Sesudah akun pemilik dibuat, sesuaikan `.env` berikut dan restart aplikasi:

```dotenv
HOST=127.0.0.1
PORT=3000
DATA_DIR=./data
SECURE_COOKIES=1
APP_ORIGIN=https://keuangan.domain-anda.example
```

`APP_ORIGIN` harus sama persis dengan origin yang dipakai browser, termasuk port nonstandar jika ada, tanpa slash akhir atau path. Gunakan URL HTTPS untuk login; cookie Secure sengaja tidak dikirim melalui HTTP biasa. Server memeriksa header Host dan Origin, serta tidak mempercayai `X-Forwarded-*` untuk menentukan origin publik. Proxy harus mempertahankan Host publik, seperti contoh Caddy di atas. Tidak perlu membuka listener aplikasi ke internet jika proxy berada pada mesin yang sama.

Jika proxy berada di container/jaringan lain, `HOST=0.0.0.0` mungkin diperlukan **sesudah inisialisasi**. Batasi port internal dengan firewall atau jaringan container; pengguna mengakses proxy HTTPS. Jangan mengekspos folder `data/`, cadangan atau repository sebagai file statis. Tidak ada sertifikat atau domain yang dibuat otomatis oleh proyek ini.

Untuk pemakaian berkelanjutan, jalankan proses melalui service manager sistem atau container dengan kebijakan restart. Pastikan direktori kerja dan `DATA_DIR` konsisten pada setiap restart.

## Docker

Docker adalah pilihan setelah akun pemilik dibuat melalui instalasi lokal di atas. Dockerfile tidak menyediakan kata sandi bawaan dan tidak melewati perlindungan inisialisasi lokal.

```sh
docker build -t keuangan-reza:local .
```

Hentikan server Node lokal sebelum container memakai folder data yang sama. Image berjalan sebagai pengguna `node` (UID/GID 1000); pada Linux, pastikan direktori `data/` dapat dibaca/ditulis oleh UID ini. Cadangkan data sebelum mengganti pemilik filesystem bila diperlukan.

Dengan reverse proxy HTTPS pada host:

```sh
docker run -d --name keuangan-reza --restart unless-stopped \
  -p 127.0.0.1:3000:3000 \
  -v "$(pwd)/data:/app/data" \
  -e SECURE_COOKIES=1 \
  -e APP_ORIGIN=https://keuangan.domain-anda.example \
  keuangan-reza:local
```

Untuk pengujian HTTP lokal saja, gunakan `-e SECURE_COOKIES=0`, hilangkan opsi `-e APP_ORIGIN=...`, dan buka `http://127.0.0.1:3000`. Image mendengarkan `0.0.0.0` di dalam container; port host pada contoh hanya terbuka di loopback. Perintah mount di atas memakai shell Linux/macOS; sesuaikan penulisan path di PowerShell.

```sh
docker logs --tail 100 keuangan-reza
docker stop keuangan-reza
docker start keuangan-reza
```

Jangan menjalankan dua proses/container dengan folder data aktif yang sama untuk pekerjaan pemeliharaan. Docker image dan uji build aplikasi adalah hasil berbeda; lihat laporan validasi untuk mengetahui apakah Docker benar-benar diuji pada lingkungan pengembangan ini.

## Pemasangan HP dan hasil cetak

Setelah tersedia di HTTPS, buka URL aplikasi pada perangkat Anda dan login menggunakan akun aplikasi:

- Android/Chrome: menu browser → Tambahkan ke layar utama/Instal aplikasi, sesuai dukungan browser.
- iPhone/Safari: Bagikan → Tambahkan ke Layar Utama.

Ini pemasangan web app/pintasan, bukan APK atau aplikasi App Store. Server tetap harus dapat dihubungi untuk membuka dan menyimpan buku; tidak ada penulisan transaksi offline yang dijanjikan. `localhost` pada HP menunjuk ke HP itu sendiri, bukan komputer server.

Cetak laporan dari menu laporan, pilih A4 dan skala 100% atau sesuaikan pratinjau browser; nonaktifkan header/footer bawaan browser bila mengganggu. Pilih “Simpan sebagai PDF” untuk file PDF. Ukuran kertas printer, margin driver dan cetak fisik perlu diperiksa pada perangkat pengguna.

## Pembaruan dan distribusi

Buat cadangan server, hentikan aplikasi, pasang kode versi baru, jalankan pemeriksaan yang relevan, lalu jalankan kembali dengan `DATA_DIR` lama. Jangan menyalin folder data kosong dari arsip distribusi di atas data aktif.

```sh
npm ci
npm run check
npm test
npx playwright install chromium
npm run test:e2e
npm run build
```

`npm test` menjalankan tes Node.js; tes browser dijalankan terpisah lewat `npm run test:e2e`. Tidak ada TypeScript atau linter terpisah pada proyek ini; `npm run check` memeriksa sintaks JavaScript. Pada Linux yang belum mempunyai pustaka browser, pemasangan Playwright mungkin perlu dependensi sistem dari administrator.

Build menghasilkan `dist/keuangan-reza/` dan paket sumber siap jalan `dist/keuangan-reza-v3.0.0.zip`, tanpa database atau kredensial. Ekstrak ke folder baru, masuk ke folder `keuangan-reza`, salin `.env.example` ke `.env`, sesuaikan konfigurasi, lalu jalankan `npm start`. `npm ci` tidak diperlukan untuk menjalankan distribusi; perintah itu diperlukan untuk alat pengujian browser. Build tidak otomatis melakukan deployment, membeli domain, memasang HTTPS atau memindahkan data produksi.

Konfigurasi environment cloud development disimpan untuk peninjauan terpisah oleh pengguna. Penyimpanan/peninjauan konfigurasi tersebut bukan bukti aplikasi sudah diterbitkan. Hasil tes aktual dan keterbatasannya ada di [laporan validasi](validation.md).
