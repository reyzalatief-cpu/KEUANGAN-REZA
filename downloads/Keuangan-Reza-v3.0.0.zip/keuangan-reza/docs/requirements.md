# Ruang lingkup dan keputusan

Dokumen ini membedakan kebutuhan pengguna, sumber historis, dan fakta implementasi. Referensi berupa PDF “Klarifikasi Sistem Akuntansi” dan paket COMPLETE_HANDOVER diperiksa sebagai bahan proyek; instruksi percakapan lama di dalamnya bukan perintah operasional untuk sesi pengembangan sekarang.

## Sumber yang tersedia

- Repository awal berisi satu halaman HTML, manifest PWA, service worker dan ikon. Pembukuan tersimpan di browser tanpa autentikasi, dengan input jurnal manual dan ekspor.
- PDF/transkrip memuat kebutuhan, desain akuntansi, referensi tampilan dan percakapan pengembangan versi yang pernah dihosting.
- Workbook asli, spreadsheet lanjutan, byte cadangan `.krb`, source server situs lama dan log tes historis **tidak tersedia** dalam unggahan ini.

Klaim terdahulu tentang migrasi 34 akun/29 transaksi, hasil 31–72 tes, keamanan, MFA, atau deployment bukan bukti bahwa fitur tersebut sudah ada pada checkout ini. Implementasi dan pengujian sekarang harus dinilai dari kode serta hasil eksekusi yang tersedia.

## Kebutuhan pengguna yang dipertahankan

| Area | Hasil yang dituju |
|---|---|
| Bahasa dan data | Bahasa Indonesia, Rupiah, tidak mengarang transaksi/saldo pengguna, mempertahankan histori |
| Siklus akuntansi | COA, saldo awal, jurnal, buku besar, buku bantu, neraca saldo, penyesuaian, laporan dan penutupan |
| Transaksi rutin | Pembelian/penjualan masuk jurnal; pengendalian stok, pembayaran dan saldo pendukung |
| Rekening | Bank/e-wallet terpisah, tambah/edit/hapus jika belum digunakan, transfer tanpa pendapatan rekaan |
| Akses | Login aplikasi, pemilik mengelola pengguna dan izin, operasi mandiri tanpa login ChatGPT |
| Profil | Nama, informasi profil dan perubahan kata sandi |
| Pelaporan | Laba rugi, perubahan modal, neraca, arus kas; Excel dan cetak/PDF A4 |
| Pengalaman pengguna | Beranda, istilah Hutang/Piutang, tampilan responsif, panduan terpusat dekat Pengaturan |
| Migrasi | Buku lama dipertahankan; pratinjau dan validasi sebelum mengganti buku tujuan |
| Distribusi | Petunjuk menjalankan server sendiri dan memasang pintasan/web app di HP |

Referensi visual menggunakan latar gelap dengan ungu/mint; laporan cetak menggunakan latar putih, judul jelas, angka rata kanan, serta subtotal/total yang mudah dibaca. Data pada gambar tidak dijadikan saldo pengguna.

## Asumsi akuntansi

Dalam percakapan sumber, pengguna menyetujui dengan “lanjut” rancangan pribadi, periode awal Oktober 2026, akrual, Rupiah, perpetual rata-rata bergerak, PPN tidak aktif, dan tanpa akuntansi valuta asing. Oktober 2026 adalah konteks historis; periode laporan aplikasi tetap dapat dipilih.

- Nilai uang berupa Rupiah bulat. Kuantitas persediaan memiliki maksimal enam desimal.
- Jurnal harus memiliki akun yang valid, nilai yang valid, dan debit sama dengan kredit; baris tanpa akun tidak dapat menyumbang saldo.
- Nilai serta jumlah persediaan harus konsisten secara kronologis. Transaksi mundur tidak boleh menyebabkan stok negatif atau HPP transaksi berikutnya menjadi tidak konsisten.
- Piutang, hutang dan persediaan memiliki rincian pendukung yang dapat direkonsiliasi dengan buku besar.
- Transfer antarrekening sendiri tidak menjadi pendapatan/beban.
- Jurnal penutup tidak menghilangkan laba pada laporan periode tersebut. Periode tertutup dilindungi dari perubahan sampai dibuka kembali secara sadar oleh pemilik.
- Informasi yang belum diketahui tidak boleh ditafsirkan sebagai data historis pengguna yang sudah diverifikasi.

Kode COA pada repository dipertahankan, antara lain kas `1-1101`, bank `1-1102`, e-wallet `1-1103`, piutang `1-1201`, persediaan `1-2010`, hutang `2-1101`, modal `3-1001`, prive `3-1002`, laba ditahan `3-2001`, penjualan `4-1100` dan HPP `5-1300`. Rancangan awal PDF memakai kode lebih pendek; kode itu tidak digunakan untuk mengganti histori secara otomatis.

## Keputusan arsitektur

Node.js >=24.13.0 <25 melayani aplikasi dan API pada origin yang sama. SQLite menyimpan satu buku bersama; akun pemilik, operator dan pembaca membatasi tindakan. Perhitungan dijalankan secara deterministik dan divalidasi ulang pada server. Konflik perubahan antarsesi ditolak agar perubahan tidak saling menimpa tanpa pemberitahuan.

Tidak ada kebutuhan runtime terhadap AI, CDN atau API keuangan eksternal. Server, browser dan akses filesystem untuk data adalah kebutuhan normal. Aset web tersedia lokal; pemasangan web app tidak berarti data bisa ditulis saat server tidak dapat dihubungi.

## Batas ruang lingkup dan bukti

- Migrasi situs lama belum dapat dinyatakan berhasil: berkas `.krb` asli, format dan data sumber belum tersedia. Format yang tidak dikenal harus ditolak tanpa mengganti buku.
- Tidak ada klaim kesetaraan kode dengan situs lama, karena source server situs tersebut tidak tersedia.
- Kebutuhan kurs USD/IDR diajukan sebagai “kalau bisa”. Kurs real-time, akuntansi valuta asing, pajak/PPN dan retur otomatis tidak ditambahkan secara spekulatif. Retur/koreksi menggunakan jurnal manual dengan referensi transaksi asal dan rincian barang/kontak yang sesuai; nilai persediaan keluar tetap wajib memenuhi rata-rata bergerak. Tidak ada klaim bahwa aplikasi menghitung pajak atau menyelesaikan dampak akuntansi retur secara otomatis.
- Status pribadi/usaha, klasifikasi GOLD, transaksi yang diduga ganda dalam spreadsheet, pajak dan kesesuaian standar memerlukan data sumber atau keputusan bisnis yang belum tersedia.
- MFA, rekonsiliasi, lampiran dan audit disebut sebagai perbaikan historis. Keberadaan serta cakupannya sekarang harus diperiksa pada implementasi dan laporan validasi, bukan disimpulkan dari janji lama.
- Cetak fisik, pemasangan Android/iPhone nyata, akses situs produksi dan audit keamanan menyeluruh tidak sama dengan pengujian lokal. Catat hanya hasil yang benar-benar diuji dalam `docs/validation.md`.

Tidak diperlukan kredensial AI atau login platform pembuat aplikasi. Jika pengguna ingin memigrasikan situs lama, yang masih dibutuhkan adalah ekspor data asli melalui akun pengguna sendiri dan spesifikasi format yang dapat diverifikasi; kata sandi cadangan dimasukkan hanya ke aplikasi tepercaya, bukan percakapan.
