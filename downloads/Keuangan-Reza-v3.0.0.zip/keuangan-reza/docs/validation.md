# Hasil validasi — 20 Oktober 2026

Validasi dilakukan pada repository ini, bukan situs lama yang disebut dalam lampiran. Seluruh data pengujian merupakan fixture terpisah. Buku pada instance pengembangan dimulai kosong dan menunggu pemilik membuat akun sendiri; tidak ada kredensial bawaan.

## Hasil aktual

| Pemeriksaan | Hasil |
|---|---|
| `npm ci --cache /workspace/.npm-cache --ignore-scripts` | Berhasil dari package-lock.json |
| `npm run check` | Pemeriksaan sintaks JavaScript lulus |
| `npm test` | **40 lulus, 0 gagal, 0 dilewati** |
| Mesin akuntansi | 20 tes: jurnal seimbang, referensi master, angka invalid, pecahan stok, HPP rata-rata bergerak, tanggal mundur, transaksi parsial, laporan antarperiode dan penutupan |
| Enkripsi cadangan | 4 tes: round-trip termasuk lampiran, nonce acak, kata sandi salah, manipulasi isi, batas parameter enkripsi |
| Ekspor XLSX | 4 tes: ZIP/checksum, struktur lembar, saldo periode, teks literal dan penolakan input invalid |
| Integrasi API dan SQLite | 12 tes: autentikasi, CSRF, peran, konflik revisi, periode terkunci, bukti, restore atomik, audit, MFA/recovery, perubahan sesi saat request tertunda, reverse proxy, backup dan pemulihan pemilik |
| `npm run test:e2e` | **8 lulus** pada Chromium 154, sekitar 12 detik |
| `npm audit --audit-level=moderate` | 0 kerentanan dilaporkan untuk dependensi terpasang |
| Pemeriksaan workbook terpisah | OpenPyXL 3.1.5 membuka 17 lembar; nilai jurnal dan laba cocok, teks tidak dijalankan sebagai formula |
| PDF browser | 5 halaman A4, 594,96 × 841,92 pt; halaman pertama diperiksa visual, tidak ada halaman awal kosong |
| Docker | Image berhasil dibangun; pembuatan akun, baca/tulis jurnal, penolakan akses anonim, dan persistensi setelah restart diuji pada container sementara |
| Instance pengembangan | Aplikasi dan health endpoint merespons; API buku memerlukan login; akun pemilik belum dibuat |
| `npm run build` dan `unzip -t` | Paket 37 file berhasil dibuat; seluruh entri ZIP lolos pemeriksaan |
| Startup paket distribusi | Pembuatan akun, penyimpanan/baca ulang jurnal, aset JavaScript, serta penolakan akses anonim lulus |
| Launcher lokal dari ZIP | Startup, API terproteksi, shutdown, restart, dan pelestarian .env lulus pada Linux; diuji dalam folder dengan spasi |
| `git diff --check` | Lulus |

Tes browser meliputi pembuatan pemilik, reload sesi, CRUD jurnal, master kontak/produk, pembelian/penjualan parsial, laporan pembanding, XLSX/PDF, bukti transaksi, backup terenkripsi dan restore, pelunasan serta kelebihan bayar, impor CSV dan pencocokan rekening, tutup periode, akses Pembaca, dan viewport ponsel 390 px. Tidak ditemukan exception JavaScript, NaN, permintaan HTTP eksternal/AI/CDN, atau overflow horizontal pada halaman yang diuji.

Node yang dipakai: 24.19.0. Tidak ada paket npm runtime; Playwright 1.64.1 adalah dependensi pengembangan. Pemeriksaan tipe/linter khusus tidak tersedia pada proyek JavaScript ini; pemeriksaan sintaks dan tes fungsional dijalankan. Audit npm tidak sama dengan audit keamanan produksi menyeluruh.

## Artefak pengujian

Artefak lokal tersedia di `artifacts/browser/`: `laporan-a4.pdf`, `laporan-browser.xlsx`, screenshot desktop/mobile, bukti unduhan, dan cadangan fixture. Artefak/data uji tidak dimasukkan dalam paket aplikasi. Paket tidak menyertakan database pengguna, auth.key, .env, atau kredensial.

## Batas yang belum diverifikasi

- File `.krb` aktual dan sumber format situs lama belum tersedia. Migrasi buku produksi lama belum dilakukan; format baru tidak diklaim kompatibel dengan format tersebut.
- Deployment ke domain publik, sertifikat HTTPS nyata, pemasangan pada Android/iPhone fisik, dan cetak pada printer fisik belum dilakukan. Launcher Windows/macOS disediakan tetapi belum dieksekusi pada sistem operasi tersebut.
- Tidak mengklaim kepatuhan penuh SAK EMKM/PSAK atau audit keamanan independen.
- Perubahan transaksi mundur yang mengubah HPP mutasi berikutnya ditolak. Koreksi perlu dilakukan berurutan agar nilai persediaan dan jurnal tetap konsisten; HPP historis tidak ditulis ulang diam-diam.
- Ekspor Excel merupakan snapshot laporan; pengeditan workbook tidak mengubah database aplikasi. PPN, retur otomatis, dan kurs real-time tidak diaktifkan. Penjadwalan backup harus dipasang sendiri mengikuti panduan operasi.

`install_script` dan `start_skill` telah berhasil disimpan pada draft konfigurasi cloud; langkah instalasinya dieksekusi dan diverifikasi. Instruksi cloud yang disimpan adalah konfigurasi untuk ditinjau. Penyimpanan draft tidak otomatis menerbitkan environment atau men-deploy situs. Pemulihan snapshot dalam task cloud baru belum diuji.
