import { defineConfig, devices } from '@playwright/test';
import { mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { existsSync } from 'node:fs';
const testData=mkdtempSync(join(tmpdir(),'reza-browser-'));
const executablePath=process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH || (existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined);
export default defineConfig({
 testDir:'./tests/browser', fullyParallel:false, workers:1, timeout:60_000,
 use:{baseURL:'http://127.0.0.1:3127',trace:'retain-on-failure',screenshot:'only-on-failure',launchOptions:{executablePath}},
 projects:[{name:'chromium',use:{...devices['Desktop Chrome']}}],
 reporter:[['list'],['html',{open:'never'}]],
 webServer:{command:'node server.mjs',url:'http://127.0.0.1:3127/api/health',reuseExistingServer:false,timeout:30_000,env:{...process.env,HOST:'127.0.0.1',PORT:'3127',DATA_DIR:testData,SECURE_COOKIES:'0'}}
});
