import { createServer } from 'node:http';
import { AsyncLocalStorage } from 'node:async_hooks';
import { randomUUID } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { dirname, join, resolve } from 'node:path';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { validateState, emptyState } from './accounting.js';
import { openStore, transaction as storeTransaction } from './server/storage.mjs';
import { token, digest, equal, checkPassword, hashPassword, verifyPassword, newTotpSecret, verifyTotp, seal, unseal } from './server/security.mjs';

const ROOT = dirname(fileURLToPath(import.meta.url));
const MAX_FILE = 5 * 1024 * 1024, MAX_BACKUP = 100 * 1024 * 1024;
const STATIC = new Map([
  ['/', ['index.html', 'text/html; charset=utf-8']], ['/index.html', ['index.html', 'text/html; charset=utf-8']],
  ...['app.js', 'accounting.js', 'backup.js', 'export.js', 'sw.js'].map(file => [`/${file}`, [file, 'text/javascript; charset=utf-8']]),
  ['/styles.css', ['styles.css', 'text/css; charset=utf-8']], ['/manifest.json', ['manifest.json', 'application/manifest+json']], ['/icon.svg', ['icon.svg', 'image/svg+xml']],
]);
class HttpError extends Error { constructor(status, message, code) { super(message); this.status = status; this.code = code; } }
const fail = (status, message, code) => { throw new HttpError(status, message, code); };
const plain = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const localAddress = value => ['127.0.0.1', '::1', '::ffff:127.0.0.1', 'localhost'].includes(value);
const userView = user => ({ id: user.id, username: user.username, displayName: user.display_name, role: user.role, mfaEnabled: Boolean(user.mfa_secret), disabled: Boolean(user.disabled), email: user.email || '', phone: user.phone || '', avatar: user.avatar || '' });

function normalizedState(value) { try { return validateState(value); } catch (error) { fail(400, error.message || 'Data akuntansi tidak valid.'); } }
function username(value) { if (typeof value !== 'string' || !/^[A-Za-z0-9_.-]{3,50}$/.test(value)) fail(400, 'Username harus 3–50 karakter huruf, angka, titik, garis bawah, atau tanda minus.'); return value.toLowerCase(); }
function password(value) { try { checkPassword(value); } catch (error) { fail(400, error.message); } return value; }
function displayName(value, fallback) { if (value === undefined) return fallback; if (typeof value !== 'string' || !value.trim() || value.length > 100) fail(400, 'Nama tampilan harus 1–100 karakter.'); return value.trim(); }
function role(value) { if (!['owner', 'operator', 'reader'].includes(value)) fail(400, 'Peran pengguna tidak valid.'); return value; }
async function readJson(req, limit = 20 * 1024 * 1024) {
  if (!/^application\/json(?:\s*;|$)/i.test(req.headers['content-type'] || '')) fail(415, 'Gunakan Content-Type application/json.');
  if (Number(req.headers['content-length']) > limit) fail(413, 'Ukuran data melebihi batas.');
  const chunks = []; let size = 0;
  for await (const chunk of req) { size += chunk.length; if (size > limit) fail(413, 'Ukuran data melebihi batas.'); chunks.push(chunk); }
  let data; try { data = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { fail(400, 'JSON tidak valid.'); }
  if (!plain(data)) fail(400, 'Isi permintaan harus objek JSON.');
  return data;
}
function attachment(value, state) {
  if (!plain(value) || typeof value.name !== 'string' || !value.name.trim() || value.name.length > 200 || /[\x00-\x1f\x7f/\\]/.test(value.name)) fail(400, 'Nama lampiran tidak valid.');
  if (!state.j.some(j => String(j.id) === String(value.journalId))) fail(400, 'Transaksi lampiran tidak ditemukan.');
  if (typeof value.data !== 'string' || value.data.length > Math.ceil(MAX_FILE / 3) * 4 || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(value.data)) fail(400, 'Lampiran base64 tidak valid atau lebih dari 5 MiB.');
  const data = Buffer.from(value.data, 'base64');
  const signatures = { 'application/pdf': Buffer.from('%PDF-'), 'image/png': Buffer.from([137,80,78,71,13,10,26,10]), 'image/jpeg': Buffer.from([255,216,255]) };
  const magic = signatures[value.type];
  if (!magic || data.length < magic.length || data.length > MAX_FILE || !data.subarray(0, magic.length).equals(magic)) fail(400, 'Hanya berkas PDF, PNG, atau JPEG valid hingga 5 MiB yang diizinkan.');
  return { id: randomUUID(), journalId: String(value.journalId), name: value.name.trim(), type: value.type, size: data.length, data };
}

export function createApplication(options = {}) {
  const host = options.host ?? process.env.HOST ?? '127.0.0.1';
  const port = Number(options.port ?? process.env.PORT ?? 3000);
  const secure = options.secureCookies ?? process.env.SECURE_COOKIES === '1';
  const originSetting = options.appOrigin ?? process.env.APP_ORIGIN ?? '';
  let appOrigin;
  if (originSetting) {
    try { appOrigin = new URL(originSetting); } catch { throw new Error('APP_ORIGIN harus berupa origin HTTP/HTTPS yang valid.'); }
    if (!['http:', 'https:'].includes(appOrigin.protocol) || appOrigin.username || appOrigin.password || appOrigin.origin !== originSetting) throw new Error('APP_ORIGIN harus berupa origin HTTP/HTTPS tanpa path atau garis miring akhir.');
    if (appOrigin.protocol === 'https:' && !secure) throw new Error('Gunakan SECURE_COOKIES=1 bersama APP_ORIGIN HTTPS.');
  }
  const { db, key, dataDir } = openStore(options.dataDir ?? process.env.DATA_DIR ?? join(ROOT, 'data'));
  const initialized = () => db.prepare('SELECT COUNT(*) AS n FROM users').get().n > 0;
  if (!localAddress(host) && !initialized()) { db.close(); throw new Error('Inisialisasi akun pemilik melalui HOST=127.0.0.1 sebelum membuka akses jaringan.'); }
  if (!db.prepare('SELECT id FROM book WHERE id=1').get()) db.prepare('INSERT INTO book VALUES (1, ?, 0)').run(JSON.stringify(emptyState()));
  db.prepare('DELETE FROM sessions WHERE expires < ?').run(Date.now());
  const failures = new Map();
  const context = new AsyncLocalStorage();
  function transaction(database, callback) {
    return storeTransaction(database, () => {
      const active = context.getStore();
      if (active?.user) {
        const fresh = session(active.req); // Authorization may change while reading a body or hashing a password.
        if (fresh.role !== active.user.role || fresh.password_hash !== active.user.password_hash) fail(401, 'Akun berubah selama permintaan. Muat ulang dan coba kembali.');
      }
      return callback();
    });
  }
  const stateRow = () => { const row = db.prepare('SELECT state, revision FROM book WHERE id=1').get(); return { state: JSON.parse(row.state), revision: row.revision }; };
  const audit = (user, action, detail = {}) => db.prepare('INSERT INTO audit (at,user,action,detail) VALUES (?,?,?,?)').run(new Date().toISOString(), user?.username || 'system', action, JSON.stringify(detail));
  function json(res, status, value) { res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' }); res.end(JSON.stringify(value)); }
  function owner(user) { if (user.role !== 'owner') fail(403, 'Hanya pemilik yang memiliki akses.'); }
  function writer(user) { if (!['owner', 'operator'].includes(user.role)) fail(403, 'Pengguna pembaca tidak dapat mengubah data.'); }
  function setCookie(res, value, clear = false) { res.setHeader('Set-Cookie', `kr_session=${value}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${clear ? 0 : 43200}${secure ? '; Secure' : ''}`); }
  function session(req) {
    const cookie = (req.headers.cookie || '').split(';').map(v => v.trim()).find(v => v.startsWith('kr_session='))?.slice(11);
    if (!cookie || !/^[A-Za-z0-9_-]{43}$/.test(cookie)) fail(401, 'Silakan masuk terlebih dahulu.');
    const row = db.prepare(`SELECT u.*,s.id AS session_id,s.csrf,s.expires FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.id=? AND s.expires>? AND u.disabled=0`).get(digest(cookie), Date.now());
    if (!row) fail(401, 'Sesi telah berakhir. Silakan masuk kembali.');
    if (!['GET', 'HEAD'].includes(req.method) && !equal(row.csrf, req.headers['x-csrf-token'])) fail(403, 'Token keamanan tidak valid. Muat ulang halaman.');
    return row;
  }
  function createSession(user, res) {
    const value = token(), csrf = token();
    db.prepare('INSERT INTO sessions VALUES (?,?,?,?,?)').run(digest(value), user.id, csrf, Date.now() + 43200000, new Date().toISOString());
    setCookie(res, value); return { user: userView(user), csrfToken: csrf };
  }
  function throttle(keyName, limit) {
    const now = Date.now(); let item = failures.get(keyName);
    if (!item || item.until <= now) { item = { n: 0, until: now + 900000 }; failures.set(keyName, item); }
    if (++item.n > limit) fail(429, 'Terlalu banyak percobaan. Coba lagi dalam 15 menit.');
    if (failures.size > 10000) for (const [name, row] of failures) if (row.until <= now) failures.delete(name);
  }
  function mfaValid(user, code) {
    if (typeof code !== 'string') return false;
    const counter = verifyTotp(unseal(user.mfa_secret, key), code.replace(/\s/g, ''), user.mfa_counter);
    if (counter !== null) { db.prepare('UPDATE users SET mfa_counter=? WHERE id=?').run(counter, user.id); return true; }
    const hashed = digest(code.replace(/[\s-]/g, '').toLowerCase());
    const recovery = JSON.parse(user.recovery_codes), index = recovery.findIndex(value => equal(value, hashed));
    if (index < 0) return false;
    recovery.splice(index, 1); db.prepare('UPDATE users SET recovery_codes=? WHERE id=?').run(JSON.stringify(recovery), user.id); return true;
  }
  function exportBackup() {
    return { format: 'keuangan-reza-data', version: 1, state: stateRow().state, attachments: db.prepare('SELECT * FROM attachments ORDER BY created_at,id').all().map(a => ({ id: a.id, journalId: a.journal_id, name: a.name, type: a.type, size: a.size, data: Buffer.from(a.data).toString('base64') })), exportedAt: new Date().toISOString() };
  }
  function snapshot() {
    const folder = join(dataDir, 'snapshots'); mkdirSync(folder, { recursive: true, mode: 0o700 });
    const filename = `before-restore-${new Date().toISOString().replace(/[:.]/g, '-')}-${randomUUID()}.json`;
    writeFileSync(join(folder, filename), JSON.stringify(exportBackup()), { mode: 0o600, flag: 'wx' }); return filename;
  }
  function checkRevision(revision, current) { if (!Number.isSafeInteger(revision) || revision !== current.revision) fail(409, 'Data telah berubah di sesi lain. Muat ulang sebelum menyimpan.', 'REVISION_CONFLICT'); }
  function protectJournal(oldState, nextState) {
    if (!oldState.closedThrough) return;
    const old = new Map(oldState.j.map(j => [String(j.id), j])), next = new Map(nextState.j.map(j => [String(j.id), j]));
    for (const [id, j] of old) if (j.tgl <= oldState.closedThrough && !same(j, next.get(id))) fail(423, 'Transaksi berada pada periode terkunci. Pemilik harus membuka periode terlebih dahulu.');
    for (const [id, j] of next) if (j.tgl <= oldState.closedThrough && !same(j, old.get(id))) fail(423, 'Penambahan atau pemindahan transaksi ke periode terkunci tidak diizinkan.');
  }
  function persistBook(next, current, user, action) {
    const before = new Map(current.state.j.map(j => [String(j.id), j])), after = new Map(next.j.map(j => [String(j.id), j]));
    const changes = [...new Set([...before.keys(), ...after.keys()])].filter(id => !same(before.get(id), after.get(id))).map(id => ({ id, before: before.get(id) ?? null, after: after.get(id) ?? null }));
    db.prepare('UPDATE book SET state=?, revision=revision+1 WHERE id=1').run(JSON.stringify(next));
    for (const row of db.prepare('SELECT id,journal_id FROM attachments').all()) if (!after.has(row.journal_id)) db.prepare('DELETE FROM attachments WHERE id=?').run(row.id);
    audit(user, action, { revision: current.revision + 1, journals: changes, masterChanges: Object.keys(next).filter(k => k !== 'j' && !same(next[k], current.state[k])).map(k => ({ field: k, before: current.state[k], after: next[k] })) });
    return { state: next, revision: current.revision + 1 };
  }

  const server = createServer((req, res) => context.run({ req }, async () => {
    res.setHeader('X-Content-Type-Options', 'nosniff'); res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Referrer-Policy', 'same-origin'); res.setHeader('Cache-Control', 'no-store');
    res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
    res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data: blob:; connect-src 'self'; font-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'; worker-src 'self'");
    if (secure) res.setHeader('Strict-Transport-Security', 'max-age=31536000');
    try {
      let url; try { url = new URL(req.url, 'http://local.invalid'); } catch { fail(400, 'URL tidak valid.'); }
      const path = url.pathname, method = req.method;
      let requestHost;
      try {
        requestHost = new URL(`http://${req.headers.host}`);
        if (!req.headers.host || requestHost.username || requestHost.password || requestHost.host !== req.headers.host || requestHost.pathname !== '/' || requestHost.search || requestHost.hash) fail(400, 'Host tidak valid.');
      } catch { fail(400, 'Host tidak valid.'); }
      const localHost = localAddress(requestHost.hostname.replace(/^\[|\]$/g, ''));
      if ((localAddress(host) || appOrigin) && !localHost && requestHost.host !== appOrigin?.host) fail(403, 'Host tidak diizinkan.');
      if (!['GET', 'HEAD'].includes(method) && req.headers.origin) {
        const expected = requestHost.host === appOrigin?.host ? appOrigin.origin : `${secure ? 'https' : 'http'}://${req.headers.host}`;
        if (req.headers.origin !== expected) fail(403, 'Asal permintaan tidak diizinkan.');
      }
      if (!path.startsWith('/api/')) {
        if (!['GET', 'HEAD'].includes(method) || !STATIC.has(path)) fail(404, 'Halaman tidak ditemukan.');
        const [file, type] = STATIC.get(path); let content; try { content = readFileSync(join(ROOT, file)); } catch { fail(404, 'Berkas aplikasi tidak ditemukan.'); }
        res.writeHead(200, { 'Content-Type': type, 'Content-Length': content.length }); return res.end(method === 'HEAD' ? undefined : content);
      }
      if (path === '/api/health' && method === 'GET') return json(res, 200, { ok: true });
      if (path === '/api/status' && method === 'GET') return json(res, 200, { initialized: initialized() });
      if (path === '/api/setup' && method === 'POST') {
        if (!localAddress(host) || !localHost || !localAddress(req.socket.remoteAddress)) fail(403, 'Pembuatan pemilik hanya tersedia melalui koneksi dan Host lokal.');
        if (initialized()) fail(409, 'Aplikasi sudah diinisialisasi.');
        throttle(`setup:${req.socket.remoteAddress}`, 10);
        const body = await readJson(req, 4096), name = username(body.username), pass = await hashPassword(password(body.password));
        const user = { id: randomUUID(), username: name, display_name: displayName(body.displayName, name), password_hash: pass, role: 'owner', disabled: 0 };
        const result = transaction(db, () => { if (initialized()) fail(409, 'Aplikasi sudah diinisialisasi.'); db.prepare('INSERT INTO users (id,username,display_name,password_hash,role,created_at) VALUES (?,?,?,?,?,?)').run(user.id, name, user.display_name, pass, 'owner', new Date().toISOString()); audit(user, 'setup'); return createSession(user, res); });
        return json(res, 201, result);
      }
      if (path === '/api/login' && method === 'POST') {
        const body = await readJson(req, 4096), name = typeof body.username === 'string' ? body.username.toLowerCase() : '';
        throttle(`ip:${req.socket.remoteAddress}`, 100); throttle(`login:${req.socket.remoteAddress}:${name}`, 12);
        let user = db.prepare('SELECT * FROM users WHERE username=?').get(name);
        if (!(await verifyPassword(body.password, user?.password_hash)) || !user || user.disabled) fail(401, 'Username atau kata sandi salah.');
        const verifiedHash = user.password_hash;
        const result = transaction(db, () => {
          user = db.prepare('SELECT * FROM users WHERE id=?').get(user.id);
          if (!user || user.disabled || user.password_hash !== verifiedHash) fail(401, 'Username atau kata sandi salah.');
          if (user.mfa_secret && !body.code) fail(401, 'Masukkan kode autentikator atau kode pemulihan.', 'MFA_REQUIRED');
          if (user.mfa_secret && !mfaValid(user, body.code)) fail(401, 'Kode autentikator atau pemulihan tidak valid atau sudah digunakan.');
          audit(user, 'login'); return createSession(user, res);
        });
        failures.delete(`login:${req.socket.remoteAddress}:${name}`); return json(res, 200, result);
      }
      const user = session(req);
      context.getStore().user = user;
      if (path === '/api/session' && method === 'GET') return json(res, 200, { user: userView(user), csrfToken: user.csrf });
      if (path === '/api/profile' && method === 'PATCH') {
        const body = await readJson(req, 360 * 1024);
        if (!Object.keys(body).length || Object.keys(body).some(k => !['displayName', 'email', 'phone', 'avatar'].includes(k))) fail(400, 'Perubahan profil tidak valid.');
        const label = displayName(body.displayName, user.display_name), email = body.email === undefined ? user.email : body.email, phone = body.phone === undefined ? user.phone : body.phone, avatar = body.avatar === undefined ? user.avatar : body.avatar;
        if (typeof email !== 'string' || email.length > 254 || (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))) fail(400, 'Alamat email tidak valid.');
        if (typeof phone !== 'string' || phone.length > 40 || (phone && !/^[0-9+(). -]+$/.test(phone))) fail(400, 'Nomor telepon tidak valid.');
        if (typeof avatar !== 'string') fail(400, 'Foto profil tidak valid.');
        if (avatar) {
          const match = /^data:(image\/(?:png|jpeg));base64,([A-Za-z0-9+/]+={0,2})$/.exec(avatar);
          if (!match || match[2].length > Math.ceil(256 * 1024 / 3) * 4) fail(400, 'Foto profil harus PNG/JPEG hingga 256 KiB.');
          const data = Buffer.from(match[2], 'base64'), magic = match[1] === 'image/png' ? Buffer.from([137,80,78,71,13,10,26,10]) : Buffer.from([255,216,255]);
          if (data.length > 256 * 1024 || !data.subarray(0, magic.length).equals(magic)) fail(400, 'Isi foto profil tidak sesuai format.');
        }
        const result = transaction(db, () => { const fresh = db.prepare('SELECT * FROM users WHERE id=?').get(user.id); db.prepare('UPDATE users SET display_name=?,email=?,phone=?,avatar=? WHERE id=?').run(body.displayName === undefined ? fresh.display_name : label, body.email === undefined ? fresh.email : email, body.phone === undefined ? fresh.phone : phone, body.avatar === undefined ? fresh.avatar : avatar, user.id); audit(user, 'profile.updated', { fields: Object.keys(body) }); return db.prepare('SELECT * FROM users WHERE id=?').get(user.id); });
        return json(res, 200, { user: userView(result) });
      }
      if (path === '/api/logout' && method === 'POST') { db.prepare('DELETE FROM sessions WHERE id=?').run(user.session_id); setCookie(res, '', true); return json(res, 200, { ok: true }); }
      if (path === '/api/password' && method === 'POST') {
        throttle(`password:${user.id}`, 12); const body = await readJson(req, 4096);
        if (!await verifyPassword(body.currentPassword, user.password_hash)) fail(403, 'Kata sandi saat ini salah.');
        const pass = await hashPassword(password(body.newPassword));
        transaction(db, () => { db.prepare('UPDATE users SET password_hash=? WHERE id=?').run(pass, user.id); db.prepare('DELETE FROM sessions WHERE user_id=? AND id!=?').run(user.id, user.session_id); audit(user, 'password.changed'); });
        return json(res, 200, { ok: true });
      }
      if (path === '/api/sessions/revoke' && method === 'POST') { transaction(db, () => { db.prepare('DELETE FROM sessions WHERE user_id=? AND id!=?').run(user.id, user.session_id); audit(user, 'sessions.revoked'); }); return json(res, 200, { ok: true }); }
      if (path === '/api/state' && method === 'GET') return json(res, 200, stateRow());
      if (path === '/api/state' && method === 'PUT') {
        writer(user); const body = await readJson(req), next = normalizedState(body.state);
        const result = transaction(db, () => {
          const current = stateRow(); checkRevision(body.revision, current);
          if (user.role !== 'owner') for (const k of new Set([...Object.keys(next), ...Object.keys(current.state)])) if (k !== 'j' && !same(next[k], current.state[k])) fail(403, 'Operator hanya dapat mengubah transaksi jurnal.');
          if (user.role !== 'owner') {
            const oldClosing=current.state.j.filter(j=>j.jn==='T'), newClosing=next.j.filter(j=>j.jn==='T');
            if (!same(oldClosing,newClosing)) fail(403, 'Hanya pemilik yang dapat mengubah jurnal penutup.');
          }
          if (next.closedThrough < current.state.closedThrough && !same(next.j, current.state.j)) fail(400, 'Buka kunci periode dalam penyimpanan terpisah sebelum mengubah jurnal.');
          protectJournal(current.state, next); return persistBook(next, current, user, 'state.updated');
        }); return json(res, 200, result);
      }
      if (path === '/api/users' && method === 'GET') { owner(user); return json(res, 200, { users: db.prepare('SELECT * FROM users ORDER BY username').all().map(userView) }); }
      if (path === '/api/users' && method === 'POST') {
        owner(user); const body = await readJson(req, 4096), name = username(body.username), selectedRole = role(body.role), label = displayName(body.displayName, name), hash = await hashPassword(password(body.password)), id = randomUUID();
        transaction(db, () => { if (db.prepare('SELECT id FROM users WHERE username=?').get(name)) fail(409, 'Username sudah digunakan.'); db.prepare('INSERT INTO users (id,username,display_name,password_hash,role,created_at) VALUES (?,?,?,?,?,?)').run(id, name, label, hash, selectedRole, new Date().toISOString()); audit(user, 'user.created', { id, username: name, role: selectedRole }); });
        return json(res, 201, { user: userView(db.prepare('SELECT * FROM users WHERE id=?').get(id)) });
      }
      if (/^\/api\/users\/[^/]+$/.test(path) && method === 'PATCH') {
        owner(user); const body = await readJson(req, 4096), id = path.split('/').at(-1);
        if (!Object.keys(body).length || Object.keys(body).some(k => !['role', 'disabled', 'password'].includes(k))) fail(400, 'Perubahan pengguna tidak valid.');
        if (body.disabled !== undefined && typeof body.disabled !== 'boolean') fail(400, 'Status nonaktif harus boolean.');
        const newRole = body.role === undefined ? undefined : role(body.role), hash = body.password === undefined ? undefined : await hashPassword(password(body.password));
        const changed = transaction(db, () => {
          const target = db.prepare('SELECT * FROM users WHERE id=?').get(id); if (!target) fail(404, 'Pengguna tidak ditemukan.');
          const selectedRole = newRole ?? target.role, disabled = body.disabled === undefined ? target.disabled : Number(body.disabled);
          if (id === user.id && disabled) fail(400, 'Akun sendiri tidak dapat dinonaktifkan.');
          if (target.role === 'owner' && !target.disabled && (selectedRole !== 'owner' || disabled) && db.prepare("SELECT COUNT(*) AS n FROM users WHERE role='owner' AND disabled=0").get().n <= 1) fail(400, 'Minimal satu pemilik aktif harus tetap tersedia.');
          db.prepare('UPDATE users SET role=?,disabled=?,password_hash=? WHERE id=?').run(selectedRole, disabled, hash ?? target.password_hash, id);
          if (hash || disabled || selectedRole !== target.role) db.prepare('DELETE FROM sessions WHERE user_id=?').run(id);
          audit(user, 'user.updated', { id, role: selectedRole, disabled: Boolean(disabled), passwordChanged: Boolean(hash) }); return db.prepare('SELECT * FROM users WHERE id=?').get(id);
        }); return json(res, 200, { user: userView(changed) });
      }
      if (path === '/api/audit' && method === 'GET') { owner(user); return json(res, 200, { events: db.prepare('SELECT * FROM audit ORDER BY id DESC LIMIT 500').all().map(a => ({ ...a, detail: JSON.parse(a.detail) })) }); }
      if (path === '/api/mfa/setup' && method === 'POST') {
        if (user.mfa_secret) fail(409, 'Autentikator sudah aktif. Nonaktifkan sebelum mengganti.');
        const secret = newTotpSecret(); db.prepare('UPDATE users SET mfa_pending=?,mfa_pending_at=? WHERE id=?').run(seal(secret, key), Date.now(), user.id);
        return json(res, 200, { secret, uri: `otpauth://totp/${encodeURIComponent(`Keuangan Reza:${user.username}`)}?secret=${secret}&issuer=Keuangan%20Reza&algorithm=SHA1&digits=6&period=30` });
      }
      if (path === '/api/mfa/enable' && method === 'POST') {
        throttle(`mfa:${user.id}`, 12); const body = await readJson(req, 4096);
        const recoveryCodes = Array.from({ length: 10 }, () => token().slice(0, 16).toLowerCase().replace(/[_-]/g, 'a'));
        transaction(db, () => {
          const fresh = db.prepare('SELECT * FROM users WHERE id=?').get(user.id);
          if (fresh.mfa_secret || !fresh.mfa_pending || Date.now() - fresh.mfa_pending_at > 600000) fail(400, 'Pengaturan autentikator berakhir. Mulai kembali.');
          const counter = verifyTotp(unseal(fresh.mfa_pending, key), body.code);
          if (counter === null) fail(400, 'Kode autentikator tidak valid.');
          db.prepare('UPDATE users SET mfa_secret=mfa_pending,mfa_pending=NULL,mfa_pending_at=NULL,mfa_counter=?,recovery_codes=? WHERE id=?').run(counter, JSON.stringify(recoveryCodes.map(digest)), user.id);
          db.prepare('DELETE FROM sessions WHERE user_id=? AND id!=?').run(user.id, user.session_id); audit(user, 'mfa.enabled');
        }); return json(res, 200, { recoveryCodes });
      }
      if (path === '/api/mfa/disable' && method === 'POST') {
        throttle(`mfa:${user.id}`, 12); const body = await readJson(req, 4096);
        if (!await verifyPassword(body.password, user.password_hash)) fail(403, 'Kata sandi salah.');
        transaction(db, () => { const fresh = db.prepare('SELECT * FROM users WHERE id=?').get(user.id); if (!fresh.mfa_secret || !mfaValid(fresh, body.code)) fail(403, 'Kode autentikator atau pemulihan tidak valid.'); db.prepare("UPDATE users SET mfa_secret=NULL,mfa_pending=NULL,mfa_pending_at=NULL,mfa_counter=-1,recovery_codes='[]' WHERE id=?").run(user.id); db.prepare('DELETE FROM sessions WHERE user_id=? AND id!=?').run(user.id, user.session_id); audit(user, 'mfa.disabled'); });
        return json(res, 200, { ok: true });
      }
      if (path === '/api/backup' && method === 'GET') { owner(user); audit(user, 'backup.exported'); return json(res, 200, exportBackup()); }
      if (path === '/api/restore' && method === 'POST') {
        owner(user); const body = await readJson(req, Math.ceil(MAX_BACKUP * 4 / 3) + 22 * 1024 * 1024);
        if (!plain(body.backup) || body.backup.format !== 'keuangan-reza-data' || body.backup.version !== 1 || !Array.isArray(body.backup.attachments)) fail(400, 'Format backup tidak dikenali.');
        const next = normalizedState(body.backup.state), attached = body.backup.attachments.map(a => attachment(a, next));
        if (attached.reduce((sum, a) => sum + a.size, 0) > MAX_BACKUP) fail(400, 'Total lampiran backup melebihi 100 MiB.');
        const result = transaction(db, () => {
          const current = stateRow(); checkRevision(body.revision, current); const snapshotFile = snapshot();
          const result = persistBook(next, current, user, 'backup.restored'); db.prepare('DELETE FROM attachments').run();
          const insert = db.prepare('INSERT INTO attachments VALUES (?,?,?,?,?,?,?)'); for (const a of attached) insert.run(a.id, a.journalId, a.name, a.type, a.size, a.data, new Date().toISOString());
          audit(user, 'restore.snapshot', { filename: snapshotFile, attachments: attached.length }); return result;
        }); return json(res, 200, result);
      }
      if (path === '/api/attachments' && method === 'GET') {
        const journalId = url.searchParams.get('journalId'); if (journalId === null) fail(400, 'journalId wajib diisi.');
        return json(res, 200, { attachments: db.prepare('SELECT id,journal_id AS journalId,name,type,size FROM attachments WHERE journal_id=? ORDER BY created_at,id').all(journalId) });
      }
      if (path === '/api/attachments' && method === 'POST') {
        writer(user); const body = await readJson(req, 7 * 1024 * 1024);
        const result = transaction(db, () => { const state = stateRow().state, a = attachment(body, state), journal = state.j.find(j => String(j.id) === a.journalId); if (state.closedThrough && journal.tgl <= state.closedThrough) fail(423, 'Bukti transaksi pada periode terkunci tidak dapat diubah.'); if (db.prepare('SELECT COALESCE(SUM(size),0) AS total FROM attachments').get().total + a.size > MAX_BACKUP) fail(400, 'Total lampiran dibatasi 100 MiB agar backup dapat dipulihkan.'); db.prepare('INSERT INTO attachments VALUES (?,?,?,?,?,?,?)').run(a.id, a.journalId, a.name, a.type, a.size, a.data, new Date().toISOString()); audit(user, 'attachment.created', { id: a.id, journalId: a.journalId, name: a.name }); const { data, ...meta } = a; return meta; });
        return json(res, 201, result);
      }
      if (/^\/api\/attachments\/[^/]+$/.test(path) && ['GET', 'DELETE'].includes(method)) {
        const id = path.split('/').at(-1), a = db.prepare('SELECT * FROM attachments WHERE id=?').get(id); if (!a) fail(404, 'Lampiran tidak ditemukan.');
        if (method === 'GET') { res.writeHead(200, { 'Content-Type': a.type, 'Content-Length': a.size, 'Content-Disposition': `attachment; filename="evidence"; filename*=UTF-8''${encodeURIComponent(a.name).replace(/['()*]/g, c => `%${c.charCodeAt(0).toString(16).toUpperCase()}`)}` }); return res.end(Buffer.from(a.data)); }
        writer(user); transaction(db, () => { const state = stateRow().state, journal = state.j.find(j => String(j.id) === a.journal_id); if (state.closedThrough && journal?.tgl <= state.closedThrough) fail(423, 'Bukti transaksi pada periode terkunci tidak dapat dihapus.'); db.prepare('DELETE FROM attachments WHERE id=?').run(id); audit(user, 'attachment.deleted', { id, journalId: a.journal_id, name: a.name }); }); return json(res, 200, { ok: true });
      }
      fail(404, 'API tidak ditemukan.');
    } catch (error) {
      if (!res.headersSent) json(res, error instanceof HttpError ? error.status : 500, { error: error instanceof HttpError ? error.message : 'Terjadi kesalahan server. Coba lagi atau hubungi pengelola.', ...(error.code && error instanceof HttpError ? { code: error.code } : {}) });
      else res.end();
      if (!(error instanceof HttpError)) console.error('Server error:', error.message);
    }
  }));
  server.requestTimeout = 30000; server.headersTimeout = 10000; server.keepAliveTimeout = 5000;
  return { server, db, dataDir,
    listen: () => new Promise((resolveListen, reject) => { server.once('error', reject); server.listen(port, host, () => { server.removeListener('error', reject); resolveListen(server.address()); }); }),
    close: () => new Promise((resolveClose, reject) => { if (!server.listening) { db.close(); return resolveClose(); } server.close(error => { db.close(); if (error) reject(error); else resolveClose(); }); server.closeIdleConnections(); }),
  };
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    const app = createApplication(); const address = await app.listen();
    console.log(`Keuangan Reza berjalan di http://${address.family === 'IPv6' ? `[${address.address}]` : address.address}:${address.port}`);
    for (const signal of ['SIGINT', 'SIGTERM']) process.once(signal, () => { app.close().then(() => process.exit(0), () => process.exit(1)); });
  } catch (error) { console.error(error.message); process.exitCode = 1; }
}
