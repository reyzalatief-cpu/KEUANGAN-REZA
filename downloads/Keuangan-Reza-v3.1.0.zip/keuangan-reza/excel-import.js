import { validateState } from './accounting.js';

const field = (key,label,required=false,aliases=[]) => ({key,label,required,aliases});
const master = [field('kode','Kode',true,['code','sku']),field('nama','Nama',true,['name'])];
export const IMPORT_KINDS = [
  {id:'journals',label:'Jurnal / saldo awal',description:'Satu nomor untuk seluruh baris jurnal yang sama. Debit dan kredit wajib seimbang. Jenis A = saldo awal, U = umum, P = penyesuaian.',fields:[
    field('nomor','Nomor transaksi',true,['id','nomor transaksi','nomor jurnal','no bukti']),field('tanggal','Tanggal',true,['date']),field('jenis','Jenis jurnal',false,['type']),field('keterangan','Keterangan',true,['description','deskripsi']),field('kode_akun','Kode akun',true,['akun','account','account code']),field('debit','Debit',true,['debet']),field('kredit','Kredit',true,['credit']),field('kode_bantu','Kode kontak / produk',false,['kode bantu','contact','produk']),field('kuantitas','Kuantitas',false,['qty','quantity']),field('referensi','Referensi',false,['reference']),field('kategori','Kategori arus kas',false,['cash category'])]},
  {id:'cash',label:'Kas masuk / keluar',description:'Satu baris menjadi satu jurnal kas. Arah Masuk/Keluar, jumlah positif, akun lawan terdaftar. Persediaan/HPP memakai jurnal lengkap.',fields:[
    field('nomor','Nomor transaksi',true,['id','nomor transaksi','no bukti']),field('tanggal','Tanggal',true,['date']),field('keterangan','Keterangan',true,['description','deskripsi']),field('arah','Arah (Masuk/Keluar)',true,['direction']),field('jumlah','Jumlah (Rp)',true,['amount','nominal']),field('akun_lawan','Akun lawan',true,['akun lawan','account']),field('kontak','Kode kontak',false,['contact','kode bantu']),field('kategori','Kategori arus kas',false,['cash category'])]},
  {id:'contacts',label:'Kontak',description:'Tambahkan pelanggan atau pemasok. Kode yang sudah ada tidak ditimpa.',fields:master},
  {id:'products',label:'Produk',description:'Tambahkan master produk. Harga referensi opsional, kosong berarti 0. Saldo stok dicatat melalui jurnal.',fields:[...master,field('harga','Harga referensi (Rp)',false,['price','harga jual','harga referensi (Rp)'])]},
  {id:'accounts',label:'Akun',description:'Kode akun mengikuti format 1-0000 sampai 5-9999. Gunakan 1-11xx untuk kas/bank.',fields:master},
  {id:'bank',label:'Mutasi bank',description:'Hanya menambahkan rekening koran untuk rekonsiliasi, bukan jurnal. Uang masuk positif dan keluar negatif.',fields:[field('date','Tanggal',true,['tanggal']),field('description','Keterangan',true,['keterangan','deskripsi']),field('amount','Nominal bertanda (Rp)',true,['nominal','jumlah'])]},
];
const fail = message => { throw new Error(message); };
const plain = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const blank = value => value == null || typeof value === 'string' && !value.trim();
const norm = value => String(value??'').trim().toLowerCase().replace(/[\s_\-()./]+/g,'');
const canonical = value => Array.isArray(value) ? value.map(canonical) : plain(value) ? Object.fromEntries(Object.keys(value).sort().map(key=>[key,canonical(value[key])])) : value;
const same = (a,b) => JSON.stringify(canonical(a))===JSON.stringify(canonical(b));
const at = (line,callback) => {try{return callback();}catch(error){throw new Error(`Baris Excel ${line}: ${error.message}`);}};
const text = (value,label,required=true,max=2000) => {
  if(blank(value)){if(required)fail(`${label} wajib diisi.`);return '';}
  if(typeof value!=='string' && !(typeof value==='number'&&Number.isSafeInteger(value)))fail(`${label} harus berupa teks.`);
  const result=String(value).trim();
  if(result.length>max||/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(result))fail(`${label} terlalu panjang atau berisi karakter tidak valid.`);
  return result;
};
const money = (value,label,signed=false,emptyZero=false) => {
  if(blank(value)){if(emptyZero)return 0;fail(`${label} wajib diisi.`);}
  const trimmed=typeof value==='string'?value.trim():value;
  if(typeof trimmed!=='number' && !(typeof trimmed==='string' && (signed?/^-?\d+$/:/^\d+$/).test(trimmed)))fail(`${label} harus Rupiah bulat tanpa pemisah ribuan atau simbol mata uang.`);
  const result=Number(trimmed);
  if(!Number.isSafeInteger(result)||(!signed&&result<0))fail(`${label} harus Rupiah bulat dalam batas aman.`);
  return result===0?0:result;
};
const date = value => {
  const result=value instanceof Date&&!Number.isNaN(value.valueOf())?value.toISOString().slice(0,10):text(value,'Tanggal');
  if(!/^\d{4}-\d{2}-\d{2}$/.test(result)||result<'1900-01-01'||result>'9999-12-31')fail('Tanggal harus tanggal Excel atau YYYY-MM-DD.');
  const parsed=new Date(result+'T00:00:00Z');
  if(Number.isNaN(parsed.valueOf())||parsed.toISOString().slice(0,10)!==result)fail('Tanggal tidak valid.');
  return result;
};
const number = value => {
  const result=text(value,'Nomor transaksi',true,80);
  if(!/^[A-Za-z0-9][A-Za-z0-9_.:-]*$/.test(result))fail('Nomor transaksi hanya boleh huruf, angka, titik, garis bawah, titik dua, atau tanda minus; maksimal 80 karakter.');
  return result;
};
const category = value => {
  if(blank(value))return '';
  const result=['Operasional','Investasi','Pendanaan'].find(item=>norm(item)===norm(value));
  if(!result)fail('Kategori harus Operasional, Investasi, atau Pendanaan.');
  return result;
};
export function suggestMapping(kind,headers) {
  const definition=IMPORT_KINDS.find(item=>item.id===kind);
  if(!definition||!Array.isArray(headers))return {};
  const used=new Set(), result={};
  for(const f of definition.fields){const names=[f.key,f.label,...f.aliases].map(norm);const index=headers.findIndex((value,i)=>!used.has(i)&&!blank(value)&&names.includes(norm(value)));result[f.key]=index;if(index>=0)used.add(index);}
  return result;
}

/** Return a complete validated append-only plan; never mutate the user's book. */
export function prepareImport(state,request) {
  if(!plain(request))fail('Permintaan impor tidak valid.');
  const {kind,rows,mapping,account}=request, definition=IMPORT_KINDS.find(item=>item.id===kind);
  if(!definition)fail('Jenis impor tidak dikenal.');
  if(!Array.isArray(rows)||!rows.length||rows.length>10000)fail('Isi 1 sampai 10.000 baris data per impor.');
  if(!plain(mapping))fail('Pemetaan kolom tidak valid.');
  const used=new Set(), columns={};
  for(const f of definition.fields){const index=mapping[f.key]??-1;if(!Number.isInteger(index)||index< -1||index>=100)fail(`Kolom ${f.label} tidak valid.`);if(f.required&&index<0)fail(`Pilih kolom wajib ${f.label}.`);if(index>=0&&used.has(index))fail('Satu kolom Excel tidak boleh dipakai untuk dua isian.');if(index>=0)used.add(index);columns[f.key]=index;}
  const records=[];
  rows.forEach((row,index)=>at(index+2,()=>{
    if(!Array.isArray(row)||row.length>100)fail('Format baris tidak valid atau melebihi 100 kolom.');
    for(const value of row)if(value!==null&&value!==undefined&&typeof value!=='string'&&typeof value!=='number'&&!(value instanceof Date))fail('Sel harus berupa teks, angka, atau tanggal.');
    if(row.every(blank))return;
    const values={};for(const f of definition.fields)values[f.key]=columns[f.key]<0?'':row[columns[f.key]]??'';
    records.push({values,line:index+2});
  }));
  if(!records.length)fail('Lembar tidak memiliki baris data.');
  const next=validateState(state), previews=[];let added=0,skipped=0;
  const preview=(line,values,status)=>{if(previews.length<20)previews.push([line,...values,status]);};
  const accounts=new Set(next.coa.map(row=>row[0])), contacts=new Set(next.bantu.map(row=>row[0])), products=new Set(next.prod.map(row=>row[0]));
  const journals=new Map(next.j.map(j=>[String(j.id),j]));
  function addJournal(j,line){
    const old=journals.get(j.id);
    if(old){if(!same(old,j))fail(`Nomor transaksi ${j.id.slice(6)} sudah ada dengan isi berbeda. Koreksi melalui menu Jurnal.`);skipped++;return 'Dilewati';}
    if(next.closedThrough&&j.tgl<=next.closedThrough)fail(`Tanggal berada pada periode terkunci sampai ${next.closedThrough}.`);
    const debit=j.l.reduce((sum,row)=>sum+row[1],0),credit=j.l.reduce((sum,row)=>sum+row[2],0);
    if(!Number.isSafeInteger(debit)||!Number.isSafeInteger(credit)||!debit||debit!==credit)fail('Total debit dan kredit harus seimbang dan lebih besar dari nol.');
    if(j.l.length<2||j.l.length>500)fail('Satu jurnal harus memiliki 2 sampai 500 baris.');
    journals.set(j.id,j);next.j.push(j);added++;return 'Baru';
  }
  if(['contacts','products','accounts'].includes(kind)){
    const key={contacts:'bantu',products:'prod',accounts:'coa'}[kind],existing=new Map(next[key].map(row=>[row[0],row]));
    for(const {values:v,line} of records)at(line,()=>{
      const code=text(v.kode,'Kode',true,64),name=text(v.nama,'Nama',true,200);
      if(kind==='accounts'?!/^[1-5]-\d{4}$/.test(code):!/^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/.test(code))fail('Kode master tidak valid; akun harus seperti 1-1104.');
      const row=kind==='products'?[code,name,money(v.harga,'Harga',false,true)]:[code,name],old=existing.get(code);
      if(old){if(!same(old,row))fail(`Kode ${code} sudah ada dengan nama/harga berbeda. Ubah melalui Pengaturan.`);skipped++;preview(line,row,'Dilewati');}
      else{next[key].push(row);existing.set(code,row);added++;preview(line,row,'Baru');}
    });
  }else if(kind==='journals'){
    const groups=new Map();
    for(const {values:v,line} of records)at(line,()=>{
      const num=number(v.nomor),jn=blank(v.jenis)?'U':text(v.jenis,'Jenis').toUpperCase();
      if(!['A','U','P'].includes(jn))fail('Jenis jurnal hanya A, U, atau P. Gunakan menu Penutupan Periode untuk jurnal penutup.');
      const journal={id:`excel:${num}`,tgl:date(v.tanggal),jn,ket:text(v.keterangan,'Keterangan'),l:[],reference:text(v.referensi,'Referensi',false,200)};
      const cat=category(v.kategori);if(cat)journal.cashCategory=cat;
      const code=text(v.kode_akun,'Kode akun'),debit=money(v.debit,'Debit',false,true),credit=money(v.kredit,'Kredit',false,true);
      if(!accounts.has(code))fail(`Akun ${code} belum terdaftar.`);if(debit&&credit)fail('Satu baris tidak boleh sekaligus debit dan kredit.');
      const item=[code,debit,credit],aux=text(v.kode_bantu,'Kode bantu',false,64);
      if(code==='1-2010'){
        if(!products.has(aux))fail('Produk persediaan belum terdaftar.');
        if(blank(v.kuantitas)||typeof v.kuantitas==='string'&&!/^\d+(\.\d{1,6})?$/.test(v.kuantitas.trim()))fail('Kuantitas harus positif, maksimal enam desimal dengan titik.');
        const qty=Number(v.kuantitas);if(!Number.isFinite(qty)||qty<=0||!Number.isSafeInteger(Math.round(qty*1e6))||Math.abs(qty*1e6-Math.round(qty*1e6))>0.00001)fail('Kuantitas harus positif dan maksimal enam desimal.');item.push(aux,qty);
      }else if(['1-1201','2-1101'].includes(code)){if(!contacts.has(aux))fail('Piutang/hutang wajib memakai kontak terdaftar.');if(!blank(v.kuantitas)&&Number(v.kuantitas)!==0)fail('Kuantitas hanya untuk persediaan.');item.push(aux);}
      else if(aux||!blank(v.kuantitas)&&Number(v.kuantitas)!==0)fail('Kode bantu/kuantitas hanya untuk piutang, hutang, atau persediaan.');
      if(!debit&&!credit&&code!=='1-2010')fail('Baris jurnal tanpa nominal harus dihapus.');
      const group=groups.get(num);
      if(group){if(!same({...group.j,l:[]},journal))fail(`Tanggal, jenis, keterangan, referensi, dan kategori untuk nomor ${num} harus sama.`);group.j.l.push(item);}
      else{journal.l.push(item);groups.set(num,{j:journal,line});}
    });
    for(const {j,line} of groups.values())at(line,()=>{const status=addJournal(j,line);preview(line,[j.id.slice(6),j.tgl,j.ket,j.l.reduce((sum,l)=>sum+l[1],0)],status);});
  }else if(kind==='cash'){
    if(typeof account!=='string'||!accounts.has(account)||!account.startsWith('1-11'))fail('Pilih rekening kas/bank yang terdaftar.');
    for(const {values:v,line} of records)at(line,()=>{
      const num=number(v.nomor),direction=norm(v.arah);if(!['masuk','keluar'].includes(direction))fail('Arah harus Masuk atau Keluar.');
      const amount=money(v.jumlah,'Jumlah');if(!amount)fail('Jumlah harus positif.');
      const other=text(v.akun_lawan,'Akun lawan');if(!accounts.has(other)||other===account)fail('Akun lawan harus terdaftar dan berbeda dari rekening kas/bank.');
      if(['1-2010','5-1300'].includes(other))fail('Persediaan/HPP harus diimpor melalui jurnal lengkap atau dicatat lewat transaksi dagang.');
      const incoming=direction==='masuk',cash=[account,incoming?amount:0,incoming?0:amount],opponent=[other,incoming?0:amount,incoming?amount:0],contact=text(v.kontak,'Kontak',false,64);
      if(['1-1201','2-1101'].includes(other)){if(!contacts.has(contact))fail('Kontak piutang/hutang harus terdaftar.');opponent.push(contact);}
      else if(contact)fail('Kontak hanya untuk piutang/hutang.');
      const j={id:`excel:${num}`,tgl:date(v.tanggal),jn:'U',ket:text(v.keterangan,'Keterangan'),l:incoming?[cash,opponent]:[opponent,cash],reference:''};const cat=category(v.kategori);if(cat)j.cashCategory=cat;
      const status=addJournal(j,line);preview(line,[num,j.tgl,j.ket,amount],status);
    });
  }else{
    if(typeof account!=='string'||!accounts.has(account)||!account.startsWith('1-11'))fail('Pilih rekening kas/bank yang terdaftar.');
    const signature=r=>JSON.stringify([r.account,r.date,r.description,r.amount]);
    const known=new Set(next.reconciliation.map(signature)),ids=new Set(next.reconciliation.map(r=>String(r.id)));let sequence=0;
    for(const {values:v,line} of records)at(line,()=>{
      const r={id:'',date:date(v.date),description:text(v.description,'Keterangan',true,1000),amount:money(v.amount,'Nominal',true),account,journalId:null};if(!r.amount)fail('Mutasi bank harus bernilai selain nol.');
      const sig=signature(r);let status='Dilewati';
      if(known.has(sig))skipped++;
      else{do{r.id=`excel:bank:${++sequence}`;}while(ids.has(r.id));ids.add(r.id);known.add(sig);next.reconciliation.push(r);added++;status='Baru';}
      preview(line,[r.date,r.description,r.amount],status);
    });
  }
  let normalized;try{normalized=validateState(next);}catch(error){fail(`Impor ditolak: ${error.message} Periksa baris jurnal dan data master; belum ada data disimpan.`);}
  const label={journals:'jurnal',cash:'jurnal kas',contacts:'kontak',products:'produk',accounts:'akun',bank:'mutasi bank'}[kind];
  const headers=['Baris Excel',...(['contacts','accounts'].includes(kind)?['Kode','Nama']:kind==='products'?['Kode','Nama','Harga']:kind==='bank'?['Tanggal','Keterangan','Nominal']:['Nomor','Tanggal','Keterangan','Nominal']),'Status'];
  return {state:normalized,summary:{added,skipped,label},preview:{headers,rows:previews}};
}
