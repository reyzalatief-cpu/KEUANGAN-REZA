import { balances, reports, sorted, inventory, subsidiary, closingEntries, createTrade, validateState, validateJournal } from './accounting.js';
import { encryptBackup, parseBackup } from './backup.js';
import { makeWorkbook } from './export.js';
import { IMPORT_KINDS, suggestMapping, prepareImport } from './excel-import.js';
import { readExcelFile } from './excel-reader.js';

const $ = (selector, root = document) => root.querySelector(selector);
const E = value => String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
const F = value => { const n = Number(value || 0); return n < 0 ? `(${Math.abs(n).toLocaleString('id-ID', { maximumFractionDigits: 0 })})` : n.toLocaleString('id-ID', { maximumFractionDigits: 0 }); };
const Q = value => Number(value || 0).toLocaleString('id-ID', { maximumFractionDigits: 6 });
const today = () => new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Jakarta' });
const id = () => crypto.randomUUID();
const copy = value => structuredClone(value);
const total = lines => lines.reduce((a, line) => [a[0] + Number(line[1] || 0), a[1] + Number(line[2] || 0)], [0, 0]);
const roleName = { owner: 'Pemilik', operator: 'Operator', reader: 'Pembaca' };
const kindName = { A: 'Saldo awal', U: 'Jurnal umum', P: 'Penyesuaian', T: 'Penutup' };
const nav = [['home','⌂','Beranda'],['input','＋','Input Transaksi'],['journals','▤','Jurnal'],['ledger','▥','Buku Besar'],['subsidiary','▦','Buku Bantu'],['trial','≡','Neraca Saldo'],['reports','◷','Laporan Keuangan'],['import','↑','Impor Excel'],['reconciliation','⇄','Rekonsiliasi Bank'],['closing','▣','Penutupan Periode'],['settings','⚙','Pengaturan'],['guide','?','Panduan']];
let session = null, S = null, revision = 0, tab = 'home', settingTab = 'entity', inputTab = 'manual', busy = false;
let period = { from: '', to: today() }, comparison = false, comparisonFrom = '', comparisonTo = '', ledgerAccount = '1-1101', journalSearch = '';
let manual = newManual(), manualDirty = false, masterKind = 'coa', masterEdit = null, users = null, audit = null, pendingMfa = null, recoveryCodes = null;
let backupPreview = null, attachmentJournal = null, attachmentList = [], csvPreview = [], reconAccount = '1-1102';
let excelBook = null, excelFileName = '', excelSheet = 0, excelKind = 'journals', excelMapping = {}, excelAccount = '1-1102', excelPreview = null, excelError = '';
let authMode = 'login', authMfa = false, mobileOpen = false, expiredDraft = null;
const owner = () => session?.user.role === 'owner';
const writer = () => ['owner', 'operator'].includes(session?.user.role);
function newManual() { return { id: null, tgl: today(), jn: 'U', ket: '', reference: '', cashCategory: '', l: [['', 0, 0], ['', 0, 0]] }; }
function notice(message, error = false) { $('#notice').innerHTML = `<div class="toast ${error ? 'error' : ''}"><span>${E(message)}</span><button type="button" data-action="dismiss" aria-label="Tutup pemberitahuan">×</button></div>`; }
async function api(path, options = {}) {
  const method = options.method || 'GET';
  const headers = { ...(options.body !== undefined ? { 'Content-Type': 'application/json' } : {}), ...(session?.csrfToken && method !== 'GET' ? { 'X-CSRF-Token': session.csrfToken } : {}) };
  const response = await fetch(`/api${path}`, { method, credentials: 'same-origin', headers, ...(options.body !== undefined ? { body: JSON.stringify(options.body) } : {}) });
  const data = await response.json().catch(() => ({ error: 'Server mengirim respons yang tidak dapat dibaca.' }));
  if (!response.ok) {
    const error = new Error(data.error || `Permintaan gagal (${response.status}).`); error.code = data.code; error.status = response.status;
    if (response.status === 401 && session && !['/password','/mfa/disable'].includes(path)) { const retainedDraft=manualDirty?{userId:session.user.id,manual:copy(manual)}:null;resetPrivateState();expiredDraft=retainedDraft;authMode='login';renderAuth('Sesi berakhir. Masuk kembali dengan akun yang sama untuk melanjutkan draf jurnal.'); }
    throw error;
  }
  return data;
}
async function task(action) {
  if (busy) return; busy = true; document.body.setAttribute('aria-busy', 'true');
  try { await action(); } catch (error) { notice(error.status === 409 ? `${error.message} Muat ulang data sebelum mencoba lagi; draf jurnal Anda tetap tersedia.` : error.message, true); }
  finally { busy = false; document.body.removeAttribute('aria-busy'); }
}
async function refresh() { const result = await api('/state'); S = result.state; revision = result.revision; }
async function persist(next, message = 'Perubahan tersimpan.') {
  const normalized = validateState(next);
  const result = await api('/state', { method: 'PUT', body: { state: normalized, revision } });
  S = result.state; revision = result.revision; if (message) notice(message);
}
function options(items, selected, placeholder = '') { return (placeholder ? `<option value="">${E(placeholder)}</option>` : '') + items.map(([value, label]) => `<option value="${E(value)}"${String(value) === String(selected) ? ' selected' : ''}>${E(value)} · ${E(label)}</option>`).join(''); }
function accountOptions(selected, cashOnly = false) { return options(S.coa.filter(([code]) => !cashOnly || code.startsWith('1-11')), selected, cashOnly ? '' : 'Pilih akun'); }
function field(label, name, value = '', type = 'text', extra = '') { return `<div class="field"><label for="${E(name)}">${E(label)}</label><input id="${E(name)}" name="${E(name)}" type="${type}" value="${E(value)}" ${extra}></div>`; }
function selectField(label, name, content, extra = '') { return `<div class="field"><label for="${E(name)}">${E(label)}</label><select id="${E(name)}" name="${E(name)}" ${extra}>${content}</select></div>`; }
function table(headers, rows, numeric = []) { return `<div class="table-wrap"><table><thead><tr>${headers.map((header, i) => `<th scope="col"${numeric.includes(i) ? ' class="money"' : ''}>${E(header)}</th>`).join('')}</tr></thead><tbody>${rows.map(row => `<tr${row.bold ? ' class="total"' : ''}>${(row.cells || row).map((cell, i) => `<td${numeric.includes(i) ? ' class="money"' : ''}>${cell ?? ''}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`; }
function empty(title, description, action = '') { return `<div class="empty"><span class="empty-icon" aria-hidden="true">▤</span><strong>${E(title)}</strong><p>${E(description)}</p>${action}</div>`; }
function btn(label, action, variant = '', attrs = '') { return `<button type="button" class="btn ${variant}" data-action="${action}" ${attrs}>${label}</button>`; }
function dateLabel() { return `${period.from || 'Awal pembukuan'} — ${period.to || 'Seluruh tanggal'}`; }
function inPeriod(journal) { return (!period.from || journal.tgl >= period.from) && (!period.to || journal.tgl <= period.to); }
function pageHead(title, description, actions = '') { return `<div class="page-head"><div><div class="eyebrow">Pembukuan mandiri · Rupiah</div><h1>${E(title)}</h1><p>${E(description)}</p></div><div class="actions noprint">${actions}</div></div>`; }
function periodControl() { return `<form id="period-form" class="period noprint">${field('Dari tanggal', 'period-from', period.from, 'date')}${field('Sampai tanggal', 'period-to', period.to, 'date')}<button class="btn secondary" type="submit">Terapkan periode</button><span class="hint">${S.closedThrough ? `Dikunci sampai ${E(S.closedThrough)}` : 'Belum ada periode yang dikunci'}</span></form>`; }
function renderAuth(error = '') {
  const setup = authMode === 'setup';
  $('#app').innerHTML = `<div class="auth-page"><section class="auth-story"><div class="brand-mark">KR</div><h1>Pembukuan yang rapi.<br>Keputusan lebih pasti.</h1><p>Kelola transaksi, persediaan, dan laporan keuangan dalam satu tempat yang Anda kendalikan.</p><div class="pill">✓ Data di server Anda &nbsp; · &nbsp; Tanpa layanan AI</div></section><main id="main" class="auth-panel"><div class="auth-card"><div class="eyebrow">Keuangan Reza</div><h2>${setup ? 'Siapkan pembukuan Anda' : 'Selamat datang kembali'}</h2><p>${setup ? 'Buat akun pemilik pertama. Tidak ada kata sandi bawaan.' : 'Masuk untuk melanjutkan pengelolaan keuangan Anda.'}</p><div id="auth-error" class="notice error auth-error" role="alert">${E(error)}</div><form id="auth-form">${setup ? field('Nama lengkap', 'displayName', '', 'text', 'autocomplete="name" maxlength="100" required') : ''}${field('Nama pengguna', 'username', '', 'text', 'autocomplete="username" required maxlength="80" autocapitalize="none"')}${field('Kata sandi', 'password', '', 'password', `autocomplete="${setup ? 'new-password' : 'current-password'}" required ${setup ? 'minlength="12"' : ''}`)}${setup ? '<p class="hint mb">Gunakan minimal 12 karakter yang unik. Simpan kata sandi di pengelola kata sandi Anda.</p>' : ''}<div id="mfa-login" ${authMfa ? '' : 'hidden'}>${field('Kode autentikator / kode pemulihan', 'code', '', 'text', 'autocomplete="one-time-code" maxlength="80"')}</div><button type="submit" class="btn">${setup ? 'Buat akun & mulai' : 'Masuk ke pembukuan'}</button></form><p class="auth-note">${setup ? 'Penyiapan pertama dilakukan melalui server lokal.' : 'Akses aman dengan sesi tersimpan di server.'}</p></div></main></div>`;
}
function render() {
  if (!session || !S) return;
  const titles = Object.fromEntries(nav.map(([key,,label]) => [key,label]));
  $('#app').innerHTML = `<div class="shell"><aside class="sidebar ${mobileOpen ? 'open' : ''}" aria-label="Navigasi utama"><a href="#home" class="brand" data-tab="home"><span class="brand-mark">KR</span><span><span class="brand-name">Keuangan Reza</span><br><span class="brand-sub">KELOLA DENGAN PASTI</span></span></a><div class="nav-label">RUANG KERJA</div><nav>${nav.filter(([key]) => key !== 'import' || owner()).map(([key,icon,label], i) => `${key === 'settings' ? '<div class="nav-label">PREFERENSI</div>' : ''}<button type="button" class="nav-item ${tab === key ? 'active' : ''}" data-tab="${key}" ${tab === key ? 'aria-current="page"' : ''}><span class="nav-icon" aria-hidden="true">${icon}</span>${label}</button>`).join('')}</nav><div class="side-footer"><span class="status-dot"></span>Terhubung ke server Anda<br>Data tersimpan setelah berhasil disimpan.<br><br>Keuangan Reza · v3.1</div></aside><div class="workspace"><header class="topbar"><div class="actions"><button type="button" class="mobile-menu" data-action="mobile-menu" aria-label="Buka navigasi" aria-expanded="${mobileOpen}">☰</button><div><div class="topbar-entity">${E(S.settings.entity || 'Pembukuan Saya')}</div><div class="topbar-desc">${E(titles[tab])} / Ruang kerja keuangan</div></div></div><div class="topbar-right"><div class="avatar" aria-hidden="true">${E((session.user.displayName || session.user.username).slice(0,1).toUpperCase())}</div><div class="user-details"><div class="user-name">${E(session.user.displayName || session.user.username)}</div><div class="role">${roleName[session.user.role] || E(session.user.role)}</div></div>${btn('↻', 'refresh', 'secondary', 'aria-label="Muat ulang data server" title="Muat ulang data server"')}${btn('Keluar','logout','secondary')}</div></header><main id="main" class="main ${tab==='reports'?'reports-page':''}" tabindex="-1">${({ home: renderHome, input: renderInput, journals: renderJournals, ledger: renderLedger, subsidiary: renderSubsidiary, trial: renderTrial, reports: renderReports, import: renderExcelImport, reconciliation: renderReconciliation, closing: renderClosing, settings: renderSettings, guide: renderGuide }[tab] || renderHome)()}</main></div></div>`;
  document.title = `${titles[tab]} · Keuangan Reza`;
}
function excelRows() {
  return (excelBook?.sheets[excelSheet]?.rows || []).slice(1).map(row => row.map(value => value instanceof Date ? value.toISOString().slice(0,10) : value));
}
function resetExcelMapping() {
  excelPreview = null; excelError = '';
  excelMapping = suggestMapping(excelKind, excelBook?.sheets[excelSheet]?.rows[0] || []);
}
function resetExcel() { excelBook=null;excelFileName='';excelSheet=0;excelMapping={};excelPreview=null;excelError=''; }
function renderExcelImport() {
  if (!owner()) return empty('Akses pemilik diperlukan','Masuk sebagai pemilik untuk mengimpor data Excel.');
  const kind = IMPORT_KINDS.find(item => item.id === excelKind), headers = excelBook?.sheets[excelSheet]?.rows[0] || [];
  const preview = excelPreview?.preview;
  return pageHead('Impor Excel','Tambahkan jurnal, kas, kontak, produk, akun, atau mutasi bank dari file .xlsx.', '<a class="btn secondary" href="/templates/impor-excel.xlsx" download="template-impor-keuangan-reza.xlsx">↓ Unduh template Excel</a>') +
    `<section class="card"><h2>1. Pilih file Excel</h2><p>Judul kolom harus berada pada baris pertama. Anda dapat mencocokkan nama kolom sendiri. Impor akun, kontak, dan produk yang belum terdaftar sebelum jurnal terkait.</p><form id="excel-file-form"><label class="label" for="excel-file">File Excel (.xlsx, maksimal 10 MB)</label><div class="actions"><input id="excel-file" name="file" type="file" accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" required><button class="btn secondary" type="submit">Baca Excel</button></div></form><p class="hint mt">File dibaca di browser Anda. Tidak menggunakan AI atau layanan eksternal. Gunakan nilai tetap; rumus tidak dihitung ulang. Cadangkan buku dari Pengaturan sebelum melakukan impor besar.</p></section>` +
    (excelBook ? `<section class="card"><h2>2. Cocokkan kolom</h2><p>File: <strong>${E(excelFileName)}</strong></p><form id="excel-preview-form"><div class="row">${selectField('Lembar Excel','excel-sheet',excelBook.sheets.map((sheet,index)=>`<option value="${index}" ${index===excelSheet?'selected':''}>${E(sheet.name)}</option>`).join(''))}${selectField('Jenis data','excel-kind',IMPORT_KINDS.map(item=>`<option value="${E(item.id)}" ${item.id===excelKind?'selected':''}>${E(item.label)}</option>`).join(''))}</div><p class="hint mb">${E(kind.description)}</p>${['cash','bank'].includes(excelKind)?selectField('Rekening kas / bank untuk impor','excel-account',accountOptions(excelAccount,true)):''}<div class="row three">${kind.fields.map(item => selectField(`${item.label}${item.required?' *':''}`,`excel-map-${item.key}`,`<option value="-1">${item.required?'Pilih kolom wajib':'Tidak digunakan'}</option>`+headers.map((header,index)=>`<option value="${index}" ${excelMapping[item.key]===index?'selected':''}>${index+1}. ${E(header||'(tanpa judul)')}</option>`).join(''))).join('')}</div><div class="actions"><button class="btn" type="submit">Periksa &amp; pratinjau</button>${btn('Batal','excel-reset','secondary')}</div></form></section>` : '') +
    (excelError ? `<section class="card notice error" role="alert"><h2>Impor belum dapat dilanjutkan</h2><p>${E(excelError)}</p><p>Belum ada data yang disimpan. Perbaiki file atau pilihan kolom, lalu periksa kembali.</p></section>` : '') +
    (excelPreview ? `<section class="card"><h2>3. Pratinjau impor</h2><p><strong>${excelPreview.summary.added} ${E(excelPreview.summary.label)} baru</strong>; ${excelPreview.summary.skipped} data identik dilewati.</p>${preview?table(preview.headers,preview.rows.slice(0,20).map(row=>row.map(value=>E(value)))):''}<p class="hint mt">Maksimal 20 baris ditampilkan. Seluruh baris telah diperiksa; data baru disimpan setelah Anda menekan tombol di bawah. Data lama tidak ditimpa.</p>${excelPreview.summary.added?btn('Simpan impor','excel-import'):'<p>Semua data sudah tersedia. Tidak ada data baru untuk disimpan.</p>'}</section>` : '');
}
function renderHome() {
  const R = reports(S, { to: today() }), b = balances(S, { to: today() }), cash = S.coa.filter(([code]) => code.startsWith('1-11'));
  const stats = [['Total aset', R.aset, '▧','Aset yang Anda miliki'],['Kas & bank', cash.reduce((sum,[code])=>sum+(b[code]||0),0), '▰','Saldo seluruh akun kas'],['Liabilitas', R.liab, '⇄','Kewajiban yang tercatat'],['Laba bersih', R.laba, '↗','Sejak awal pembukuan']];
  const recent = sorted(S).slice(-5).reverse();
  return pageHead('Beranda', `Ringkasan pembukuan Anda per ${today()}.`, btn('↓ Ekspor Excel','export','secondary') + (writer() ? btn('＋ Transaksi baru','new-journal') : '')) + `<section class="card hero"><div><div class="eyebrow">CATAT HARI INI, PAHAMI ESOK</div><h2>Keuangan tertata, usaha terjaga.</h2><p>Setiap transaksi membentuk gambaran keuangan Anda. Mulai dari jurnal, lalu pantau laporan yang diperbarui secara otomatis.</p>${btn(S.j.length ? 'Lihat laporan keuangan →' : 'Mulai dengan panduan →', S.j.length ? 'go-reports' : 'go-guide')}</div><div class="hero-art" aria-hidden="true">▥</div></section><div class="stats">${stats.map(([label,value,icon,note])=>`<div class="stat"><div class="stat-top"><span class="stat-label">${label}</span><span class="stat-icon" aria-hidden="true">${icon}</span></div><div class="stat-value">Rp ${F(value)}</div><div class="stat-note">${note}</div></div>`).join('')}</div><div class="grid-wide"><section class="card"><div class="card-header"><h2>Transaksi terbaru</h2>${btn('Lihat semua →','go-journals','link')}</div>${recent.length ? table(['Tanggal','Keterangan','Nilai'],recent.map(j=>[E(j.tgl),`${E(j.ket)}<br><small>${kindName[j.jn]}</small>`,F(total(j.l)[0])]),[2]) : empty('Buku Anda siap diisi','Belum ada transaksi. Tambahkan akun, kontak, dan produk sesuai kebutuhan sebelum mencatat saldo awal.', writer() ? btn('Catat transaksi pertama','new-journal') : '')}</section><section class="card"><div class="card-header"><h2>Kas & bank</h2><span class="badge green">Saldo aktual</span></div>${table(['Akun','Saldo (Rp)'],cash.map(([code,name])=>[E(name),F(b[code]||0)]),[1])}<p class="privacy-note">Seluruh saldo dihitung dari jurnal yang tersimpan, tanpa data contoh.</p></section></div><section class="card"><div class="card-header"><h2>Kesehatan pembukuan</h2><span class="badge ${R.chk.every(([,valid])=>valid) ? 'green' : 'red'}">${R.chk.every(([,valid])=>valid) ? 'Seimbang' : 'Periksa saldo'}</span></div><div class="row three"><div><div class="muted">Transaksi tercatat</div><strong>${S.j.length} jurnal</strong></div><div><div class="muted">Selisih neraca</div><strong>Rp ${F(R.aset-R.liab-R.eq)}</strong></div><div><div class="muted">Periode terkunci</div><strong>${S.closedThrough ? `s.d. ${E(S.closedThrough)}` : 'Belum dikunci'}</strong></div></div></section>`;
}
function renderInput() {
  if (!writer()) return pageHead('Input Transaksi','Akun pembaca dapat melihat pembukuan.') + '<div class="notice">Anda memerlukan peran operator atau pemilik untuk mencatat transaksi.</div>';
  return pageHead('Input Transaksi','Catat jurnal berpasangan atau biarkan transaksi dagang membentuk jurnal dan HPP secara otomatis.') + `<div class="tabs noprint">${[['manual','Jurnal manual'],['trade','Pembelian & penjualan'],['settlement','Pelunasan piutang / hutang']].map(([k,n])=>`<button type="button" data-input-tab="${k}" class="${inputTab === k ? 'active' : ''}">${n}</button>`).join('')}</div>` + (inputTab === 'manual' ? renderManual() : inputTab === 'trade' ? renderTrade() : renderSettlement());
}
function renderManual() {
  const [debit, credit] = total(manual.l);
  return `<section class="card"><div class="card-header"><h2>${manual.id ? 'Ubah jurnal' : 'Jurnal baru'}</h2>${manual.id ? '<span class="badge">Mode perubahan</span>' : ''}</div><form id="manual-form"><div class="row three">${field('Tanggal transaksi', 'tgl', manual.tgl, 'date','required data-manual="tgl"')}${selectField('Jenis jurnal','jn',options([['U','Jurnal umum'],['P','Penyesuaian'],['A','Saldo awal']],manual.jn),'data-manual="jn"')}${field('Nomor referensi (opsional)','reference',manual.reference,'text','maxlength="150" data-manual="reference"')}</div>${field('Keterangan','ket',manual.ket,'text','required maxlength="1000" placeholder="Contoh: pembayaran sewa bulan ini" data-manual="ket"')}<div class="row">${selectField('Kelompok arus kas','cashCategory',options([['','Otomatis berdasarkan akun'],['Operasional','Operasional'],['Investasi','Investasi'],['Pendanaan','Pendanaan']],manual.cashCategory),'data-manual="cashCategory"')}<p class="hint">Pilih kelompok jika jurnal mencampurkan beberapa jenis kegiatan. Nominal memakai Rupiah bulat, tanpa pemisah ribuan.</p></div><div id="journal-lines">${manual.l.map((line,i)=>renderLine(line,i)).join('')}</div>${btn('＋ Tambah baris','add-line','secondary')}<div id="line-totals" class="line-totals">${lineTotals(debit,credit)}</div><div class="actions"><button type="submit" class="btn">${manual.id ? 'Simpan perubahan' : 'Simpan jurnal'}</button>${btn('Bersihkan draf','reset-draft','secondary')}</div><p class="hint mt">Debit dan kredit harus sama. Piutang / hutang memerlukan kontak; persediaan memerlukan produk dan kuantitas positif. Mutasi keluar persediaan mengikuti biaya rata-rata bergerak.</p></form></section>`;
}
function renderLine(line,i) {
  const subsidiaryType = line[0] === '1-2010' ? 'prod' : ['1-1201','2-1101'].includes(line[0]) ? 'bantu' : null;
  return `<div class="line-item"><div class="line-row">${selectField(`Akun · baris ${i+1}`,`line-account-${i}`,accountOptions(line[0]),`data-line="${i}" data-field="0" required`)}${field('Debit (Rp)',`line-debit-${i}`,line[1] || '', 'number',`data-line="${i}" data-field="1" min="0" step="1" inputmode="numeric" placeholder="0"`)}${field('Kredit (Rp)',`line-credit-${i}`,line[2] || '', 'number',`data-line="${i}" data-field="2" min="0" step="1" inputmode="numeric" placeholder="0"`)}${btn('×','remove-line','secondary',`data-index="${i}" aria-label="Hapus baris ${i+1}" ${manual.l.length <= 2 ? 'disabled' : ''}`)}</div>${subsidiaryType ? `<div class="line-extra">${selectField(subsidiaryType === 'prod' ? 'Produk' : 'Kontak',`line-sub-${i}`,options(S[subsidiaryType],line[3],'Pilih kode bantu'),`data-line="${i}" data-field="3" required`)}${subsidiaryType === 'prod' ? field('Kuantitas',`line-qty-${i}`,line[4] || '','number',`data-line="${i}" data-field="4" min="0.000001" step="0.000001" required`) : ''}</div>` : ''}</div>`;
}
function lineTotals(debit,credit) { return `<span>Total debit<strong>Rp ${F(debit)}</strong></span><span>Total kredit<strong>Rp ${F(credit)}</strong></span><span>Selisih<strong class="${debit === credit && debit > 0 ? 'positive' : ''}">Rp ${F(debit-credit)}</strong></span>`; }
function renderTrade() {
  return `<section class="card"><h2>Transaksi dagang otomatis</h2>${!S.prod.length ? '<div class="notice">Tambahkan produk di Pengaturan → Data master terlebih dahulu.</div>' : ''}<form id="trade-form"><div class="row three">${selectField('Jenis transaksi','kind','<option value="purchase">Pembelian barang</option><option value="sale">Penjualan barang</option>')}${field('Tanggal','date',today(),'date','required')}${field('Referensi (opsional)','reference','','text','maxlength="150"')}</div><div class="row three">${selectField('Produk','product',options(S.prod,'','Pilih produk'),'required')}${field('Kuantitas','quantity','','number','min="0.000001" step="0.000001" required')}${field('Harga per unit (Rp)','unitPrice','','number','min="1" step="1" required')}</div><div class="row three">${selectField('Akun pembayaran','paymentAccount',accountOptions('1-1101',true))}${field('Dibayar sekarang (Rp)','paidAmount','','number','min="0" step="1" placeholder="Kosong = lunas"')}${selectField('Kontak (wajib jika belum lunas)','contact',options(S.bantu,'','Pilih kontak'))}</div>${field('Keterangan','description','','text','maxlength="1000" placeholder="Kosong = keterangan otomatis"')}<div class="notice">Penjualan mengurangi persediaan dengan HPP rata-rata bergerak. Isi pembayaran 0 untuk transaksi kredit, atau isi sebagian untuk pembayaran parsial. Stok tidak boleh negatif.</div><button type="submit" class="btn" ${!S.prod.length ? 'disabled' : ''}>Catat transaksi dagang</button></form></section><section class="card"><h2>Persediaan tersedia saat ini</h2>${inventoryTable()}</section>`;
}
function renderSettlement() {
  return `<section class="card narrow"><h2>Pelunasan berdasarkan kontak</h2><form id="settlement-form"><div class="row">${selectField('Jenis pelunasan','settlementKind','<option value="receivable">Penerimaan piutang pelanggan</option><option value="payable">Pembayaran hutang pemasok</option>')}${field('Tanggal','date',today(),'date','required')}</div><div class="row">${selectField('Kontak','contact',options(S.bantu,'','Pilih kontak'),'required')}${selectField('Akun kas / bank','paymentAccount',accountOptions('1-1101',true))}</div><div class="row">${field('Nominal (Rp)','amount','','number','min="1" step="1" required')}${field('Referensi tagihan (opsional)','reference','','text','maxlength="150"')}</div>${field('Keterangan','description','','text','maxlength="1000" placeholder="Contoh: pelunasan faktur INV-001"')}<button type="submit" class="btn">Simpan pelunasan</button><p class="hint mt">Pelunasan dicatat pada buku bantu kontak. Periksa saldo kontak dan referensi faktur sebelum menyimpan.</p></form></section>`;
}
function renderJournals() {
  const name = Object.fromEntries(S.coa), list = sorted(S).filter(inPeriod).filter(j=>!journalSearch || `${j.ket} ${j.reference || ''} ${j.id} ${j.l.map(x=>x[0]).join(' ')}`.toLowerCase().includes(journalSearch.toLowerCase())).reverse();
  return pageHead('Jurnal','Telusuri bukti pencatatan dan kelola transaksi Anda.', btn('Cetak / PDF','print','secondary') + (writer() ? btn('＋ Jurnal baru','new-journal') : '')) + periodControl() + `<form id="journal-search" class="card noprint"><div class="actions"><div class="spacer">${field('Cari keterangan, referensi, atau kode akun','journal-query',journalSearch,'search')}</div><button class="btn secondary" type="submit">Cari</button></div></form>` + (list.length ? list.map(j=>`<article class="card"><div class="journal-title"><div><div class="journal-meta"><strong>${E(j.tgl)}</strong><span class="badge ${j.jn === 'T' ? 'gray' : ''}">${kindName[j.jn]}</span>${S.closedThrough && j.tgl <= S.closedThrough ? '<span class="badge gray">Terkunci</span>' : ''}</div><h3>${E(j.ket)}</h3>${j.reference ? `<p>Referensi: ${E(j.reference)}</p>` : ''}</div><div class="journal-actions noprint">${btn('Bukti','attachments','secondary small',`data-id="${E(j.id)}"`)}${writer() && j.jn !== 'T' && (!S.closedThrough || j.tgl > S.closedThrough) ? btn('Ubah','edit-journal','secondary small',`data-id="${E(j.id)}"`) + btn('Hapus','delete-journal','danger small',`data-id="${E(j.id)}"`) : ''}</div></div>${table(['Akun / Buku bantu','Debit (Rp)','Kredit (Rp)'],j.l.map(([code,d,c,sub,qty])=>[`${E(code)} · ${E(name[code] || code)}${sub ? `<br><small>${E(sub)}${qty ? ` · ${Q(qty)} unit` : ''}</small>` : ''}`,F(d),F(c)]),[1,2])}${attachmentJournal === String(j.id) ? renderAttachments(j) : ''}</article>`).join('') : `<section class="card">${empty('Tidak ada jurnal dalam pilihan ini','Ubah rentang tanggal atau kata pencarian, atau catat transaksi baru.')}</section>`);
}
function renderAttachments(j) {
  const mutable = writer() && (!S.closedThrough || j.tgl > S.closedThrough);
  return `<section class="mt noprint"><h3>Bukti transaksi</h3>${attachmentList.length ? `<ul class="file-list">${attachmentList.map(a=>`<li><a href="/api/attachments/${encodeURIComponent(a.id)}" download>${E(a.name)}</a><span><small>${Q(a.size/1024)} KB</small> ${mutable ? btn('Hapus','delete-attachment','danger small',`data-id="${E(a.id)}"`) : ''}</span></li>`).join('')}</ul>` : '<p class="hint">Belum ada bukti terlampir.</p>'}${mutable ? `<form id="attachment-form"><label class="label" for="attachment-file">Tambah PDF, JPEG, atau PNG (maksimal 5 MB)</label><div class="actions"><input type="file" id="attachment-file" name="file" accept="application/pdf,image/jpeg,image/png" required><button type="submit" class="btn secondary">Unggah bukti</button></div></form>` : ''}</section>`;
}
function renderLedger() {
  let running = 0, opening = 0; const rows = [];
  for (const j of sorted(S)) for (const [code,d,c] of j.l) if (code === ledgerAccount && (!period.to || j.tgl <= period.to)) { running += d-c; if (period.from && j.tgl < period.from) opening += d-c; else rows.push([E(j.tgl),E(j.ket),E(j.reference || '—'),F(d),F(c),F(running)]); }
  return pageHead('Buku Besar','Mutasi per akun, termasuk saldo sebelum awal periode.',btn('Cetak / PDF','print','secondary')) + periodControl() + `<section class="card"><form id="ledger-form" class="noprint"><div class="row">${selectField('Akun','ledger-account',accountOptions(ledgerAccount))}<div class="field"><label>&nbsp;</label><button type="submit" class="btn secondary">Tampilkan akun</button></div></div></form><h2>${E(S.coa.find(x=>x[0]===ledgerAccount)?.join(' · ') || ledgerAccount)}</h2>${table(['Tanggal','Keterangan','Referensi','Debit','Kredit','Saldo (D − K)'],[{bold:true,cells:['—','Saldo awal periode','',F(Math.max(opening,0)),F(Math.max(-opening,0)),F(opening)]},...rows,{bold:true,cells:['','Saldo akhir','','','',F(running)]}],[3,4,5])}<p class="hint mt">Saldo kredit ditampilkan dalam tanda kurung. Angka menggunakan Rupiah.</p></section>`;
}
function inventoryTable() {
  const products = Object.fromEntries(S.prod.map(([code,name])=>[code,name]));
  const rows = inventory(S, { to: tab === 'input' ? undefined : period.to || undefined });
  return rows.length ? table(['Produk','Qty','Nilai (Rp)','Biaya rata-rata (Rp)'],rows.map(p=>[`${E(p.code)} · ${E(products[p.code])}`,Q(p.qty),F(p.value),Q(p.average)]),[1,2,3]) : empty('Belum ada produk','Tambahkan produk pada Pengaturan → Data master.');
}
function renderSubsidiary() {
  const names = Object.fromEntries(S.bantu), b = balances(S, { to: period.to || undefined });
  return pageHead('Buku Bantu','Rincian saldo per kontak dan persediaan per produk sampai akhir periode.',btn('↓ Excel','export','secondary') + btn('Cetak / PDF','print','secondary')) + periodControl() + `<section class="card"><h2>Persediaan barang</h2>${inventoryTable()}</section>` + [['1-1201','Piutang pelanggan',1],['2-1101','Hutang pemasok',-1]].map(([code,title,sign])=>{ const rows = subsidiary(S,code,{to:period.to || undefined}); const sum = rows.reduce((n,r)=>n+r.balance,0); return `<section class="card"><div class="card-header"><h2>${title}</h2><span class="badge ${sum === (b[code]||0)*sign ? 'green' : 'red'}">${sum === (b[code]||0)*sign ? 'Cocok dengan buku besar' : 'Periksa selisih'}</span></div>${rows.length ? table(['Kode','Nama kontak','Saldo (Rp)'],[...rows.map(r=>[E(r.code),E(names[r.code]||r.code),F(r.balance)]),{bold:true,cells:['','TOTAL',F(sum)]}],[2]) : empty('Belum ada saldo kontak','Transaksi kredit dan pelunasan akan tampil di sini.')}</section>`; }).join('');
}
function renderTrial() {
  const b = balances(S,{to:period.to || undefined}); let debit=0,credit=0;
  const rows = S.coa.filter(([code])=>b[code]).map(([code,name])=>{const d=Math.max(b[code],0), c=Math.max(-b[code],0);debit+=d;credit+=c;return [E(code),E(name),F(d),F(c)];});
  return pageHead('Neraca Saldo','Saldo seluruh akun sampai akhir periode, termasuk jurnal penutup yang tersimpan.',btn('↓ Excel','export','secondary') + btn('Cetak / PDF','print','secondary')) + periodControl() + `<section class="card"><div class="card-header"><h2>Neraca saldo per ${E(period.to || 'seluruh tanggal')}</h2><span class="badge ${debit === credit ? 'green' : 'red'}">${debit === credit ? 'Debit = Kredit' : 'Tidak seimbang'}</span></div>${table(['Kode akun','Nama akun','Debit (Rp)','Kredit (Rp)'],[...rows,{bold:true,cells:['','TOTAL',F(debit),F(credit)]}],[2,3])}${!rows.length ? '<p class="hint mt">Belum ada saldo. Buku dimulai tanpa transaksi contoh.</p>' : ''}</section>`;
}
function renderReports() {
  const R = reports(S,{from:period.from || undefined,to:period.to || undefined});
  const previous = comparison ? reports(S,{from:comparisonFrom || undefined,to:comparisonTo || undefined}) : null;
  const sections = [['LR','Laporan Laba Rugi'],['NR','Laporan Posisi Keuangan'],['PM','Laporan Perubahan Modal'],['AK','Laporan Arus Kas']];
  return pageHead('Laporan Keuangan','Laporan terhubung langsung dengan jurnal; nilai dalam Rupiah.',btn('↓ Ekspor Excel','export','secondary') + btn('Cetak A4 / Simpan PDF','print')) + periodControl() + `<section class="card noprint"><label class="checkbox"><input type="checkbox" id="compare-toggle" ${comparison ? 'checked' : ''}> Bandingkan dengan periode lain</label>${comparison ? `<form id="comparison-form" class="row three">${field('Awal pembanding','comparison-from',comparisonFrom,'date')}${field('Akhir pembanding','comparison-to',comparisonTo,'date','required')}<div class="field"><label>&nbsp;</label><button class="btn secondary" type="submit">Terapkan pembanding</button></div></form>` : ''}</section>` + sections.map(([key,title],sectionIndex)=>`<section class="card report-section ${sectionIndex===0?'first-report':''}"><div class="report-title"><div class="eyebrow">${E(S.settings.entity || 'Keuangan Reza')}</div><h2>${title}</h2><p>${key === 'NR' ? `Per ${E(period.to || 'seluruh tanggal')}` : E(dateLabel())}</p>${comparison ? `<p class="comparison">Pembanding: ${E(comparisonFrom || 'Awal pembukuan')} — ${E(comparisonTo || 'Seluruh tanggal')}</p>` : ''}</div>${table(comparison ? ['Keterangan','Periode ini','Pembanding','Selisih'] : ['Keterangan','Jumlah (Rp)'],R[key].map(([label,value,bold],i)=>{const other = previous?.[key].find(row=>row[0]===label)?.[1] ?? 0;return {bold:Boolean(bold),cells:[E(label),F(value),...(comparison ? [F(other),F(value-other)] : [])]};}),comparison ? [1,2,3] : [1])}${key === 'NR' ? `<p class="hint mt">Selisih aset − liabilitas − ekuitas: Rp ${F(R.aset-R.liab-R.eq)}.</p>` : ''}</section>`).join('') + `<section class="card report-section"><div class="report-title"><h2>Catatan atas Laporan Keuangan</h2><p>${E(S.settings.entity || 'Keuangan Reza')} · ${E(dateLabel())}</p></div><p>Pencatatan menggunakan pembukuan berpasangan dalam Rupiah. Persediaan dihitung menggunakan metode rata-rata bergerak. Laba rugi mengecualikan jurnal penutup.</p><p class="pre-line">${E(S.settings.notes || 'Belum ada catatan khusus. Pemilik dapat mengisi kebijakan dan penjelasan pada Pengaturan → Entitas.')}</p></section>`;
}

function renderReconciliation() {
  const rows = S.reconciliation.filter(r => r.account === reconAccount && (!period.from || r.date >= period.from) && (!period.to || r.date <= period.to));
  const used = new Set(S.reconciliation.filter(r => r.account === reconAccount && r.journalId !== null).map(r => String(r.journalId)));
  const matching = row => sorted(S).filter(j => j.l.filter(l => l[0] === reconAccount).reduce((n,l) => n+l[1]-l[2],0) === row.amount && (String(j.id) === String(row.journalId) || !used.has(String(j.id))));
  return pageHead('Rekonsiliasi Bank','Cocokkan mutasi rekening koran dengan jurnal. Pencocokan tidak membuat jurnal baru.') + periodControl() + `<section class="card"><form id="recon-account-form" class="row"><div>${selectField('Rekening kas / bank','recon-account',accountOptions(reconAccount,true))}</div><div class="field"><label>&nbsp;</label><button class="btn secondary">Tampilkan rekening</button></div></form><p class="hint">Masuk bernilai positif, keluar negatif. Satu jurnal per rekening hanya boleh dicocokkan sekali. Mutasi dari rekening koran tetap perlu dicatat sebagai jurnal jika belum ada.</p></section>${owner() ? `<section class="card"><h2>Tambah mutasi rekening koran</h2><form id="recon-manual-form"><div class="row three">${field('Tanggal','recon-date',today(),'date','required')}${field('Keterangan','recon-description','','text','required maxlength="1000"')}${field('Nominal bertanda (Rp)','recon-amount','','number','required step="1" placeholder="Contoh: -50000"')}</div><button class="btn secondary">Tambah mutasi</button></form><hr class="divider"><h3>Impor CSV</h3><p class="hint">Kolom wajib: <code>date,description,amount</code>. Tanggal YYYY-MM-DD; nominal Rupiah bulat tanpa pemisah ribuan. Pemisah koma atau titik koma didukung. Contoh: <code>2026-10-01,Transfer masuk,100000</code>.</p><form id="recon-csv-form"><label class="label" for="recon-csv">File CSV (maksimal 2 MB)</label><div class="actions"><input id="recon-csv" name="file" type="file" accept=".csv,text/csv" required><button class="btn secondary">Pratinjau CSV</button></div></form>${csvPreview.length ? `<div class="mt"><h3>${csvPreview.length} mutasi siap ditambahkan ke ${E(reconAccount)}</h3>${table(['Tanggal','Keterangan','Nominal'],csvPreview.slice(0,20).map(r=>[E(r.date),E(r.description),F(r.amount)]),[2])}<p class="hint">Pratinjau menampilkan maksimal 20 baris. Mutasi yang sama persis dengan data tersimpan akan ditolak.</p><div class="actions">${btn('Impor mutasi','import-csv')}${btn('Batal','cancel-csv','secondary')}</div></div>` : ''}</section>` : ''}<section class="card"><div class="card-header"><h2>Mutasi rekening koran</h2><span class="badge">${rows.filter(r=>r.journalId!==null).length} / ${rows.length} cocok</span></div>${rows.length ? table(['Tanggal / Keterangan','Nominal (Rp)','Jurnal yang cocok','Tindakan'],rows.map(r=>{ const candidates = matching(r); return [E(r.date)+'<br>'+E(r.description), F(r.amount), owner() ? `<select aria-label="Jurnal untuk ${E(r.description)}" data-recon-match="${E(r.id)}"><option value="">Belum dicocokkan</option>${candidates.map(j=>`<option value="${E(j.id)}" ${String(j.id)===String(r.journalId) ? 'selected' : ''}>${E(j.tgl)} · ${E(j.ket)}</option>`).join('')}</select>${!candidates.length ? '<small>Tidak ada jurnal dengan nominal yang sama.</small>' : ''}` : E(r.journalId === null ? 'Belum dicocokkan' : S.j.find(j=>String(j.id)===String(r.journalId))?.ket),owner() ? btn('Hapus','delete-recon','danger small',`data-id="${E(r.id)}"`) : '—'];}),[1]) : empty('Belum ada mutasi rekening koran','Tambahkan mutasi atau impor CSV untuk rekening dan periode ini.')}</section>`;
}
function renderClosing() {
  const closeJournals = sorted(S).filter(j=>j.jn==='T');
  return pageHead('Penutupan Periode','Pindahkan saldo pendapatan, beban, dan prive ke laba ditahan, kemudian kunci periode.') + `<section class="card"><h2>Status periode</h2><p>${S.closedThrough ? `Pembukuan dikunci sampai <strong>${E(S.closedThrough)}</strong>.` : 'Belum ada periode yang dikunci.'}</p><p class="hint">Jurnal dan bukti pada periode terkunci tidak dapat diubah. Laporan laba rugi tetap menampilkan aktivitas periode tersebut setelah penutupan.</p>${owner() && S.closedThrough ? btn('Buka kembali periode','unlock-period','danger') : ''}</section>${owner() ? `<section class="card narrow"><h2>Tutup dan kunci periode</h2><form id="closing-form"><div class="row">${field('Dari tanggal (opsional)','closing-from',period.from,'date')}${field('Sampai tanggal','closing-to',period.to || today(),'date','required')}</div><p class="hint">Seluruh saldo akun sementara sampai tanggal akhir akan ditutup. Jika masih ada saldo sebelum tanggal awal, perluas periode terlebih dahulu. Periksa laporan dan simpan cadangan sebelum melanjutkan.</p><button class="btn">Pratinjau penutupan</button></form><div id="closing-preview"></div></section>` : '<div class="notice">Hanya pemilik yang dapat menutup atau membuka periode.</div>'}<section class="card"><h2>Jurnal penutup tersimpan</h2>${closeJournals.length ? table(['Tanggal','Keterangan','Nilai (Rp)','Tindakan'],closeJournals.map(j=>[E(j.tgl),E(j.ket),F(total(j.l)[0]),owner() && (!S.closedThrough || j.tgl>S.closedThrough) ? btn('Hapus penutup','delete-journal','danger small',`data-id="${E(j.id)}"`) : 'Terkunci']),[2]) : empty('Belum ada jurnal penutup','Penutupan yang tidak memiliki saldo sementara tetap akan mengunci periodenya.')}</section>`;
}
function renderSettings() {
  const sections = [['profile','Profil & keamanan'],...(owner() ? [['entity','Entitas'],['masters','Data master'],['users','Pengguna'],['backup','Cadangan & pemulihan'],['audit','Jejak audit']] : [])];
  if (!sections.some(([key])=>key===settingTab)) settingTab='profile';
  return pageHead('Pengaturan','Kelola profil, akses, data master, dan cadangan pembukuan.') + `<div class="tabs">${sections.map(([key,label])=>`<button type="button" class="${settingTab===key?'active':''}" data-setting-tab="${key}">${label}</button>`).join('')}</div>` + ({profile:renderProfile,entity:renderEntity,masters:renderMasters,users:renderUsers,backup:renderBackup,audit:renderAudit}[settingTab])();
}
function renderEntity() { return `<section class="card narrow"><h2>Identitas pembukuan</h2><form id="entity-form">${field('Nama entitas / usaha','entity',S.settings.entity,'text','required maxlength="200"')}<div class="field"><label for="notes">Catatan atas laporan keuangan</label><textarea id="notes" name="notes" rows="8" maxlength="20000">${E(S.settings.notes)}</textarea><p class="hint">Tuliskan kebijakan, informasi pendukung, dan penjelasan angka. Catatan ikut tercetak bersama laporan.</p></div><button class="btn">Simpan identitas</button></form></section>`; }
function renderMasters() {
  const labels = {coa:'Akun',bantu:'Kontak',prod:'Produk'}, editing = masterEdit !== null, current = editing ? S[masterKind].find(r=>r[0]===masterEdit) : null;
  return `<div class="tabs">${Object.entries(labels).map(([key,label])=>`<button type="button" data-master-kind="${key}" class="${masterKind===key?'active':''}">${label}</button>`).join('')}</div><section class="card"><h2>${editing?'Ubah':'Tambah'} ${labels[masterKind].toLowerCase()}</h2><form id="master-form"><div class="row ${masterKind==='prod'?'three':''}">${field('Kode','master-code',current?.[0] || '','text',`required maxlength="80" ${editing?'readonly':''} ${masterKind==='coa'?'pattern="[1-5]-[0-9]{4}" placeholder="Contoh: 1-1104"':''}`)}${field('Nama','master-name',current?.[1] || '','text','required maxlength="200"')}${masterKind==='prod'?field('Harga jual default (Rp)','master-price',current?.[2] || 0,'number','required min="0" step="1"'):''}</div><div class="actions"><button class="btn">${editing?'Simpan perubahan':'Tambah data'}</button>${editing?btn('Batal','cancel-master','secondary'):''}</div><p class="hint mt">${masterKind==='coa'?'Kode memakai kelas 1 aset, 2 liabilitas, 3 ekuitas, 4 pendapatan, 5 beban. Akun kas/bank harus diawali 1-11. Akun wajib dan data yang digunakan jurnal tidak dapat dihapus.':'Kode tetap setelah disimpan agar histori tidak berubah. Data yang sudah digunakan jurnal tidak dapat dihapus.'}</p></form></section><section class="card"><h2>Daftar ${labels[masterKind].toLowerCase()}</h2>${S[masterKind].length?table(['Kode','Nama',...(masterKind==='prod'?['Harga jual (Rp)']:[]),'Tindakan'],S[masterKind].map(row=>[E(row[0]),E(row[1]),...(masterKind==='prod'?[F(row[2])]:[]),`<div class="actions">${btn('Ubah','edit-master','secondary small',`data-code="${E(row[0])}"`)}${btn('Hapus','delete-master','danger small',`data-code="${E(row[0])}"`)}</div>`]),masterKind==='prod'?[2]:[]):empty('Data belum tersedia','Tambahkan data melalui formulir di atas.')}</section>`;
}
function renderProfile() {
  const u=session.user;
  return `<section class="card narrow"><h2>Profil pengguna</h2><form id="profile-form"><div class="row">${field('Nama pengguna','profile-username',u.username,'text','readonly')}${field('Nama tampilan','displayName',u.displayName,'text','required maxlength="100"')}</div><div class="row">${field('Email (opsional)','email',u.email || '','email','maxlength="254"')}${field('Telepon (opsional)','phone',u.phone || '','tel','maxlength="40"')}</div>${u.avatar?`<img class="profile-photo" src="${E(u.avatar)}" alt="Foto profil saat ini">`:''}<div class="field"><label for="profile-avatar">Foto profil (PNG/JPEG, maksimal 256 KB)</label><input type="file" name="avatar" id="profile-avatar" accept="image/png,image/jpeg"></div><label class="checkbox"><input name="removeAvatar" type="checkbox"> Hapus foto profil saat menyimpan</label><button class="btn">Simpan profil</button><p class="hint mt">Email dan telepon merupakan informasi profil; aplikasi tidak mengirim pesan atau menyediakan pemulihan lewat email.</p></form></section><section class="card narrow"><h2>Ubah kata sandi</h2><form id="password-form">${field('Kata sandi saat ini','currentPassword','','password','required autocomplete="current-password"')}${field('Kata sandi baru','newPassword','','password','required minlength="12" autocomplete="new-password"')}${field('Ulangi kata sandi baru','confirmPassword','','password','required minlength="12" autocomplete="new-password"')}<button class="btn">Perbarui kata sandi</button><p class="hint mt">Minimal 12 karakter. Sesi pada perangkat lain akan dihentikan.</p></form></section><section class="card narrow"><div class="card-header"><h2>Autentikasi dua langkah</h2><span class="badge ${u.mfaEnabled?'green':'gray'}">${u.mfaEnabled?'Aktif':'Belum aktif'}</span></div><p>Gunakan aplikasi autentikator TOTP di perangkat Anda. Kode pemulihan hanya dapat dipakai satu kali.</p>${u.mfaEnabled?`<form id="mfa-disable-form">${field('Kata sandi saat ini','mfa-password','','password','required autocomplete="current-password"')}${field('Kode autentikator / pemulihan','mfa-code','','text','required autocomplete="one-time-code"')}<button class="btn danger">Nonaktifkan autentikator</button></form>`:pendingMfa?`<p>Tambahkan akun secara manual pada autentikator dengan kunci berikut. Kunci ini hanya untuk Anda.</p><pre class="mfa-secret">${E(pendingMfa.secret)}</pre><p class="hint">Jenis: TOTP, SHA-1, 6 digit, interval 30 detik. Verifikasi dalam 10 menit.</p><form id="mfa-enable-form">${field('Kode enam digit','mfa-code','','text','required pattern="[0-9]{6}" inputmode="numeric" autocomplete="one-time-code"')}<button class="btn">Verifikasi & aktifkan</button></form>`:btn('Siapkan autentikator','mfa-setup')}${recoveryCodes?`<div class="notice mt"><h3>Simpan kode pemulihan sekarang</h3><p>Kode hanya ditampilkan sekali. Simpan di tempat aman terpisah dari perangkat autentikator.</p><div class="recovery-codes">${recoveryCodes.map(E).join('<br>')}</div><div class="actions mt">${btn('Unduh kode pemulihan','download-recovery','secondary')}${btn('Sudah saya simpan','dismiss-recovery','secondary')}</div></div>`:''}</section><section class="card narrow"><h2>Sesi perangkat</h2><p>Hentikan semua sesi akun Anda pada perangkat lain. Sesi saat ini tetap aktif.</p>${btn('Keluar dari perangkat lain','revoke-sessions','secondary')}</section>`;
}
function renderUsers() {
  return `<section class="card"><h2>Tambah pengguna</h2><form id="user-form"><div class="row">${field('Nama pengguna','user-username','','text','required maxlength="80" autocomplete="off"')}${field('Nama tampilan','user-displayName','','text','required maxlength="100"')}</div><div class="row">${field('Kata sandi awal','user-password','','password','required minlength="12" autocomplete="new-password"')}${selectField('Peran','user-role',options(Object.entries(roleName),'operator'))}</div><button class="btn">Buat pengguna</button><p class="hint mt">Pemilik mengelola seluruh buku dan akses; operator mencatat transaksi dan bukti; pembaca hanya melihat dan mengekspor laporan.</p></form></section><section class="card"><div class="card-header"><h2>Pengguna terdaftar</h2>${btn('Muat ulang pengguna','load-users','secondary small')}</div>${users?table(['Pengguna','Peran','Status','Kelola'],users.map(u=>[`${E(u.displayName)}<br><small>${E(u.username)}</small>`,E(roleName[u.role]),u.disabled?'Nonaktif':'Aktif',`<form class="user-update-form" data-id="${E(u.id)}"><select name="role" aria-label="Peran ${E(u.username)}">${options(Object.entries(roleName),u.role)}</select><label class="checkbox mt"><input type="checkbox" name="disabled" ${u.disabled?'checked':''} ${u.id===session.user.id?'disabled':''}> Nonaktif</label><input name="password" type="password" minlength="12" autocomplete="new-password" placeholder="Kata sandi baru (opsional)" aria-label="Reset kata sandi ${E(u.username)}"><button class="btn secondary small mt">Simpan pengguna</button></form>`])):'<p class="hint">Memuat pengguna…</p>'}</section>`;
}
function legacyAvailable() { try { return Boolean(localStorage.getItem('keuangan-reza-v2')); } catch { return false; } }
function renderBackup() {
  return `<section class="card narrow"><h2>Cadangan terenkripsi</h2><p>Cadangan memuat seluruh buku dan bukti transaksi. Akun pengguna, kata sandi, autentikator, dan jejak audit tidak disertakan; gunakan cadangan server untuk pemulihan penuh.</p><form id="backup-form">${field('Kata sandi cadangan','backup-password','','password','required minlength="12" autocomplete="new-password"')}${field('Ulangi kata sandi cadangan','backup-confirm','','password','required minlength="12" autocomplete="new-password"')}<button class="btn">Unduh cadangan terenkripsi</button></form><p class="hint mt">Enkripsi dilakukan pada browser dengan AES-256-GCM. Simpan kata sandi terpisah; kata sandi yang hilang tidak dapat dipulihkan.</p></section><section class="card narrow"><h2>Pulihkan buku dari cadangan</h2><form id="restore-preview-form"><div class="field"><label for="restore-file">File cadangan JSON</label><input type="file" id="restore-file" name="file" accept=".json,.krb,application/json" required></div>${field('Kata sandi jika terenkripsi','restore-password','','password','autocomplete="off"')}<button class="btn secondary">Periksa & pratinjau</button></form><p class="hint mt">JSON dari versi awal repository didukung. Format .krb dari aplikasi lain yang belum diketahui ditolak tanpa mengubah buku.</p>${legacyAvailable()?`<hr class="divider"><h3>Data versi lama di browser ini</h3><p>Data <code>keuangan-reza-v2</code> ditemukan. Periksa dahulu sebelum mengganti buku server. Data sumber tidak akan dihapus.</p>${btn('Pratinjau data browser lama','preview-legacy','secondary')}`:''}</section>${backupPreview?renderBackupPreview():''}`;
}
function renderBackupPreview() {
  const p=backupPreview, dates=p.state.j.map(j=>j.tgl).sort();
  return `<section class="card danger-zone narrow"><h2>Pratinjau pemulihan</h2>${table(['Isi','Cadangan','Buku saat ini'],[['Entitas',E(p.state.settings.entity),E(S.settings.entity)],['Jurnal',p.state.j.length,S.j.length],['Akun',p.state.coa.length,S.coa.length],['Kontak',p.state.bantu.length,S.bantu.length],['Produk',p.state.prod.length,S.prod.length],['Bukti transaksi',p.attachments.length,'Akan diganti'],['Rentang tanggal',dates.length?`${E(dates[0])} — ${E(dates.at(-1))}`:'Tidak ada jurnal','']])}<div class="notice mt">Pemulihan mengganti seluruh buku dan bukti transaksi saat ini. Server membuat snapshot sebelum penggantian. Akun pengguna tetap dipertahankan.</div><form id="restore-confirm-form"><label class="checkbox"><input name="confirm" type="checkbox" required> Saya telah memeriksa cadangan dan ingin mengganti buku aktif.</label><div class="actions"><button class="btn danger">Pulihkan buku ini</button>${btn('Batal','cancel-restore','secondary')}</div></form></section>`;
}
function renderAudit() {
  return `<section class="card"><div class="card-header"><h2>Jejak aktivitas</h2>${btn('Muat ulang audit','load-audit','secondary small')}</div><p class="hint">Maksimal 500 aktivitas terbaru. Waktu disimpan dalam UTC; rincian perubahan tersedia untuk pemeriksaan pemilik.</p>${audit?audit.length?table(['Waktu','Pengguna','Aktivitas','Rincian'],audit.map(e=>[E(e.at),E(e.user || e.username || e.user_id || 'Sistem'),E(e.action),`<details><summary>Lihat rincian</summary><pre>${E(JSON.stringify(e.detail,null,2))}</pre></details>`])):empty('Belum ada aktivitas','Aktivitas berikutnya akan tercatat di sini.'):'<p class="hint">Memuat jejak audit…</p>'}</section>`;
}
function renderGuide() {
  const steps=[['Siapkan entitas dan data master','Buka Pengaturan untuk mengisi nama pembukuan, akun kas/bank, kontak pelanggan/pemasok, serta produk. Buku baru tidak memuat saldo atau transaksi contoh.'],['Impor data Excel','Pemilik dapat membuka Impor Excel, memilih file .xlsx, mencocokkan kolom, memeriksa pratinjau, lalu menyimpan. Impor master sebelum jurnal terkait. Template kosong tersedia pada menu impor.'],['Catat saldo awal','Gunakan Input Transaksi → Jurnal manual → Saldo awal. Setiap jurnal harus seimbang. Piutang/hutang wajib memakai kontak, persediaan wajib memakai produk dan kuantitas.'],['Catat kegiatan harian','Gunakan transaksi dagang untuk pembelian/penjualan agar HPP dan stok dihitung otomatis. Isi Dibayar sekarang untuk pembayaran parsial; nilai 0 berarti kredit. Gunakan pelunasan untuk piutang/hutang dan jurnal manual untuk beban atau transfer antarrekening.'],['Periksa dan cocokkan','Periksa Jurnal, Buku Besar, Buku Bantu dan Neraca Saldo. Unggah bukti dari tombol Bukti pada jurnal. Rekonsiliasi Bank mencocokkan rekening koran dengan jurnal bernominal sama; tidak mencatat transaksi baru.'],['Baca dan bagikan laporan','Atur tanggal laporan, aktifkan perbandingan bila diperlukan. Ekspor Excel menghasilkan workbook; Cetak membuka dialog browser untuk kertas A4 atau simpan PDF.'],['Cadangkan dan tutup periode','Pemilik mengunduh cadangan terenkripsi sebelum penutupan. Periksa laporan lalu tutup periode. Pembukaan kembali memerlukan tindakan pemilik; jurnal penutup lama harus diperiksa sebelum perubahan atau penutupan ulang.']];
  return pageHead('Panduan','Petunjuk penggunaan mandiri untuk pembukuan sehari-hari.') + `<section class="card">${steps.map(([title,body],i)=>`<div class="guide-step"><span>${i+1}</span><div><h3>${title}</h3><p>${body}</p></div></div>`).join('')}</section><section class="card"><h2>Aturan pencatatan</h2><ul class="bullet-list"><li>Nominal menggunakan Rupiah bulat tanpa pemisah ribuan pada formulir. Kuantitas mendukung maksimal enam angka desimal.</li><li>Debit = kredit pada setiap jurnal. Penjualan menggunakan HPP rata-rata bergerak; stok tidak boleh negatif. Perubahan transaksi lama dapat ditolak jika membuat HPP transaksi berikutnya tidak konsisten.</li><li>Transfer antar kas/bank dicatat sebagai debit rekening tujuan dan kredit rekening asal, tanpa akun pendapatan atau beban.</li><li>Pelunasan tidak boleh melebihi saldo piutang/hutang kontak pada tanggal transaksi. Referensi tagihan membantu pelacakan, tetapi aplikasi belum mengalokasikan pelunasan otomatis per faktur.</li><li>Laporan posisi keuangan dan neraca saldo menghitung seluruh saldo sampai tanggal akhir. Rentang awal–akhir membatasi aktivitas laba rugi dan arus kas.</li><li>Jurnal yang telah disimpan dapat diubah atau dihapus selama periode terbuka. Hapus jurnal juga menghapus bukti terkait; cadangkan data penting dahulu.</li><li>Jika muncul konflik perubahan, tekan tombol muat ulang di kanan atas. Tinjau data terbaru sebelum menyimpan ulang. Draf jurnal manual tetap tersedia pada tab ini.</li></ul></section><section class="card"><h2>Akses, data, dan pengoperasian mandiri</h2><ul class="bullet-list"><li>Aplikasi memerlukan server Node.js dan penyimpanan SQLite milik Anda. Tidak memerlukan ChatGPT, Claude, layanan AI, atau API key AI.</li><li>Pemilik mengelola buku, pengguna, penutupan dan cadangan. Operator mengelola transaksi. Pembaca dapat membaca dan mengekspor laporan.</li><li>Data keuangan tidak disimpan di localStorage. Draf yang belum disimpan hanya berada dalam memori tab dan hilang ketika halaman ditutup. Bukti tersimpan di server.</li><li>Simpan cadangan terenkripsi secara berkala di media terpisah. Untuk pemulihan seluruh akun dan audit, ikuti petunjuk cadangan database di README dan docs/operations.md.</li><li>Gunakan HTTPS saat mengakses dari perangkat lain. Server harus tetap berjalan; pintasan aplikasi di layar utama tidak menyediakan mode pembukuan offline.</li><li>Di Android gunakan menu browser → Tambahkan ke layar utama. Di iPhone buka Safari → Bagikan → Tambahkan ke Layar Utama. Ketersediaan menu mengikuti browser.</li><li>Jika lupa kata sandi, pemilik lain dapat meresetnya. Jika seluruh akses pemilik hilang, gunakan perintah pemulihan administrator yang dijelaskan pada dokumentasi server.</li></ul></section>`;
}

let closingPreview = null;
function formValues(form) { return Object.fromEntries(new FormData(form)); }
function download(blob,name) { const url=URL.createObjectURL(blob), link=document.createElement('a'); link.href=url;link.download=name;document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),30000); }
function downloadJSON(value,name) { download(new Blob([JSON.stringify(value,null,2)],{type:'application/json'}),name); }
function resetPrivateState() { resetExcel();expiredDraft=null;S=null;session=null;revision=0;manual=newManual();manualDirty=false;users=null;audit=null;backupPreview=null;pendingMfa=null;recoveryCodes=null;attachmentList=[];attachmentJournal=null;csvPreview=[];closingPreview=null; }
function safePeriod(from,to) { if (from && to && from>to) throw new Error('Tanggal awal tidak boleh melewati tanggal akhir.'); return {from,to}; }
async function loadSettings() {
  if (settingTab==='users' && owner()) users=(await api('/users')).users;
  if (settingTab==='audit' && owner()) audit=(await api('/audit')).events;
  if (tab==='settings') render();
}
function navigate(next) { tab=next;mobileOpen=false;render(); if (location.hash!==`#${next}`) history.replaceState(null,'',`#${next}`); $('#main')?.focus({preventScroll:true}); }
async function addJournal(journal) { const next=copy(S); next.j.push(journal); await persist(next,'Transaksi berhasil disimpan.'); }
async function attachmentRefresh() { attachmentList=(await api(`/attachments?journalId=${encodeURIComponent(attachmentJournal)}`)).attachments; }
async function prepareBackup(text,password) {
  const parsed=await parseBackup(text,password);parsed.state=validateState(parsed.state);backupPreview=parsed;settingTab='backup';tab='settings';render();
}
function csvRows(text) {
  const first=text.replace(/^\uFEFF/,'').split(/\r?\n/,1)[0], delimiter=first.includes(';')?';':',';
  const rows=[];let row=[],field='',quoted=false;
  text=text.replace(/^\uFEFF/,'');
  for(let i=0;i<text.length;i++) { const c=text[i]; if(quoted) { if(c==='"'&&text[i+1]==='"'){field+='"';i++;}else if(c==='"')quoted=false;else field+=c; } else if(c==='"'&&field==='')quoted=true;else if(c===delimiter){row.push(field);field='';}else if(c==='\n'||c==='\r'){if(c==='\r'&&text[i+1]==='\n')i++;row.push(field);if(row.some(x=>x.trim()))rows.push(row);row=[];field='';}else field+=c; }
  if(quoted)throw new Error('CSV memiliki tanda kutip yang belum ditutup.');row.push(field);if(row.some(x=>x.trim()))rows.push(row);
  if(rows.length<2)throw new Error('CSV harus memuat header dan minimal satu mutasi.');
  const header=rows.shift().map(x=>x.trim().toLowerCase()); const di=header.indexOf('date'),ti=header.indexOf('description'),ai=header.indexOf('amount');
  if([di,ti,ai].includes(-1))throw new Error('Header CSV harus memuat date,description,amount.');
  if(rows.length>10000)throw new Error('Maksimal 10.000 mutasi per impor.');
  return rows.map((r,i)=>{const amount=(r[ai]??'').trim();if(!/^-?\d+$/.test(amount))throw new Error(`Nominal CSV baris ${i+2} harus Rupiah bulat tanpa pemisah ribuan.`);return {id:id(),date:(r[di]??'').trim(),description:(r[ti]??'').trim(),amount:Number(amount),account:reconAccount,journalId:null};});
}
function assertNewReconciliation(rows) {
  const key=r=>JSON.stringify([r.account,r.date,r.description,r.amount]),keys=new Set(S.reconciliation.map(key));
  for(const r of rows){if(!r.amount)throw new Error('Mutasi rekening koran harus bernilai selain nol.');const k=key(r);if(keys.has(k))throw new Error('Mutasi yang sama persis sudah tersedia atau berulang dalam impor. Periksa rekening koran.');keys.add(k);}
  validateState({...S,reconciliation:[...S.reconciliation,...rows]});
}

async function handleSubmit(form) {
  const v=formValues(form);
  if(form.id==='auth-form') {
    try { session=await api(authMode==='setup'?'/setup':'/login',{method:'POST',body:v});await refresh();if(expiredDraft?.userId===session.user.id){manual=expiredDraft.manual;manualDirty=true;}expiredDraft=null;authMfa=false;tab='home';render(); }
    catch(error){session=null;const errorBox=$('#auth-error');if(errorBox)errorBox.textContent=error.message;if(error.code==='MFA_REQUIRED'){authMfa=true;$('#mfa-login').hidden=false;$('#code').required=true;$('#code').focus();}throw error;} return;
  }
  if(!session||!S)return;
  switch(form.id) {
    case 'excel-file-form': {
      if(!owner())throw new Error('Hanya pemilik yang dapat mengimpor Excel.');
      const file=form.elements.file.files[0], activeSession=session;resetExcel();
      notice('Membaca Excel…');
      try { const workbook=await readExcelFile(file);if(session!==activeSession)return;excelBook=workbook;excelFileName=file.name;
        const useful=workbook.sheets.findIndex(sheet=>sheet.name.toLowerCase()!=='panduan'&&sheet.rows.length>1);excelSheet=useful>=0?useful:Math.max(0,workbook.sheets.findIndex(sheet=>sheet.name.toLowerCase()!=='panduan'));
        resetExcelMapping();render();notice('Excel terbaca. Pilih jenis data dan cocokkan kolom.');
      } catch(error) { excelError=error.message;render();throw error; }break;
    }
    case 'excel-preview-form': {
      excelPreview=null;excelError='';
      try {
        if(!owner()||!excelBook)throw new Error('Pilih file Excel menggunakan akun pemilik terlebih dahulu.');
        const request={kind:excelKind,rows:excelRows(),mapping:{...excelMapping},account:excelAccount};
        const result=prepareImport(S,request);excelPreview={...result,revision,request};render();notice('Pratinjau siap. Belum ada data yang disimpan.');
      } catch(error) {excelError=error.message;render();throw error;}break;
    }
    case 'period-form':period=safePeriod(v['period-from'],v['period-to']);render();break;
    case 'comparison-form':{const p=safePeriod(v['comparison-from'],v['comparison-to']);comparisonFrom=p.from;comparisonTo=p.to;render();break;}
    case 'manual-form': {
      const next=copy(S),journal=copy(manual);journal.id??=id();if(!journal.cashCategory)delete journal.cashCategory;
      const normalized=validateJournal(journal,next),index=next.j.findIndex(j=>String(j.id)===String(journal.id));if(index>=0)next.j[index]=normalized;else next.j.push(normalized);
      await persist(next,'Jurnal berhasil disimpan.');manual=newManual();manualDirty=false;navigate('journals');break;
    }
    case 'trade-form': {
      const journal=createTrade(S,{...v,quantity:Number(v.quantity),unitPrice:Number(v.unitPrice),...(v.paidAmount!==''?{paidAmount:Number(v.paidAmount)}:{paidAmount:undefined})});await addJournal(journal);navigate('journals');break;
    }
    case 'settlement-form': {
      const amount=Number(v.amount),receivable=v.settlementKind==='receivable',account=receivable?'1-1201':'2-1101';
      const due=subsidiary(S,account,{to:v.date}).find(r=>r.code===v.contact)?.balance||0;
      if(!Number.isSafeInteger(amount)||amount<=0)throw new Error('Nominal harus berupa Rupiah bulat positif.');if(amount>due)throw new Error(`Nominal melebihi saldo ${receivable?'piutang':'hutang'} kontak per tanggal transaksi (Rp ${F(due)}).`);
      await addJournal({id:id(),tgl:v.date,jn:'U',ket:v.description||`Pelunasan ${receivable?'piutang':'hutang'} ${v.contact}`,reference:v.reference,l:receivable?[[v.paymentAccount,amount,0],[account,0,amount,v.contact]]:[[account,amount,0,v.contact],[v.paymentAccount,0,amount]]});navigate('journals');break;
    }
    case 'journal-search':journalSearch=v['journal-query'];render();break;
    case 'ledger-form':ledgerAccount=v['ledger-account'];render();break;
    case 'entity-form': {const next=copy(S);next.settings={entity:v.entity,notes:v.notes};await persist(next);render();break;}
    case 'master-form': {
      const next=copy(S),row=[v['master-code'].trim(),v['master-name'].trim(),...(masterKind==='prod'?[Number(v['master-price'])]:[])];
      if(masterEdit!==null){const i=next[masterKind].findIndex(r=>r[0]===masterEdit);next[masterKind][i]=row;}else{if(next[masterKind].some(r=>r[0]===row[0]))throw new Error('Kode sudah digunakan.');next[masterKind].push(row);}
      await persist(next);masterEdit=null;render();break;
    }
    case 'profile-form': {
      const body={displayName:v.displayName,email:v.email,phone:v.phone};const file=form.elements.avatar.files[0];
      if(v.removeAvatar)body.avatar='';else if(file){if(file.size>256*1024||!['image/png','image/jpeg'].includes(file.type))throw new Error('Foto harus PNG/JPEG maksimal 256 KB.');body.avatar=`data:${file.type};base64,${await fileBase64(file)}`;}
      session.user=(await api('/profile',{method:'PATCH',body})).user;render();notice('Profil berhasil disimpan.');break;
    }
    case 'password-form':if(v.newPassword!==v.confirmPassword)throw new Error('Pengulangan kata sandi tidak sama.');await api('/password',{method:'POST',body:{currentPassword:v.currentPassword,newPassword:v.newPassword}});form.reset();notice('Kata sandi diperbarui dan sesi perangkat lain dihentikan.');break;
    case 'mfa-enable-form': {const result=await api('/mfa/enable',{method:'POST',body:{code:v['mfa-code']}});recoveryCodes=result.recoveryCodes;pendingMfa=null;session.user.mfaEnabled=true;render();notice('Autentikator aktif. Simpan kode pemulihan Anda.');break;}
    case 'mfa-disable-form':if(!confirm('Nonaktifkan autentikator untuk akun ini?'))return;await api('/mfa/disable',{method:'POST',body:{password:v['mfa-password'],code:v['mfa-code']}});session.user.mfaEnabled=false;pendingMfa=null;recoveryCodes=null;render();notice('Autentikator dinonaktifkan.');break;
    case 'user-form':await api('/users',{method:'POST',body:{username:v['user-username'],displayName:v['user-displayName'],password:v['user-password'],role:v['user-role']}});users=(await api('/users')).users;render();notice('Pengguna ditambahkan.');break;
    case 'backup-form': {
      if(v['backup-password']!==v['backup-confirm'])throw new Error('Pengulangan kata sandi cadangan tidak sama.');
      const encrypted=await encryptBackup(await api('/backup'),v['backup-password']);downloadJSON(encrypted,`keuangan-reza-${today()}.encrypted.json`);form.reset();notice('Cadangan terenkripsi siap diunduh. Periksa folder unduhan Anda.');break;
    }
    case 'restore-preview-form':{const file=form.elements.file.files[0];if(!file||file.size>72*1024*1024)throw new Error('Pilih cadangan maksimal 72 MB.');await prepareBackup(await file.text(),v['restore-password']);notice('Cadangan berhasil dibaca dan buku tervalidasi.');break;}
    case 'restore-confirm-form': {
      if(!backupPreview)throw new Error('Pratinjau cadangan tidak tersedia.');if(!confirm(`Ganti seluruh buku aktif (${S.j.length} jurnal) dengan cadangan (${backupPreview.state.j.length} jurnal)?`))return;
      const result=await api('/restore',{method:'POST',body:{backup:backupPreview,revision}});S=result.state;revision=result.revision;backupPreview=null;manual=newManual();manualDirty=false;csvPreview=[];attachmentJournal=null;attachmentList=[];render();notice('Buku berhasil dipulihkan. Snapshot buku sebelumnya tersimpan di server.');break;
    }
    case 'attachment-form': {
      const file=form.elements.file.files[0];if(!file||file.size>5*1024*1024||!['application/pdf','image/jpeg','image/png'].includes(file.type))throw new Error('Bukti harus PDF/JPEG/PNG maksimal 5 MB.');
      await api('/attachments',{method:'POST',body:{journalId:attachmentJournal,name:file.name,type:file.type,data:await fileBase64(file)}});await attachmentRefresh();render();notice('Bukti transaksi berhasil diunggah.');break;
    }
    case 'closing-form': {
      const p=safePeriod(v['closing-from'],v['closing-to']),journals=closingEntries(S,p.from,p.to);closingPreview={...p,journals,revision};
      $('#closing-preview').innerHTML=`<div class="notice mt"><strong>Pratinjau penutupan sampai ${E(p.to)}</strong><p>${journals.length?`Jurnal penutup sebesar Rp ${F(total(journals[0].l)[0])} akan dibuat.`:'Tidak ada saldo sementara yang perlu ditutup; periode akan dikunci.'}</p></div>${journals.length?table(['Akun','Debit','Kredit'],journals[0].l.map(l=>[E(l[0]),F(l[1]),F(l[2])]),[1,2]):''}<div class="mt">${btn('Tutup & kunci periode ini','confirm-closing')}</div>`;break;
    }
    case 'recon-account-form':reconAccount=v['recon-account'];csvPreview=[];render();break;
    case 'recon-manual-form': {
      const rows=[{id:id(),date:v['recon-date'],description:v['recon-description'],amount:Number(v['recon-amount']),account:reconAccount,journalId:null}];assertNewReconciliation(rows);await persist({...S,reconciliation:[...S.reconciliation,...rows]},'Mutasi rekening koran ditambahkan.');render();break;
    }
    case 'recon-csv-form':{const file=form.elements.file.files[0];if(!file||file.size>2*1024*1024)throw new Error('CSV harus berukuran maksimal 2 MB.');const rows=csvRows(await file.text());assertNewReconciliation(rows);csvPreview=rows;render();break;}
    default:if(form.classList.contains('user-update-form')){
      const body={role:v.role,disabled:Boolean(v.disabled)};if(v.password)body.password=v.password;
      const target=users?.find(u=>u.id===form.dataset.id);if(target?.id===session.user.id&&body.role!==target.role&&!confirm('Perubahan peran akan mengakhiri sesi Anda. Lanjutkan?'))return;
      await api(`/users/${encodeURIComponent(form.dataset.id)}`,{method:'PATCH',body});
      if(target?.id===session.user.id&&(v.password||body.role!==target.role)){resetPrivateState();authMode='login';renderAuth('Akun diperbarui. Silakan masuk kembali.');}else{users=(await api('/users')).users;render();notice('Pengguna diperbarui.');}
    }
  }
}
async function fileBase64(file) { const bytes=new Uint8Array(await file.arrayBuffer());let value='';for(let i=0;i<bytes.length;i+=32768)value+=String.fromCharCode(...bytes.subarray(i,i+32768));return btoa(value); }
async function handleAction(button) {
  const action=button.dataset.action;
  if(action==='dismiss'){$('#notice').replaceChildren();return;}
  if(action==='retry-boot'){await boot();return;}
  if(!session||!S)return;
  if(action.startsWith('go-')){navigate(action.slice(3));return;}
  switch(action) {
    case 'excel-reset':resetExcel();render();break;
    case 'excel-import': {
      if(!owner()||!excelPreview||excelPreview.revision!==revision)throw new Error('Pratinjau kedaluwarsa. Periksa & pratinjau kembali sebelum menyimpan.');
      const result=await api('/import-excel',{method:'POST',body:{...excelPreview.request,revision}});
      S=result.state;revision=result.revision;excelPreview=null;excelError='';render();notice(`Impor berhasil: ${result.summary.added} ${result.summary.label} ditambahkan; ${result.summary.skipped} data identik dilewati.`);break;
    }
    case 'mobile-menu':mobileOpen=!mobileOpen;render();break;
    case 'refresh':excelPreview=null;await refresh();users=null;audit=null;closingPreview=null;if(tab==='settings')await loadSettings();else render();notice('Data terbaru dimuat. Draf jurnal manual tetap tersedia.');break;
    case 'logout':if(manualDirty&&!confirm('Keluar dan buang draf jurnal yang belum disimpan?'))return;await api('/logout',{method:'POST',body:{}});resetPrivateState();authMode='login';renderAuth();break;
    case 'new-journal':inputTab='manual';navigate('input');break;
    case 'add-line':manual.l.push(['',0,0]);manualDirty=true;render();break;
    case 'remove-line':if(manual.l.length>2){manual.l.splice(Number(button.dataset.index),1);manualDirty=true;render();}break;
    case 'reset-draft':if(manualDirty&&!confirm('Buang draf jurnal yang belum disimpan?'))return;manual=newManual();manualDirty=false;render();break;
    case 'edit-journal': {
      if(manualDirty&&!confirm('Ganti draf yang belum disimpan dengan jurnal ini?'))return;const j=S.j.find(j=>String(j.id)===button.dataset.id);if(!j)throw new Error('Jurnal tidak ditemukan.');manual=copy(j);manualDirty=false;inputTab='manual';navigate('input');break;
    }
    case 'delete-journal': {
      const journal=S.j.find(j=>String(j.id)===button.dataset.id);if(!journal)throw new Error('Jurnal tidak ditemukan.');if(!confirm(`Hapus jurnal "${journal.ket}" (${journal.tgl}) beserta bukti terkait? Pencocokan rekening koran akan dilepas.`))return;
      const next=copy(S);next.j=next.j.filter(j=>String(j.id)!==button.dataset.id);next.reconciliation=next.reconciliation.map(r=>String(r.journalId)===button.dataset.id?{...r,journalId:null}:r);await persist(next,'Jurnal dihapus.');if(String(manual.id)===button.dataset.id){manual=newManual();manualDirty=false;}render();break;
    }
    case 'attachments':attachmentJournal=attachmentJournal===button.dataset.id?null:button.dataset.id;attachmentList=[];if(attachmentJournal)await attachmentRefresh();render();break;
    case 'delete-attachment':if(!confirm('Hapus bukti transaksi ini?'))return;await api(`/attachments/${encodeURIComponent(button.dataset.id)}`,{method:'DELETE'});await attachmentRefresh();render();notice('Bukti dihapus.');break;
    case 'edit-master':masterEdit=button.dataset.code;render();$('#master-name')?.focus();break;
    case 'cancel-master':masterEdit=null;render();break;
    case 'delete-master': {
      if(!confirm(`Hapus ${masterKind==='coa'?'akun':masterKind==='prod'?'produk':'kontak'} ${button.dataset.code}? Data yang digunakan jurnal tidak dapat dihapus.`))return;const next=copy(S);next[masterKind]=next[masterKind].filter(row=>row[0]!==button.dataset.code);await persist(next);masterEdit=null;render();break;
    }
    case 'mfa-setup':pendingMfa=await api('/mfa/setup',{method:'POST',body:{}});render();break;
    case 'download-recovery':if(recoveryCodes)download(new Blob([`Keuangan Reza — kode pemulihan untuk ${session.user.username}\nSimpan secara aman. Setiap kode hanya dapat dipakai sekali.\n\n${recoveryCodes.join('\n')}\n`],{type:'text/plain'}),'keuangan-reza-kode-pemulihan.txt');break;
    case 'dismiss-recovery':if(!confirm('Pastikan kode pemulihan sudah disimpan. Tutup tampilan kode?'))return;recoveryCodes=null;render();break;
    case 'revoke-sessions':await api('/sessions/revoke',{method:'POST',body:{}});notice('Semua sesi perangkat lain dihentikan.');break;
    case 'load-users':users=(await api('/users')).users;render();break;
    case 'load-audit':audit=(await api('/audit')).events;render();break;
    case 'preview-legacy':{let raw;try{raw=localStorage.getItem('keuangan-reza-v2');}catch{throw new Error('Browser tidak mengizinkan akses data lama.');}if(!raw)throw new Error('Data versi lama tidak ditemukan.');await prepareBackup(raw);notice('Data lama tersedia untuk ditinjau. Data sumber belum diubah.');break;}
    case 'cancel-restore':backupPreview=null;render();break;
    case 'export':download(makeWorkbook(S,{from:period.from||undefined,to:period.to||undefined}),`keuangan-reza-${period.to||today()}.xlsx`);notice('Workbook siap diunduh.');break;
    case 'print':window.print();break;
    case 'confirm-closing': {
      if(!closingPreview||closingPreview.revision!==revision)throw new Error('Pratinjau penutupan kedaluwarsa. Periksa kembali periode.');if(!confirm(`Tutup dan kunci seluruh transaksi sampai ${closingPreview.to}?`))return;
      const next=copy(S);next.j.push(...closingPreview.journals);next.closedThrough=closingPreview.to;await persist(next,'Periode ditutup dan dikunci.');closingPreview=null;render();break;
    }
    case 'unlock-period':if(!confirm(`Buka kunci seluruh periode sampai ${S.closedThrough}? Jurnal penutup tetap tersimpan. Periksa dan hapus penutup yang terkait sebelum mengubah atau menutup ulang.`))return;await persist({...S,closedThrough:''},'Periode dibuka. Jurnal penutup tetap tersimpan untuk ditinjau.');render();break;
    case 'cancel-csv':csvPreview=[];render();break;
    case 'import-csv':assertNewReconciliation(csvPreview);await persist({...S,reconciliation:[...S.reconciliation,...csvPreview]},`${csvPreview.length} mutasi rekening koran ditambahkan.`);csvPreview=[];render();break;
    case 'delete-recon':if(!confirm('Hapus mutasi rekening koran ini? Jurnal pembukuan tidak dihapus.'))return;await persist({...S,reconciliation:S.reconciliation.filter(r=>String(r.id)!==button.dataset.id)});render();break;
  }
}

document.addEventListener('submit',event=>{const form=event.target;if(!(form instanceof HTMLFormElement))return;event.preventDefault();void task(()=>handleSubmit(form));});
document.addEventListener('click',event=>{
  const target=event.target.closest('button,a');if(!target)return;
  if(target.dataset.tab){event.preventDefault();navigate(target.dataset.tab);if(tab==='settings')void task(loadSettings);return;}
  if(target.dataset.settingTab){settingTab=target.dataset.settingTab;render();void task(loadSettings);return;}
  if(target.dataset.inputTab){inputTab=target.dataset.inputTab;render();return;}
  if(target.dataset.masterKind){masterKind=target.dataset.masterKind;masterEdit=null;render();return;}
  if(target.dataset.action){event.preventDefault();void task(()=>handleAction(target));}
});
document.addEventListener('input',event=>{
  const input=event.target;if(input.dataset.manual){manual[input.dataset.manual]=input.value;manualDirty=true;}
  if(input.dataset.line!==undefined){const i=Number(input.dataset.line),key=Number(input.dataset.field);manual.l[i][key]=[1,2,4].includes(key)?Number(input.value||0):input.value;manualDirty=true;if(key===0){manual.l[i]=[input.value,manual.l[i][1],manual.l[i][2]];const item=input.closest('.line-item');if(item)item.outerHTML=renderLine(manual.l[i],i);}const t=$('#line-totals');if(t)t.innerHTML=lineTotals(...total(manual.l));}
});
document.addEventListener('change',event=>{
  const input=event.target;
  if(input.id==='excel-sheet'){excelSheet=Number(input.value);resetExcelMapping();render();}
  if(input.id==='excel-kind'){excelKind=input.value;resetExcelMapping();render();}
  if(input.id==='excel-account'){excelAccount=input.value;excelPreview=null;excelError='';render();}
  if(input.id.startsWith('excel-map-')){excelMapping[input.id.slice('excel-map-'.length)]=Number(input.value);excelPreview=null;excelError='';render();}
  if(input.id==='compare-toggle'){comparison=input.checked;if(comparison&&!comparisonTo){const end=new Date(`${period.to||today()}T12:00:00Z`);end.setUTCFullYear(end.getUTCFullYear()-1);comparisonTo=end.toISOString().slice(0,10);if(period.from){const start=new Date(`${period.from}T12:00:00Z`);start.setUTCFullYear(start.getUTCFullYear()-1);comparisonFrom=start.toISOString().slice(0,10);}}render();}
  if(input.id==='product'&&input.closest('#trade-form')){const price=S.prod.find(p=>p[0]===input.value)?.[2];if(price&&!$('#unitPrice').value)$('#unitPrice').value=price;}
  if(input.dataset.reconMatch){void task(async()=>{const next=copy(S),row=next.reconciliation.find(r=>String(r.id)===input.dataset.reconMatch);row.journalId=input.value||null;try{await persist(next,'Pencocokan disimpan.');}finally{render();}});}
});
window.addEventListener('beforeunload',event=>{if(manualDirty){event.preventDefault();event.returnValue='';}});
window.addEventListener('hashchange',()=>{const next=location.hash.slice(1);if(session&&S&&nav.some(([key])=>key===next)){navigate(next);if(tab==='settings')void task(loadSettings);}});
async function boot() {
  try {
    if('serviceWorker' in navigator){const registrations=await navigator.serviceWorker.getRegistrations();for(const registration of registrations){const worker=registration.active||registration.waiting||registration.installing;if(worker&&new URL(worker.scriptURL).pathname==='/sw.js')await registration.unregister();}if('caches'in window)for(const name of await caches.keys())if(name.startsWith('keuangan-reza'))await caches.delete(name);}
    const status=await api('/status');authMode=status.initialized?'login':'setup';
    if(status.initialized){try{session=await api('/session');}catch(error){if(error.status!==401)throw error;}}
    if(session){await refresh();const initial=location.hash.slice(1);tab=nav.some(([key])=>key===initial)?initial:'home';render();if(tab==='settings')await loadSettings();}else renderAuth();
  } catch(error) {
    $('#app').innerHTML=`<main id="main" class="loading-screen"><span class="brand-mark">KR</span><h1>Server belum dapat dihubungi</h1><p>${E(error.message)}</p>${btn('Coba hubungkan kembali','retry-boot')}<p class="hint mt">Pastikan server Keuangan Reza berjalan, lalu buka alamat server yang benar.</p></main>`;
  }
}
void boot();
