# Mulai menggunakan Keuangan Reza

1. Ekstrak seluruh isi ZIP. Jangan menjalankan file langsung dari dalam ZIP.
2. Pasang Node.js **24.13 atau versi 24.x yang lebih baru** pada komputer Anda.
3. Jalankan aplikasi:
   - **Windows:** klik dua kali `MULAI-WINDOWS.cmd`.
   - **Linux/macOS:** buka terminal di folder aplikasi, lalu jalankan `bash mulai.sh`.
4. Biarkan jendela terminal tetap terbuka. Buka alamat yang ditampilkan server di browser; bawaan `http://127.0.0.1:3000`.
5. Buat akun pemilik dengan kata sandi Anda sendiri. Tidak ada akun bawaan.
6. Isi data master yang diperlukan, lalu catat saldo awal dan transaksi. Panduan tersedia di menu **Panduan**.

Launcher membuat `.env` hanya jika belum tersedia. Konfigurasi yang sudah ada dan data pengguna tetap dipertahankan. Paket tidak memerlukan `npm install` untuk penggunaan normal.

Untuk menghentikan aplikasi, tekan **Ctrl+C** di terminal. Jalankan file yang sama untuk memulai lagi. Data tersimpan pada folder `data/`. Jangan menghapus folder ini saat memperbarui aplikasi.

Jika port sudah digunakan, hentikan instance Keuangan Reza yang sebelumnya Anda jalankan, atau ubah `PORT` dalam `.env` ke port kosong. Jangan menghentikan program lain tanpa mengenalinya.

Buat cadangan rutin dari **Pengaturan → Cadangan & pemulihan**. Untuk mencadangkan seluruh server, termasuk akun dan MFA, gunakan [panduan operasi](docs/operations.md#backup-dan-pemulihan).

Akses dari HP memerlukan server yang dapat dijangkau melalui HTTPS; `localhost` pada HP menunjuk ke HP itu sendiri. Jangan mengunggah paket ini sebagai website statis karena login dan penyimpanan membutuhkan server Node.js. Lihat [panduan deployment](docs/operations.md#https-dan-akses-dari-perangkat-lain).

Format `.krb` dari situs lama belum dapat dipastikan kompatibel. Simpan file asli dan baca petunjuk migrasi di [README](README.md) sebelum melakukan pemulihan.

## Memperbarui ke versi 3.1 (Impor Excel)

1. Buat cadangan, lalu hentikan aplikasi lama dengan Ctrl+C.
2. Ekstrak ZIP versi baru ke folder terpisah.
3. Jika sudah memakai aplikasi, **salin** folder `data` beserta seluruh isinya dan file `.env` dari folder lama ke folder baru. Pertahankan folder lama sebagai cadangan. Jika `DATA_DIR` pada `.env` mengarah ke lokasi khusus, gunakan lokasi yang sama.
4. Jalankan `MULAI-WINDOWS.cmd` atau `bash mulai.sh` dari folder baru; muat ulang browser. Login dengan akun yang sama.
5. Buka **Impor Excel**, unduh template atau pilih file `.xlsx` Anda. Ikuti [panduan impor](docs/impor-excel.md).

Impor Excel hanya tampil bagi pemilik. Pilihan kolom dan pratinjau muncul setelah file berhasil dibaca.
