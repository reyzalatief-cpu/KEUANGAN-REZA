/** Read locally in an isolated worker. No workbook content leaves the browser. */
export async function readExcelFile(file) {
  if (!file || !/\.xlsx$/i.test(file.name || '')) {
    throw new Error('Pilih file Excel .xlsx. Simpan ulang file .xls atau .xlsm sebagai .xlsx terlebih dahulu.');
  }
  if (!file.size || file.size > 10 * 1024 * 1024) {
    throw new Error('Ukuran Excel harus lebih dari nol dan maksimal 10 MB.');
  }
  const buffer = await file.arrayBuffer();
  return new Promise((resolve, reject) => {
    const worker = new Worker(new URL('./excel-worker.js', import.meta.url), { type: 'module' });
    const finish = (error, result) => {
      clearTimeout(timer);
      worker.terminate();
      if (error) reject(new Error(error));
      else resolve(result);
    };
    const timer = setTimeout(() => finish('Pembacaan Excel terlalu lama. Bagi data menjadi file yang lebih kecil lalu coba lagi.'), 15000);
    worker.onmessage = ({ data }) => finish(data.error, data.result);
    worker.onerror = () => finish('Excel tidak dapat dibaca. Pastikan file .xlsx valid, tidak dilindungi kata sandi, dan browser sudah diperbarui.');
    worker.postMessage(buffer, [buffer]);
  });
}
