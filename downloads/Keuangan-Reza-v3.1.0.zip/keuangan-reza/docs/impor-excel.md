# Impor Excel

Masuk sebagai **Pemilik** lalu buka **Impor Excel**. Buat cadangan melalui Pengaturan sebelum memasukkan data dalam jumlah besar.

1. Unduh **template Excel** dari menu impor, atau gunakan file `.xlsx` milik Anda.
2. Letakkan judul kolom pada baris pertama. Hindari sel gabungan, baris judul tambahan, subtotal, dan baris total di tengah data.
3. Pilih file → **Baca Excel**.
4. Pilih lembar kerja dan jenis data. Cocokkan setiap kolom wajib dengan kolom Excel Anda; nama judul kolom tidak harus sama dengan template.
5. Klik **Periksa & pratinjau**. Periksa jumlah data baru, data identik yang dilewati, dan contoh baris.
6. Klik **Simpan impor**. Data baru masuk ke buku hanya setelah server berhasil menyimpan.

Impor dilakukan **satu lembar dan satu jenis data sekaligus**. Jika satu baris tidak valid, seluruh impor lembar itu ditolak. Data lama tidak ditimpa. Jika buku berubah di sesi lain, muat ulang data dan buat pratinjau kembali.

## Jenis data

| Jenis | Kolom utama | Hasil |
|---|---|---|
| Jurnal | nomor, tanggal, keterangan, kode_akun, debit, kredit | Jurnal pembukuan; satu nomor dapat memiliki beberapa baris akun |
| Kas masuk/keluar | nomor, tanggal, keterangan, arah, jumlah, akun_lawan | Jurnal dua sisi pada rekening kas/bank yang dipilih |
| Kontak | kode, nama | Master pelanggan/pemasok |
| Produk | kode, nama; harga opsional | Master produk, belum termasuk saldo stok |
| Akun | kode, nama | Master akun dengan format kode seperti `1-1104` |
| Mutasi bank | date, description, amount | Rekonsiliasi rekening; tidak otomatis membuat jurnal |

Kolom tambahan jurnal: `jenis` (`A` saldo awal, `U` umum, `P` penyesuaian; kosong berarti `U`), `kode_bantu`, `kuantitas`, `referensi`, `kategori`. Penutup periode tetap dilakukan melalui menu Penutupan Periode.

Kolom tambahan kas: `kontak` untuk piutang/hutang dan `kategori` arus kas. `arah` diisi `Masuk` atau `Keluar`; `jumlah` selalu positif. Pembelian/penjualan persediaan tidak dimasukkan melalui format kas sederhana: gunakan jurnal lengkap dengan nilai persediaan dan HPP yang benar, atau menu transaksi dagang.

## Nilai dan contoh

- Gunakan tanggal Excel asli atau teks `2026-10-01` (YYYY-MM-DD).
- Nominal merupakan angka Rupiah bulat; teks seperti `Rp 10.000` harus dibersihkan dahulu. Nominal desimal tidak dibulatkan otomatis.
- Tulis kode sebagai teks agar nol di depan tidak hilang.
- Nomor transaksi harus unik dan tetap. Dua baris jurnal dengan nomor sama adalah bagian transaksi yang sama, sehingga tanggal, jenis, dan keterangannya harus konsisten.
- Debit dan kredit harus seimbang. Akun, kontak, dan produk harus sudah terdaftar; impor master terlebih dahulu.
- Piutang/hutang memerlukan kode kontak. Persediaan memerlukan kode produk serta kuantitas; nilai keluar harus sesuai HPP rata-rata bergerak dan stok tidak boleh negatif.
- Mutasi bank menggunakan nominal positif untuk uang masuk, negatif untuk uang keluar.

Contoh saldo awal pada lembar Jurnal:

| nomor | tanggal | jenis | keterangan | kode_akun | debit | kredit |
|---|---|---|---|---|---:|---:|
| AWAL-001 | 2026-10-01 | A | Setoran modal | 1-1102 | 1000000 | 0 |
| AWAL-001 | 2026-10-01 | A | Setoran modal | 3-1001 | 0 | 1000000 |

Contoh di atas hanya dokumentasi. Lembar data pada template sengaja kosong agar transaksi contoh tidak masuk ke buku Anda.

## Pengulangan dan koreksi

Impor ulang transaksi dari fitur ini dengan nomor dan isi identik dilewati. Nomor sama dengan isi berbeda ditolak; koreksi jurnal yang sudah tersimpan melalui menu Jurnal. Kode master identik dilewati, sedangkan kode sama dengan nama/harga berbeda ditolak. Mutasi bank identik dibandingkan menurut rekening, tanggal, keterangan, dan nominal.

Transaksi yang sebelumnya dicatat manual atau berasal dari mekanisme lain belum tentu memiliki identitas impor yang sama. Periksa buku dan rentang tanggal sumber sebelum mengimpor agar tidak mencatat transaksi ekonomis yang sama dua kali. Jangan mengganti nomor hanya untuk menghindari pesan konflik.

## Batas dan privasi

File dibaca di browser memakai pustaka yang disertakan dalam aplikasi. Hanya baris dari lembar terpilih yang dikirim ke server Anda ketika menekan Simpan impor. Tidak ada pengiriman ke AI atau layanan pihak lain.

Format yang didukung adalah `.xlsx` biasa, bukan `.xls`, `.xlsm`, atau file terenkripsi. Batas: 10 MB file, 20 lembar, 10.000 baris data dan 100 kolom per lembar, serta batas ukuran isi arsip untuk melindungi browser. File sangat besar perlu dibagi.

Rumus tidak dieksekusi atau dihitung ulang. Pembaca memakai nilai hasil terakhir yang tersimpan oleh Excel; nilai itu bisa kedaluwarsa. Untuk kepastian, salin lalu **Paste Special → Values** di salinan file sumber sebelum impor. Ekspor laporan aplikasi bukan format pemulihan buku; gunakan template atau petakan hanya tabel sumber yang sesuai.
