import { unzipSync, parseContents } from './vendor/excel-parser.js';

const fail = message => { throw new Error(message); };
const MAX_EXPANDED = 50 * 1024 * 1024;
const decoder = new TextDecoder('utf-8', { fatal: true });
const crcTable = Array.from({ length: 256 }, (_, n) => {
  for (let i = 0; i < 8; i++) n = n & 1 ? 0xedb88320 ^ n >>> 1 : n >>> 1;
  return n >>> 0;
});
const crc32 = bytes => {
  let crc = 0xffffffff;
  for (const byte of bytes) crc = crcTable[(crc ^ byte) & 255] ^ crc >>> 8;
  return (crc ^ 0xffffffff) >>> 0;
};

/** Bound ZIP allocations before inflation; verify every expanded XML using CRC. */
function inspectArchive(buffer) {
  const bytes = new Uint8Array(buffer), view = new DataView(buffer);
  if (bytes.length < 22 || bytes.length > 10 * 1024 * 1024 || view.getUint32(0, true) !== 0x04034b50) {
    fail('File bukan Excel .xlsx yang valid atau dilindungi kata sandi.');
  }
  let end = bytes.length - 22;
  for (; end >= Math.max(0, bytes.length - 65557); end--) {
    if (view.getUint32(end, true) === 0x06054b50 && end + 22 + view.getUint16(end + 20, true) === bytes.length) break;
  }
  if (end < 0 || view.getUint32(end, true) !== 0x06054b50) fail('Arsip Excel rusak.');
  const count = view.getUint16(end + 10, true), size = view.getUint32(end + 12, true);
  let pos = view.getUint32(end + 16, true), expanded = 0;
  if (view.getUint16(end + 4, true) || view.getUint16(end + 6, true) || view.getUint16(end + 8, true) !== count ||
      count > 512 || !count || pos + size !== end) fail('Struktur arsip Excel tidak didukung atau terlalu besar.');
  const entries = new Map();
  for (let i = 0; i < count; i++) {
    if (pos + 46 > end || view.getUint32(pos, true) !== 0x02014b50) fail('Direktori Excel rusak.');
    const flags = view.getUint16(pos + 8, true), method = view.getUint16(pos + 10, true);
    const compressed = view.getUint32(pos + 20, true), original = view.getUint32(pos + 24, true);
    const nameLength = view.getUint16(pos + 28, true), extra = view.getUint16(pos + 30, true), comment = view.getUint16(pos + 32, true);
    const local = view.getUint32(pos + 42, true);
    if (pos + 46 + nameLength + extra + comment > end || local + 30 > end) fail('Entri Excel rusak.');
    const name = decoder.decode(bytes.subarray(pos + 46, pos + 46 + nameLength));
    if (flags & 1 || ![0, 8].includes(method) || name.startsWith('/') || name.includes('\\') || name.split('/').includes('..') ||
        entries.has(name) || name === '__proto__' || name === 'constructor' || /vbaProject|macrosheets/i.test(name)) {
      fail('Excel terenkripsi, bermakro, atau berstruktur tidak didukung. Simpan sebagai .xlsx biasa.');
    }
    expanded += original;
    if (original > 20 * 1024 * 1024 || expanded > MAX_EXPANDED) fail('Isi Excel terlalu besar. Bagi data menjadi beberapa file.');
    if (view.getUint32(local, true) !== 0x04034b50) fail('Entri Excel rusak.');
    const start = local + 30 + view.getUint16(local + 26, true) + view.getUint16(local + 28, true);
    if (start + compressed > end || method === 0 && compressed !== original) fail('Ukuran entri Excel tidak valid.');
    entries.set(name, { original, crc: view.getUint32(pos + 16, true) });
    pos += 46 + nameLength + extra + comment;
  }
  if (pos !== end || !entries.has('xl/workbook.xml') || !entries.has('[Content_Types].xml')) fail('Struktur workbook Excel tidak ditemukan.');
  if ([...entries.keys()].filter(name => /^xl\/worksheets\/[^/]+\.xml$/i.test(name)).length > 20) {
    fail('Maksimal 20 lembar kerja per file.');
  }
  return { bytes, entries };
}

function checkXml(name, xml) {
  if (/<!DOCTYPE|<!ENTITY/i.test(xml)) fail('Deklarasi XML eksternal tidak didukung.');
  if (name === '[Content_Types].xml' && /macroEnabled/i.test(xml)) fail('Workbook bermakro tidak didukung.');
  if (!/^xl\/worksheets\/[^/]+\.xml$/i.test(name)) return;
  for (const cell of xml.matchAll(/<(?:[\w.-]+:)?c\b(?![^>]*\/>)([^>]*)>([\s\S]*?)<\/(?:[\w.-]+:)?c\s*>/g)) {
    if (/<(?:[\w.-]+:)?f\b/.test(cell[2])) {
      const value = /<(?:[\w.-]+:)?v\b[^>]*>([\s\S]*?)<\/(?:[\w.-]+:)?v\s*>/.exec(cell[2]);
      if (!value?.[1]?.trim() || /\bt\s*=\s*["']e["']/.test(cell[1])) {
        fail('Rumus Excel belum memiliki hasil tersimpan yang valid. Hitung ulang dan simpan di Excel, atau salin lalu Tempel Khusus → Nilai sebelum mengimpor.');
      }
    }
  }
  let cells = 0;
  for (const match of xml.matchAll(/<(?:[\w.-]+:)?(?:row|c)\b[^>]*\br\s*=\s*["']([^"']+)["']/g)) {
    const ref = /^([A-Z]*)(\d+)$/.exec(match[1]);
    if (!ref) fail('Alamat sel Excel tidak valid.');
    let column = 0;
    for (const letter of ref[1]) column = column * 26 + letter.charCodeAt(0) - 64;
    if (Number(ref[2]) > 10001 || column > 100 || ++cells > 250000) {
      fail('Maksimal 10.000 baris data, 100 kolom, dan 250.000 sel per lembar. Hapus baris/kolom kosong yang berada jauh di bawah data.');
    }
  }
}

export async function parseExcelBuffer(buffer) {
  const { bytes, entries } = inspectArchive(buffer);
  const contents = unzipSync(bytes, { filter: entry => /\.xml(?:\.rels)?$/i.test(entry.name) || /\.rels$/i.test(entry.name) });
  for (const [name, value] of Object.entries(contents)) {
    const expected = entries.get(name);
    if (!expected || value.length !== expected.original || crc32(value) !== expected.crc) fail('Isi Excel rusak atau checksum tidak cocok.');
    checkXml(name, decoder.decode(value));
  }
  const workbook = await parseContents(contents);
  if (!workbook.length || workbook.length > 20) fail('Workbook harus berisi 1 sampai 20 lembar.');
  const sheets = workbook.map(sheet => {
    if (sheet.data.length > 10001 || sheet.data.some(row => row.length > 100)) fail('Maksimal 10.000 baris data dan 100 kolom per lembar.');
    return { name: sheet.sheet, rows: sheet.data };
  });
  return { sheets };
}

if (typeof self !== 'undefined' && typeof document === 'undefined') {
  self.onmessage = async ({ data }) => {
    try {
      self.postMessage({ result: await parseExcelBuffer(data) });
    } catch (error) {
      self.postMessage({ error: `Gagal membaca Excel: ${error.message || 'file tidak valid.'}` });
    }
  };
}
