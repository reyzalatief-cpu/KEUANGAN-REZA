import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { deflateRawSync } from 'node:zlib';
import { parseExcelBuffer } from '../excel-worker.js';
import { unzipSync } from '../vendor/excel-parser.js';

const arrayBuffer = bytes => bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
const fixture = name => readFileSync(new URL(`./browser/fixtures/${name}.xlsx`, import.meta.url));
const entries = bytes => unzipSync(bytes);
function crc32(bytes) {
  let crc = 0xffffffff;
  for (const byte of bytes) {
    crc ^= byte;
    for (let i = 0; i < 8; i++) crc = crc & 1 ? 0xedb88320 ^ crc >>> 1 : crc >>> 1;
  }
  return (crc ^ 0xffffffff) >>> 0;
}
function pack(files) {
  const local = [], central = [];
  let offset = 0, centralSize = 0;
  for (const [filename, value] of Object.entries(files)) {
    const name = Buffer.from(filename), body = Buffer.from(value), compressed = deflateRawSync(body), crc = crc32(body);
    const header = Buffer.alloc(30);
    header.writeUInt32LE(0x04034b50); header.writeUInt16LE(20, 4); header.writeUInt16LE(8, 8);
    header.writeUInt32LE(crc, 14); header.writeUInt32LE(compressed.length, 18); header.writeUInt32LE(body.length, 22); header.writeUInt16LE(name.length, 26);
    const directory = Buffer.alloc(46);
    directory.writeUInt32LE(0x02014b50); directory.writeUInt16LE(20, 4); directory.writeUInt16LE(20, 6); directory.writeUInt16LE(8, 10);
    directory.writeUInt32LE(crc, 16); directory.writeUInt32LE(compressed.length, 20); directory.writeUInt32LE(body.length, 24); directory.writeUInt16LE(name.length, 28);
    directory.writeUInt32LE(offset, 42);
    local.push(header, name, compressed); central.push(directory, name);
    offset += header.length + name.length + compressed.length; centralSize += directory.length + name.length;
  }
  const end = Buffer.alloc(22); end.writeUInt32LE(0x06054b50);
  end.writeUInt16LE(central.length / 2, 8); end.writeUInt16LE(central.length / 2, 10);
  end.writeUInt32LE(centralSize, 12); end.writeUInt32LE(offset, 16);
  return Buffer.concat([...local, ...central, end]);
}
function changeSheet(files, fn) {
  files['xl/worksheets/sheet1.xml'] = Buffer.from(fn(Buffer.from(files['xl/worksheets/sheet1.xml']).toString()));
  return pack(files);
}

test('XLSX reads compressed native date, numbers and inline text without executing Excel', async () => {
  const result = await parseExcelBuffer(arrayBuffer(fixture('journals')));
  assert.equal(result.sheets[0].name, 'Jurnal');
  const row = result.sheets[0].rows[1];
  assert.equal(row[0], 'EXCEL-001');
  assert.equal(row[1].toISOString(), '2026-11-01T00:00:00.000Z');
  assert.equal(row[5], 250000);
});

test('template contains instructions and empty data sheets only', async () => {
  const data = readFileSync(new URL('../templates/impor-excel.xlsx', import.meta.url));
  const { sheets } = await parseExcelBuffer(arrayBuffer(data));
  assert.deepEqual(sheets.map(s => s.name), ['Panduan', 'Jurnal', 'Kas', 'Kontak', 'Produk', 'Akun', 'Mutasi']);
  for (const sheet of sheets.slice(1)) assert.equal(sheet.rows.length, 1);
});

test('shared strings preserve codes and XML escaped text', async () => {
  const files = entries(fixture('journals'));
  files['xl/sharedStrings.xml'] = Buffer.from('<?xml version="1.0"?><sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="1" uniqueCount="1"><si><t>001 &amp; Aman</t></si></sst>');
  files['xl/_rels/workbook.xml.rels'] = Buffer.from(Buffer.from(files['xl/_rels/workbook.xml.rels']).toString().replace('</Relationships>', '<Relationship Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml" Id="rIdShared"/></Relationships>'));
  const buffer = changeSheet(files, xml => xml.replace(/<c r="A2"[^>]*>[\s\S]*?<\/c>/, '<c r="A2" t="s"><v>0</v></c>'));
  const { sheets } = await parseExcelBuffer(arrayBuffer(buffer));
  assert.equal(sheets[0].rows[1][0], '001 & Aman');
});

test('cached formulas read saved numeric value, missing or error cache is rejected', async () => {
  await assert.rejects(parseExcelBuffer(arrayBuffer(fixture('formula-uncached'))), /Rumus Excel/);
  const files = entries(fixture('journals'));
  const withFormula = changeSheet(files, xml => xml.replace(/<c r="F2"[^>]*>[\s\S]*?<\/c>/, '<c r="F2"><f>125000*2</f><v>250000</v></c>'));
  assert.equal((await parseExcelBuffer(arrayBuffer(withFormula))).sheets[0].rows[1][5], 250000);
  const withError = changeSheet(files, xml => xml.replace(/<c r="F2"[^>]*>[\s\S]*?<\/c>/, '<c r="F2" t="e"><f>1/0</f><v>#DIV/0!</v></c>'));
  await assert.rejects(parseExcelBuffer(arrayBuffer(withError)), /Rumus Excel/);
});

test('malformed, encrypted, macro archives and inflated-size claims are rejected', async () => {
  await assert.rejects(parseExcelBuffer(arrayBuffer(Buffer.from('not excel'))), /valid|kata sandi/);
  const original = fixture('journals');
  const central = original.indexOf(Buffer.from([0x50, 0x4b, 0x01, 0x02]));
  const encrypted = Buffer.from(original); encrypted.writeUInt16LE(1, central + 8);
  await assert.rejects(parseExcelBuffer(arrayBuffer(encrypted)), /terenkripsi/);
  const oversized = Buffer.from(original); oversized.writeUInt32LE(0x7fffffff, central + 24);
  await assert.rejects(parseExcelBuffer(arrayBuffer(oversized)), /terlalu besar/);
  const corrupt = Buffer.from(original); corrupt.writeUInt32LE(0, central + 16);
  await assert.rejects(parseExcelBuffer(arrayBuffer(corrupt)), /checksum/);
  const macro = entries(original); macro['xl/vbaProject.bin'] = Buffer.from('macro');
  await assert.rejects(parseExcelBuffer(arrayBuffer(pack(macro))), /bermakro/);
});

test('large row addresses and external XML entities are rejected before worksheet allocation', async () => {
  const files = entries(fixture('journals'));
  await assert.rejects(parseExcelBuffer(arrayBuffer(changeSheet(files, xml => xml.replace('r="A2"', 'r="A1048576"')))), /10.000 baris/);
  await assert.rejects(parseExcelBuffer(arrayBuffer(changeSheet(files, xml => '<!DOCTYPE worksheet [<!ENTITY data SYSTEM "file:///etc/passwd">]>' + xml))), /XML eksternal/);
});
