import test from 'node:test';
import assert from 'node:assert/strict';
import { emptyState, validateState } from '../accounting.js';
import { prepareImport, suggestMapping, IMPORT_KINDS } from '../excel-import.js';

const masterMapping = { kode: 0, nama: 1 };
const journalMapping = { nomor: 0, tanggal: 1, keterangan: 2, kode_akun: 3, debit: 4, kredit: 5, jenis: -1, kode_bantu: -1, kuantitas: -1, referensi: -1, kategori: -1 };
const journals = (nomor = 'REF-001', amount = 10000, tanggal = '2026-10-01') => [
  [nomor, tanggal, 'Modal Excel', '1-1101', amount, 0],
  [nomor, tanggal, 'Modal Excel', '3-1001', 0, amount],
];
const importJournals = (state, rows, mapping = journalMapping) => prepareImport(state, { kind: 'journals', rows, mapping });

test('six supported Excel data types expose real mapping fields', () => {
  assert.deepEqual(new Set(IMPORT_KINDS.map(kind => kind.id)), new Set(['journals', 'cash', 'contacts', 'products', 'accounts', 'bank']));
  for (const kind of IMPORT_KINDS) {
    assert.ok(kind.label);
    assert.ok(kind.fields.length);
    assert.equal(new Set(kind.fields.map(field => field.key)).size, kind.fields.length);
  }
});

test('column suggestions map named headers independently of their order', () => {
  const mapping = suggestMapping('products', ['harga', 'nama', 'kode']);
  assert.equal(mapping.kode, 2);
  assert.equal(mapping.nama, 1);
  assert.equal(mapping.harga, 0);
  assert.equal(suggestMapping('contacts', ['unknown']).kode, -1);
});

test('contacts and products append safely, preserving leading zero codes and existing data', () => {
  const initial = emptyState();
  const contact = prepareImport(initial, { kind: 'contacts', mapping: masterMapping, rows: [['001', 'Pelanggan Excel']] });
  assert.equal(contact.summary.added, 1);
  assert.deepEqual(contact.state.bantu, [['001', 'Pelanggan Excel']]);
  const product = prepareImport(contact.state, { kind: 'products', mapping: { ...masterMapping, harga: 2 }, rows: [['SKU-01', 'Produk Excel', 12500]] });
  assert.deepEqual(product.state.prod, [['SKU-01', 'Produk Excel', 12500]]);
  assert.deepEqual(product.state.bantu, contact.state.bantu);
  assert.deepEqual(initial, emptyState());
});

test('new account appends without removing required accounts', () => {
  const initial = emptyState();
  const result = prepareImport(initial, { kind: 'accounts', mapping: masterMapping, rows: [['1-1104', 'Bank kedua']] });
  assert.equal(result.state.coa.length, initial.coa.length + 1);
  assert.deepEqual(result.state.coa.at(-1), ['1-1104', 'Bank kedua']);
  assert.doesNotThrow(() => validateState(result.state));
  assert.throws(() => prepareImport(initial, { kind: 'accounts', mapping: masterMapping, rows: [['arbitrary', 'Bukan kode akun']] }));
});

test('identical masters are skipped and conflicting names cannot overwrite history', () => {
  const initial = emptyState();
  initial.bantu.push(['CUS-01', 'Nama Asli']);
  const request = { kind: 'contacts', mapping: masterMapping, rows: [['CUS-01', 'Nama Asli']] };
  const result = prepareImport(initial, request);
  assert.equal(result.summary.added, 0);
  assert.equal(result.summary.skipped, 1);
  assert.throws(() => prepareImport(initial, { ...request, rows: [['CUS-01', 'Nama Baru']] }));
  assert.equal(initial.bantu[0][1], 'Nama Asli');
});

test('one balanced reference becomes one journal with unused optional mappings', () => {
  const result = importJournals(emptyState(), journals());
  assert.equal(result.summary.added, 1);
  assert.equal(result.state.j.length, 1);
  assert.equal(result.state.j[0].jn, 'U');
  assert.equal(result.state.j[0].tgl, '2026-10-01');
  assert.deepEqual(result.state.j[0].l, [['1-1101', 10000, 0], ['3-1001', 0, 10000]]);
  assert.doesNotThrow(() => validateState(result.state));
});

test('same journal reference and data are idempotent while changed data is rejected', () => {
  const first = importJournals(emptyState(), journals());
  const again = importJournals(first.state, journals());
  assert.equal(again.summary.added, 0);
  assert.equal(again.summary.skipped, 1);
  assert.deepEqual(again.state.j, first.state.j);
  assert.throws(() => importJournals(first.state, journals('REF-001', 20000)));
});

test('journal with cash category remains idempotent after accounting normalization changes property order', () => {
  const mapping = { ...journalMapping, kategori: 6, referensi: 7 };
  const rows = journals('WITH-CATEGORY').map(row => [...row, 'Pendanaan', 'Bukti Excel']);
  const first = importJournals(emptyState(), rows, mapping);
  const again = importJournals(first.state, rows, mapping);
  assert.equal(again.summary.added, 0);
  assert.equal(again.summary.skipped, 1);
  assert.deepEqual(again.state, first.state);
});

test('invalid journal anywhere rejects the entire file without modifying the original state', () => {
  const initial = emptyState(), before = structuredClone(initial);
  const broken = journals('BROKEN');
  broken[1][5] = 9999;
  assert.throws(() => importJournals(initial, [...journals('VALID'), ...broken]), /debit|kredit|seimbang/i);
  assert.deepEqual(initial, before);
});

test('journal account references and consistent group metadata are required', () => {
  const unknown = journals();
  unknown[0][3] = '1-9999';
  assert.throws(() => importJournals(emptyState(), unknown));
  const inconsistent = journals();
  inconsistent[1][1] = '2026-10-02';
  assert.throws(() => importJournals(emptyState(), inconsistent));
});

test('locked periods and manually imported closing journals are rejected', () => {
  const initial = emptyState();
  initial.closedThrough = '2026-10-31';
  assert.throws(() => importJournals(initial, journals()), /kunci|periode|tutup/i);
  const rows = journals().map(row => [...row, 'T']);
  assert.throws(() => importJournals(emptyState(), rows, { ...journalMapping, jenis: 6 }));
});

test('ambiguous, fractional, unsafe, and negative monetary values are rejected', () => {
  for (const value of ['1.000', '1,000', 'Rp 1000', 1.5, Number.MAX_SAFE_INTEGER + 1, -1, Infinity]) {
    assert.throws(() => prepareImport(emptyState(), {
      kind: 'products', mapping: { ...masterMapping, harga: 2 }, rows: [['SKU', 'Produk', value]],
    }), `Should reject price ${value}`);
  }
});

test('ambiguous or nonexistent dates are rejected instead of guessed', () => {
  for (const date of ['01/02/2026', '2026-02-30', '2026-13-01', 'not-a-date']) {
    assert.throws(() => importJournals(emptyState(), journals('DATE', 10000, date)));
  }
});

test('cash import makes deterministic double-entry journals and repeat import is skipped', () => {
  const request = {
    kind: 'cash', account: '1-1102',
    mapping: { nomor: 0, tanggal: 1, keterangan: 2, arah: 3, jumlah: 4, akun_lawan: 5, kontak: -1, kategori: -1 },
    rows: [['KAS-001', '2026-10-01', 'Pemasukan Excel', 'Masuk', 50000, '4-3200']],
  };
  const result = prepareImport(emptyState(), request);
  assert.equal(result.summary.added, 1);
  assert.equal(result.state.j.length, 1);
  assert.ok(result.state.j[0].l.some(row => row[0] === '1-1102' && row[1] === 50000 && row[2] === 0));
  assert.ok(result.state.j[0].l.some(row => row[0] === '4-3200' && row[1] === 0 && row[2] === 50000));
  assert.equal(prepareImport(result.state, request).summary.skipped, 1);
  assert.throws(() => prepareImport(emptyState(), { ...request, account: '4-3200' }));
});

test('bank import only appends reconciliation rows and exact repeated rows are skipped', () => {
  const request = {
    kind: 'bank', account: '1-1102',
    mapping: { date: 0, description: 1, amount: 2 },
    rows: [['2026-10-01', 'Transfer rekening', 10000], ['2026-10-02', 'Biaya admin', -1000]],
  };
  const result = prepareImport(emptyState(), request);
  assert.equal(result.summary.added, 2);
  assert.equal(result.state.j.length, 0);
  assert.equal(result.state.reconciliation.length, 2);
  assert.equal(result.state.reconciliation[1].amount, -1000);
  assert.equal(result.state.reconciliation[0].journalId, null);
  const repeated = prepareImport(result.state, request);
  assert.equal(repeated.summary.added, 0);
  assert.equal(repeated.summary.skipped, 2);
});

test('missing required mappings and oversized imports fail clearly', () => {
  assert.throws(() => prepareImport(emptyState(), { kind: 'contacts', mapping: { kode: -1, nama: 0 }, rows: [['Nama saja']] }));
  assert.throws(() => prepareImport(emptyState(), { kind: 'contacts', mapping: masterMapping, rows: Array.from({ length: 10001 }, (_, i) => [`C${i}`, `Kontak ${i}`]) }));
});
