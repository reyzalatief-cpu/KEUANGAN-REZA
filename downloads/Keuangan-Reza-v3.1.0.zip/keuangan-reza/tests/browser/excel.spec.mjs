import { test, expect } from '@playwright/test';
import { mkdtemp, rm } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { tmpdir } from 'node:os';
import { createApplication } from '../../server.mjs';

const fixturePath = name => resolve(import.meta.dirname, 'fixtures', name);
const password = 'Excel-Tests-Only-4821!';
let app, temporaryDirectory, base, csrf;

async function currentBook(page) {
  const response = await page.request.get(`${base}/api/state`);
  expect(response.status()).toBe(200);
  return response.json();
}

async function upload(page, filename, kind = 'journals') {
  await page.locator('[data-tab="import"]').click();
  await page.locator('#excel-file').setInputFiles(fixturePath(filename));
  await page.locator('#excel-file-form').getByRole('button', { name: 'Baca Excel', exact: true }).click();
  await expect(page.locator('#excel-kind')).toBeVisible();
  await page.locator('#excel-kind').selectOption(kind);
  await expect(page.locator('body')).not.toHaveAttribute('aria-busy', 'true');
}

async function preview(page) {
  await page.locator('#excel-preview-form').getByRole('button', { name: 'Periksa & pratinjau', exact: true }).click();
  await expect(page.locator('body')).not.toHaveAttribute('aria-busy', 'true');
}

test.describe('Impor Excel asli dengan database terpisah', () => {
  test.beforeEach(async ({ page }, testInfo) => {
    temporaryDirectory = await mkdtemp(join(tmpdir(), 'reza-excel-browser-'));
    app = createApplication({ dataDir: temporaryDirectory, host: '127.0.0.1', port: 0, appOrigin: '', secureCookies: false });
    const address = await app.listen();
    base = `http://127.0.0.1:${address.port}`;
    const setup = await page.request.post(`${base}/api/setup`, {
      data: { username: 'excel_owner', displayName: 'Pemilik Uji Excel', password },
    });
    expect(setup.status()).toBe(201);
    csrf = (await setup.json()).csrfToken;
    testInfo.browserErrors = [];
    testInfo.externalRequests = [];
    page.on('pageerror', error => testInfo.browserErrors.push(error.message));
    page.on('request', request => {
      const url = new URL(request.url());
      if (['http:', 'https:'].includes(url.protocol) && url.origin !== base) testInfo.externalRequests.push(request.url());
    });
    await page.goto(base);
    await expect(page.getByRole('heading', { name: 'Beranda', exact: true })).toBeVisible();
  });

  test.afterEach(async ({ page }, testInfo) => {
    try {
      expect(testInfo.browserErrors, 'Impor tidak menyebabkan exception JavaScript').toEqual([]);
      expect(testInfo.externalRequests, 'Pembacaan Excel sepenuhnya lokal, tanpa CDN atau AI').toEqual([]);
    } finally {
      await page.close();
      await app?.close();
      await rm(temporaryDirectory, { recursive: true, force: true });
    }
  });

  test('template tersedia, XLSX berkompresi dan tanggal Excel diimpor setelah pratinjau, unggah ulang tidak menggandakan jurnal', async ({ page }) => {
    const template = await page.request.get(`${base}/templates/impor-excel.xlsx`);
    expect(template.status()).toBe(200);
    expect((await template.body()).subarray(0, 4).toString('hex')).toBe('504b0304');
    await upload(page, 'journals.xlsx');
    await preview(page);
    await expect(page.locator('[data-action="excel-import"]')).toBeVisible();
    expect((await currentBook(page)).state.j).toHaveLength(0);
    await page.locator('[data-action="excel-import"]').click();
    await expect(page.locator('#notice')).toContainText(/berhasil|tersimpan|ditambahkan/i);
    let state = (await currentBook(page)).state;
    expect(state.j).toHaveLength(1);
    expect(state.j[0]).toMatchObject({
      tgl: '2026-11-01', jn: 'A', ket: 'Modal hasil impor Excel',
      l: [['1-1102', 250000, 0], ['3-1001', 0, 250000]],
    });
    await page.reload();
    state = (await currentBook(page)).state;
    expect(state.j).toHaveLength(1);
    await upload(page, 'journals.xlsx');
    await preview(page);
    await expect(page.locator('main')).toContainText(/dilewati|sudah ada|duplikat/i);
    expect((await currentBook(page)).state.j).toHaveLength(1);
  });

  test('judul kolom Excel sendiri dapat dipetakan dan master produk benar-benar tersimpan', async ({ page }) => {
    await upload(page, 'products.xlsx', 'products');
    await page.locator('#excel-map-kode').selectOption('0');
    await page.locator('#excel-map-nama').selectOption('1');
    await page.locator('#excel-map-harga').selectOption('2');
    await preview(page);
    expect((await currentBook(page)).state.prod).toHaveLength(0);
    await page.locator('[data-action="excel-import"]').click();
    await expect(page.locator('#notice')).toContainText(/berhasil|tersimpan|ditambahkan/i);
    expect((await currentBook(page)).state.prod).toEqual([
      ['SKU-EXCEL-1', 'Produk Excel', 19000], ['SKU-EXCEL-2', 'Produk Kedua', 23000],
    ]);
  });

  test('satu jurnal salah menolak seluruh file, termasuk ketika validasi browser dilewati', async ({ page }) => {
    await upload(page, 'invalid-journals.xlsx');
    await preview(page);
    await expect(page.locator('#notice .error')).toContainText(/debit|kredit|seimbang/i);
    expect((await currentBook(page)).state.j).toHaveLength(0);
    const response = await page.request.post(`${base}/api/import-excel`, {
      headers: { 'X-CSRF-Token': csrf },
      data: {
        kind: 'journals', revision: 0,
        mapping: { nomor: 0, tanggal: 1, keterangan: 2, kode_akun: 3, debit: 4, kredit: 5 },
        rows: [
          ['GOOD', '2026-11-01', 'Benar', '1-1101', 10000, 0],
          ['GOOD', '2026-11-01', 'Benar', '3-1001', 0, 10000],
          ['BAD', '2026-11-02', 'Salah', '5-2001', 1000, 0],
          ['BAD', '2026-11-02', 'Salah', '1-1101', 0, 999],
        ],
      },
    });
    expect(response.status()).toBe(400);
    const after = await currentBook(page);
    expect(after.revision).toBe(0);
    expect(after.state.j).toHaveLength(0);
  });

  test('server menolak revisi basi dan pengguna pembaca tidak dapat mengimpor', async ({ page }) => {
    const payload = { kind: 'contacts', rows: [['CUS-EXCEL', 'Pelanggan Excel']], mapping: { kode: 0, nama: 1 }, revision: 0 };
    const imported = await page.request.post(`${base}/api/import-excel`, { headers: { 'X-CSRF-Token': csrf }, data: payload });
    expect(imported.status()).toBe(200);
    const conflict = await page.request.post(`${base}/api/import-excel`, { headers: { 'X-CSRF-Token': csrf }, data: payload });
    expect(conflict.status()).toBe(409);
    const created = await page.request.post(`${base}/api/users`, {
      headers: { 'X-CSRF-Token': csrf },
      data: { username: 'excel_reader', role: 'reader', displayName: 'Pembaca Excel', password },
    });
    expect(created.status()).toBe(201);
    const login = await page.request.post(`${base}/api/login`, { data: { username: 'excel_reader', password } });
    expect(login.status()).toBe(200);
    const readerCsrf = (await login.json()).csrfToken;
    // A query change forces boot/session fetch; a hash-only goto would retain
    // the owner UI that was loaded before the API switched browser cookies.
    await page.goto(`${base}/?role=reader#import`);
    await expect(page.locator('#excel-file-form')).toHaveCount(0);
    await expect(page.locator('[data-tab="import"]')).toHaveCount(0);
    const denied = await page.request.post(`${base}/api/import-excel`, {
      headers: { 'X-CSRF-Token': readerCsrf }, data: { ...payload, revision: 1 },
    });
    expect(denied.status()).toBe(403);
    expect((await currentBook(page)).state.bantu).toEqual([['CUS-EXCEL', 'Pelanggan Excel']]);
  });

  test('berkas rusak ditolak tanpa menulis data', async ({ page }) => {
    await page.locator('[data-tab="import"]').click();
    await page.locator('#excel-file').setInputFiles({
      name: 'rusak.xlsx',
      mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      buffer: Buffer.from('Bukan file Excel'),
    });
    await page.locator('#excel-file-form').getByRole('button', { name: 'Baca Excel', exact: true }).click();
    await expect(page.locator('#notice .error')).toBeVisible();
    expect((await currentBook(page)).state.j).toHaveLength(0);
  });

  test('rumus Excel tanpa hasil tersimpan ditolak, bukan diam-diam diubah menjadi harga nol', async ({ page }) => {
    await page.locator('[data-tab="import"]').click();
    await page.locator('#excel-file').setInputFiles(fixturePath('formula-uncached.xlsx'));
    await page.locator('#excel-file-form').getByRole('button', { name: 'Baca Excel', exact: true }).click();
    await expect(page.locator('#notice .error')).toContainText(/rumus|formula|nilai/i);
    expect((await currentBook(page)).state.prod).toHaveLength(0);
  });
});
